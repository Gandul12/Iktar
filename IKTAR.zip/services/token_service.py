import jwt
from datetime import datetime, timedelta
from flask import current_app

class TokenService:
    @staticmethod
    def generate_reset_token(user_id, expires_in=3600):
        """Generate password reset token"""
        try:
            payload = {
                'user_id': user_id,
                'exp': datetime.utcnow() + timedelta(seconds=expires_in),
                'iat': datetime.utcnow(),
                'type': 'password_reset'
            }
            
            token = jwt.encode(
                payload,
                current_app.config['JWT_SECRET_KEY'],
                algorithm='HS256'
            )
            
            return token
        except Exception as e:
            current_app.logger.error(f"Error generating reset token: {str(e)}")
            return None
    
    @staticmethod
    def verify_reset_token(token):
        """Verify and decode password reset token"""
        try:
            payload = jwt.decode(
                token,
                current_app.config['JWT_SECRET_KEY'],
                algorithms=['HS256']
            )
            
            # Check token type
            if payload.get('type') != 'password_reset':
                return None
            
            return payload.get('user_id')
            
        except jwt.ExpiredSignatureError:
            current_app.logger.warning("Reset token has expired")
            return None
        except jwt.InvalidTokenError as e:
            current_app.logger.warning(f"Invalid reset token: {str(e)}")
            return None
        except Exception as e:
            current_app.logger.error(f"Error verifying reset token: {str(e)}")
            return None
    
    @staticmethod
    def generate_email_verification_token(user_id, expires_in=86400):
        """Generate email verification token (24 hours)"""
        try:
            payload = {
                'user_id': user_id,
                'exp': datetime.utcnow() + timedelta(seconds=expires_in),
                'iat': datetime.utcnow(),
                'type': 'email_verification'
            }
            
            token = jwt.encode(
                payload,
                current_app.config['JWT_SECRET_KEY'],
                algorithm='HS256'
            )
            
            return token
        except Exception as e:
            current_app.logger.error(f"Error generating verification token: {str(e)}")
            return None
    
    @staticmethod
    def verify_email_verification_token(token):
        """Verify and decode email verification token"""
        try:
            payload = jwt.decode(
                token,
                current_app.config['JWT_SECRET_KEY'],
                algorithms=['HS256']
            )
            
            # Check token type
            if payload.get('type') != 'email_verification':
                return None
            
            return payload.get('user_id')
            
        except jwt.ExpiredSignatureError:
            current_app.logger.warning("Verification token has expired")
            return None
        except jwt.InvalidTokenError as e:
            current_app.logger.warning(f"Invalid verification token: {str(e)}")
            return None
        except Exception as e:
            current_app.logger.error(f"Error verifying verification token: {str(e)}")
            return None
