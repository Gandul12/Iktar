from database import db
from models.product_stock import Product
from models.transaction_updated import Transaction, TransactionDetail, StockMovement
from flask import session
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class StockService:
    
    @staticmethod
    def check_cart_availability(cart_items):
        """
        Check if all items in cart are available with sufficient stock
        Returns: (is_available, unavailable_items, updated_cart)
        """
        unavailable_items = []
        updated_cart = []
        
        for item in cart_items:
            product = Product.query.get(item['id'])
            
            if not product:
                unavailable_items.append({
                    'id': item['id'],
                    'name': item.get('name', 'Unknown Product'),
                    'reason': 'Product not found'
                })
                continue
            
            if not product.is_active:
                unavailable_items.append({
                    'id': product.id,
                    'name': product.name,
                    'reason': 'Product is no longer active'
                })
                continue
            
            requested_quantity = item['quantity']
            
            if product.stock < requested_quantity:
                unavailable_items.append({
                    'id': product.id,
                    'name': product.name,
                    'requested': requested_quantity,
                    'available': product.stock,
                    'reason': f'Insufficient stock. Available: {product.stock}, Requested: {requested_quantity}'
                })
                
                # Update cart with available quantity if any
                if product.stock > 0:
                    updated_item = item.copy()
                    updated_item['quantity'] = product.stock
                    updated_item['max_available'] = product.stock
                    updated_cart.append(updated_item)
            else:
                # Item is available
                updated_cart.append(item)
        
        is_available = len(unavailable_items) == 0
        return is_available, unavailable_items, updated_cart
    
    @staticmethod
    def process_checkout(cart_items, buyer_id, shipping_address=None, notes=None):
        """
        Process checkout: validate stock, create transaction, reduce stock
        Returns: (success, transaction_id, error_message)
        """
        try:
            # Start database transaction
            db.session.begin()
            
            # Check availability first
            is_available, unavailable_items, updated_cart = StockService.check_cart_availability(cart_items)
            
            if not is_available:
                db.session.rollback()
                error_msg = "Some items are not available:\n"
                for item in unavailable_items:
                    error_msg += f"- {item['name']}: {item['reason']}\n"
                return False, None, error_msg
            
            # Calculate total price
            total_price = 0
            transaction_details = []
            
            for item in cart_items:
                product = Product.query.get(item['id'])
                quantity = item['quantity']
                unit_price = product.price
                subtotal = quantity * unit_price
                
                total_price += subtotal
                
                transaction_details.append({
                    'product': product,
                    'quantity': quantity,
                    'unit_price': unit_price,
                    'subtotal': subtotal
                })
            
            # Create transaction
            transaction = Transaction(
                buyer_id=buyer_id,
                total_price=total_price,
                shipping_address=shipping_address,
                notes=notes
            )
            
            db.session.add(transaction)
            db.session.flush()  # Get transaction ID
            
            # Create transaction details and reduce stock
            for detail_data in transaction_details:
                product = detail_data['product']
                quantity = detail_data['quantity']
                
                # Create transaction detail
                detail = TransactionDetail(
                    transaction_id=transaction.id,
                    product_id=product.id,
                    quantity=quantity,
                    unit_price=detail_data['unit_price'],
                    subtotal=detail_data['subtotal']
                )
                
                db.session.add(detail)
                db.session.flush()  # Get detail ID
                
                # Reduce stock
                product.reduce_stock(quantity, detail.id, buyer_id)
            
            # Commit all changes
            db.session.commit()
            
            logger.info(f"Checkout successful. Transaction ID: {transaction.id}, Buyer ID: {buyer_id}")
            return True, transaction.id, None
            
        except ValueError as e:
            db.session.rollback()
            logger.error(f"Stock validation error during checkout: {str(e)}")
            return False, None, str(e)
        
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error during checkout: {str(e)}")
            return False, None, "An error occurred during checkout. Please try again."
    
    @staticmethod
    def get_low_stock_products(seller_id=None):
        """Get products with low stock"""
        query = Product.query.filter(Product.stock <= Product.min_stock, Product.stock > 0)
        
        if seller_id:
            query = query.filter(Product.seller_id == seller_id)
        
        return query.all()
    
    @staticmethod
    def get_out_of_stock_products(seller_id=None):
        """Get products that are out of stock"""
        query = Product.query.filter(Product.stock == 0)
        
        if seller_id:
            query = query.filter(Product.seller_id == seller_id)
        
        return query.all()
    
    @staticmethod
    def get_stock_movements(product_id=None, limit=50):
        """Get stock movement history"""
        query = StockMovement.query.order_by(StockMovement.created_at.desc())
        
        if product_id:
            query = query.filter(StockMovement.product_id == product_id)
        
        return query.limit(limit).all()
    
    @staticmethod
    def restock_product(product_id, quantity, user_id, notes=None):
        """Restock a product"""
        try:
            product = Product.query.get(product_id)
            if not product:
                return False, "Product not found"
            
            product.increase_stock(quantity, 'restock', notes, user_id)
            db.session.commit()
            
            logger.info(f"Product {product_id} restocked with {quantity} units by user {user_id}")
            return True, f"Successfully restocked {quantity} units"
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error restocking product {product_id}: {str(e)}")
            return False, str(e)
