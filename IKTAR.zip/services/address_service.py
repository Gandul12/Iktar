from models.shipping_address import ShippingAddress, INDONESIAN_PROVINCES
from flask import session
import re

class AddressService:
    
    @staticmethod
    def validate_address_data(data):
        """Validate address form data"""
        errors = []
        
        # Validate recipient name
        recipient_name = data.get('recipient_name', '').strip()
        if not recipient_name:
            errors.append('Nama penerima wajib diisi')
        elif len(recipient_name) < 2:
            errors.append('Nama penerima minimal 2 karakter')
        elif len(recipient_name) > 100:
            errors.append('Nama penerima maksimal 100 karakter')
        
        # Validate phone
        phone = data.get('phone', '').strip()
        if not phone:
            errors.append('Nomor telepon wajib diisi')
        elif not AddressService.validate_phone_number(phone):
            errors.append('Format nomor telepon tidak valid')
        
        # Validate address line
        address_line = data.get('address_line', '').strip()
        if not address_line:
            errors.append('Alamat lengkap wajib diisi')
        elif len(address_line) < 10:
            errors.append('Alamat lengkap minimal 10 karakter')
        elif len(address_line) > 500:
            errors.append('Alamat lengkap maksimal 500 karakter')
        
        # Validate district
        district = data.get('district', '').strip()
        if not district:
            errors.append('Kecamatan wajib diisi')
        elif len(district) > 100:
            errors.append('Kecamatan maksimal 100 karakter')
        
        # Validate city
        city = data.get('city', '').strip()
        if not city:
            errors.append('Kota/Kabupaten wajib diisi')
        elif len(city) > 100:
            errors.append('Kota/Kabupaten maksimal 100 karakter')
        
        # Validate province
        province = data.get('province', '').strip()
        if not province:
            errors.append('Provinsi wajib diisi')
        elif province not in INDONESIAN_PROVINCES:
            errors.append('Provinsi tidak valid')
        
        # Validate postal code
        postal_code = data.get('postal_code', '').strip()
        if not postal_code:
            errors.append('Kode pos wajib diisi')
        elif not AddressService.validate_postal_code(postal_code):
            errors.append('Format kode pos tidak valid (5 digit)')
        
        return errors
    
    @staticmethod
    def validate_phone_number(phone):
        """Validate Indonesian phone number"""
        # Remove all non-digit characters
        phone_digits = re.sub(r'\D', '', phone)
        
        # Check Indonesian phone number patterns
        patterns = [
            r'^08\d{8,11}$',   # 08xxxxxxxxxx
            r'^628\d{8,11}$',  # 628xxxxxxxxxx
            r'^62\d{9,12}$'    # 62xxxxxxxxxx
        ]
        
        return any(re.match(pattern, phone_digits) for pattern in patterns)
    
    @staticmethod
    def validate_postal_code(postal_code):
        """Validate Indonesian postal code (5 digits)"""
        return re.match(r'^\d{5}$', postal_code) is not None
    
    @staticmethod
    def create_address(data, user_id):
        """Create new shipping address"""
        # Validate data
        errors = AddressService.validate_address_data(data)
        if errors:
            return False, None, errors
        
        try:
            # Create new address
            address = ShippingAddress(
                user_id=user_id,
                recipient_name=data['recipient_name'].strip(),
                phone=data['phone'].strip(),
                address_line=data['address_line'].strip(),
                district=data['district'].strip(),
                city=data['city'].strip(),
                province=data['province'].strip(),
                postal_code=data['postal_code'].strip(),
                is_default=data.get('is_default', False)
            )
            
            success, message = address.save()
            if success:
                return True, address, []
            else:
                return False, None, [message]
                
        except Exception as e:
            return False, None, [f'Gagal membuat alamat: {str(e)}']
    
    @staticmethod
    def update_address(address_id, data, user_id):
        """Update existing shipping address"""
        # Validate data
        errors = AddressService.validate_address_data(data)
        if errors:
            return False, None, errors
        
        try:
            # Get address
            address = ShippingAddress.query.filter_by(id=address_id, user_id=user_id).first()
            if not address:
                return False, None, ['Alamat tidak ditemukan']
            
            # Update address data
            address.recipient_name = data['recipient_name'].strip()
            address.phone = data['phone'].strip()
            address.address_line = data['address_line'].strip()
            address.district = data['district'].strip()
            address.city = data['city'].strip()
            address.province = data['province'].strip()
            address.postal_code = data['postal_code'].strip()
            address.is_default = data.get('is_default', False)
            
            success, message = address.save()
            if success:
                return True, address, []
            else:
                return False, None, [message]
                
        except Exception as e:
            return False, None, [f'Gagal mengupdate alamat: {str(e)}']
    
    @staticmethod
    def delete_address(address_id, user_id):
        """Delete shipping address"""
        try:
            address = ShippingAddress.query.filter_by(id=address_id, user_id=user_id).first()
            if not address:
                return False, 'Alamat tidak ditemukan'
            
            success, message = address.delete()
            return success, message
            
        except Exception as e:
            return False, f'Gagal menghapus alamat: {str(e)}'
    
    @staticmethod
    def set_default_address(address_id, user_id):
        """Set address as default"""
        return ShippingAddress.set_as_default(address_id, user_id)
    
    @staticmethod
    def get_user_addresses(user_id):
        """Get all user addresses"""
        return ShippingAddress.get_user_addresses(user_id)
    
    @staticmethod
    def get_address_for_checkout(user_id):
        """Get address options for checkout"""
        addresses = AddressService.get_user_addresses(user_id)
        default_address = next((addr for addr in addresses if addr.is_default), None)
        
        return {
            'addresses': addresses,
            'default_address': default_address,
            'has_addresses': len(addresses) > 0
        }
    
    @staticmethod
    def format_phone_display(phone):
        """Format phone number for display"""
        # Remove all non-digit characters
        phone_digits = re.sub(r'\D', '', phone)
        
        # Format based on pattern
        if phone_digits.startswith('628'):
            # International format: +62 8xx-xxxx-xxxx
            if len(phone_digits) >= 11:
                return f"+62 {phone_digits[2:5]}-{phone_digits[5:9]}-{phone_digits[9:]}"
        elif phone_digits.startswith('08'):
            # Local format: 08xx-xxxx-xxxx
            if len(phone_digits) >= 10:
                return f"{phone_digits[:4]}-{phone_digits[4:8]}-{phone_digits[8:]}"
        
        return phone
