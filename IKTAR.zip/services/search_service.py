from models.product_search import Product
from sqlalchemy import func, distinct
import re

class SearchService:
    
    @staticmethod
    def parse_search_params(request_args):
        """Parse and validate search parameters from request"""
        params = {
            'search_query': request_args.get('q', '').strip(),
            'category': request_args.get('category', '').strip(),
            'price_min': request_args.get('price_min', '').strip(),
            'price_max': request_args.get('price_max', '').strip(),
            'sort_by': request_args.get('sort_by', 'name').strip(),
            'sort_order': request_args.get('sort_order', 'asc').strip(),
            'only_in_stock': request_args.get('in_stock') == '1',
            'page': 1
        }
        
        # Validate and convert page number
        try:
            params['page'] = int(request_args.get('page', 1))
            if params['page'] < 1:
                params['page'] = 1
        except (ValueError, TypeError):
            params['page'] = 1
        
        # Validate price parameters
        if params['price_min']:
            try:
                params['price_min'] = float(params['price_min'])
                if params['price_min'] < 0:
                    params['price_min'] = None
            except (ValueError, TypeError):
                params['price_min'] = None
        else:
            params['price_min'] = None
        
        if params['price_max']:
            try:
                params['price_max'] = float(params['price_max'])
                if params['price_max'] < 0:
                    params['price_max'] = None
            except (ValueError, TypeError):
                params['price_max'] = None
        else:
            params['price_max'] = None
        
        # Validate sort parameters
        valid_sort_fields = ['name', 'price', 'stock', 'created_at']
        if params['sort_by'] not in valid_sort_fields:
            params['sort_by'] = 'name'
        
        if params['sort_order'] not in ['asc', 'desc']:
            params['sort_order'] = 'asc'
        
        return params
    
    @staticmethod
    def build_search_url(base_url, params, exclude_params=None):
        """Build search URL with parameters"""
        if exclude_params is None:
            exclude_params = []
        
        url_params = []
        
        for key, value in params.items():
            if key in exclude_params or not value:
                continue
            
            if key == 'search_query':
                url_params.append(f'q={value}')
            elif key == 'only_in_stock' and value:
                url_params.append('in_stock=1')
            elif key in ['price_min', 'price_max'] and value is not None:
                url_params.append(f'{key}={value}')
            elif value and key not in ['page']:
                url_params.append(f'{key}={value}')
        
        if url_params:
            return f"{base_url}?{'&'.join(url_params)}"
        return base_url
    
    @staticmethod
    def get_filter_summary(params):
        """Generate human-readable filter summary"""
        summary_parts = []
        
        if params['search_query']:
            summary_parts.append(f"'{params['search_query']}'")
        
        if params['category'] and params['category'] != 'all':
            category_names = {
                'hias': 'Ikan Hias',
                'konsumsi': 'Ikan Konsumsi',
                'predator': 'Ikan Predator',
                'bibit': 'Bibit Ikan'
            }
            summary_parts.append(f"Kategori: {category_names.get(params['category'], params['category'])}")
        
        if params['price_min'] is not None or params['price_max'] is not None:
            if params['price_min'] is not None and params['price_max'] is not None:
                summary_parts.append(f"Harga: Rp {params['price_min']:,.0f} - Rp {params['price_max']:,.0f}")
            elif params['price_min'] is not None:
                summary_parts.append(f"Harga minimal: Rp {params['price_min']:,.0f}")
            elif params['price_max'] is not None:
                summary_parts.append(f"Harga maksimal: Rp {params['price_max']:,.0f}")
        
        if params['only_in_stock']:
            summary_parts.append("Hanya yang tersedia")
        
        return ' | '.join(summary_parts) if summary_parts else None
    
    @staticmethod
    def get_popular_searches():
        """Get popular search terms (can be enhanced with analytics)"""
        return [
            'guppy', 'lele', 'nila', 'mas', 'cupang', 
            'gurame', 'arwana', 'koi', 'patin', 'bawal'
        ]
    
    @staticmethod
    def clean_search_query(query):
        """Clean and normalize search query"""
        if not query:
            return ''
        
        # Remove special characters except spaces and hyphens
        cleaned = re.sub(r'[^\w\s\-]', '', query)
        
        # Remove extra spaces
        cleaned = ' '.join(cleaned.split())
        
        return cleaned.strip()
