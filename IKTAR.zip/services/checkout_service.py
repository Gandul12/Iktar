from database import db
from models.transaction_checkout import Transaction, TransactionDetail
from models.product_search import Product
from flask import session
from datetime import datetime
import logging
import re

logger = logging.getLogger(__name__)

class CheckoutService:
    
    @staticmethod
    def validate_checkout_data(form_data, cart_items):
        """
        Validate checkout form data and cart items
        Returns: (is_valid, errors)
        """
        errors = []
        
        # Validate cart
        if not cart_items:
            errors.append('Keranjang belanja kosong.')
            return False, errors
        
        # Validate customer information
        customer_name = form_data.get('customer_name', '').strip()
        customer_phone = form_data.get('customer_phone', '').strip()
        shipping_address = form_data.get('shipping_address', '').strip()
        
        if not customer_name or len(customer_name) < 2:
            errors.append('Nama lengkap minimal 2 karakter.')
        
        if not customer_phone:
            errors.append('Nomor telepon wajib diisi.')
        elif not CheckoutService.validate_phone_number(customer_phone):
            errors.append('Format nomor telepon tidak valid.')
        
        if not shipping_address or len(shipping_address) < 10:
            errors.append('Alamat lengkap minimal 10 karakter.')
        
        # Validate cart items availability
        for item in cart_items:
            product = Product.query.get(item.get('id'))
            if not product:
                errors.append(f'Produk dengan ID {item.get("id")} tidak ditemukan.')
                continue
            
            if not product.is_active:
                errors.append(f'Produk {product.name} tidak lagi tersedia.')
                continue
            
            if product.stock < item.get('quantity', 0):
                errors.append(f'Stok {product.name} tidak mencukupi. Tersedia: {product.stock}, diminta: {item.get("quantity", 0)}.')
        
        return len(errors) == 0, errors
    
    @staticmethod
    def validate_phone_number(phone):
        """Validate Indonesian phone number format"""
        # Remove all non-digit characters
        phone_digits = re.sub(r'\D', '', phone)
        
        # Check if it's a valid Indonesian phone number
        # Should start with 08, +628, or 628 and have 10-13 digits total
        patterns = [
            r'^08\d{8,11}$',  # 08xxxxxxxxxx
            r'^628\d{8,11}$',  # 628xxxxxxxxxx
            r'^62\d{9,12}$'    # 62xxxxxxxxxx
        ]
        
        return any(re.match(pattern, phone_digits) for pattern in patterns)
    
    @staticmethod
    def calculate_cart_total(cart_items):
        """Calculate total price for cart items"""
        total = 0
        for item in cart_items:
            product = Product.query.get(item.get('id'))
            if product:
                total += product.price * item.get('quantity', 0)
        return total
    
    @staticmethod
    def process_checkout(form_data, cart_items, buyer_id):
        """
        Process checkout: validate, create transaction, reduce stock
        Returns: (success, transaction_id, error_message)
        """
        try:
            # Start database transaction
            db.session.begin()
            
            # Validate data
            is_valid, errors = CheckoutService.validate_checkout_data(form_data, cart_items)
            if not is_valid:
                db.session.rollback()
                return False, None, '; '.join(errors)
            
            # Calculate total price
            total_price = CheckoutService.calculate_cart_total(cart_items)
            
            # Create transaction
            transaction = Transaction(
                buyer_id=buyer_id,
                total_price=total_price,
                customer_name=form_data.get('customer_name', '').strip(),
                customer_phone=form_data.get('customer_phone', '').strip(),
                shipping_address=form_data.get('shipping_address', '').strip(),
                notes=form_data.get('notes', '').strip()
            )
            
            db.session.add(transaction)
            db.session.flush()  # Get transaction ID
            
            # Create transaction details and reduce stock
            for item in cart_items:
                product = Product.query.get(item.get('id'))
                quantity = item.get('quantity', 0)
                
                # Double-check stock availability
                if product.stock < quantity:
                    db.session.rollback()
                    return False, None, f'Stok {product.name} tidak mencukupi.'
                
                # Create transaction detail
                detail = TransactionDetail(
                    transaction_id=transaction.id,
                    product_id=product.id,
                    quantity=quantity,
                    unit_price=product.price,
                    subtotal=product.price * quantity
                )
                
                db.session.add(detail)
                
                # Reduce product stock
                product.stock -= quantity
                product.updated_at = datetime.utcnow()
            
            # Commit all changes
            db.session.commit()
            
            logger.info(f"Checkout successful. Transaction ID: {transaction.id}, Buyer ID: {buyer_id}")
            return True, transaction.id, None
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error during checkout: {str(e)}")
            return False, None, "Terjadi kesalahan saat memproses pesanan. Silakan coba lagi."
    
    @staticmethod
    def get_cart_summary(cart_items):
        """Get detailed cart summary for display"""
        cart_summary = []
        total_price = 0
        total_items = 0
        
        for item in cart_items:
            product = Product.query.get(item.get('id'))
            if product:
                quantity = item.get('quantity', 0)
                subtotal = product.price * quantity
                
                cart_summary.append({
                    'product': product,
                    'quantity': quantity,
                    'subtotal': subtotal,
                    'available_stock': product.stock,
                    'is_available': product.stock >= quantity and product.is_active
                })
                
                total_price += subtotal
                total_items += quantity
        
        return {
            'items': cart_summary,
            'total_price': total_price,
            'total_items': total_items,
            'has_unavailable_items': any(not item['is_available'] for item in cart_summary)
        }
    
    @staticmethod
    def format_phone_number(phone):
        """Format phone number for display"""
        # Remove all non-digit characters
        phone_digits = re.sub(r'\D', '', phone)
        
        # Format as Indonesian phone number
        if phone_digits.startswith('628'):
            return f"+{phone_digits[:2]} {phone_digits[2:5]} {phone_digits[5:9]} {phone_digits[9:]}"
        elif phone_digits.startswith('08'):
            return f"{phone_digits[:4]} {phone_digits[4:8]} {phone_digits[8:]}"
        else:
            return phone
