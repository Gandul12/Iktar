from models.transaction_tracking import TrackingUpdate, ShippingStatus
from models.transaction_checkout import Transaction
from database import db
from datetime import datetime
from sqlalchemy.exc import SQLAlchemyError
import logging

logger = logging.getLogger(__name__)

class TrackingService:
    @staticmethod
    def get_transaction_tracking(transaction_id):
        """Get tracking information for a transaction"""
        try:
            transaction = Transaction.query.get(transaction_id)
            if not transaction:
                return None, "Transaksi tidak ditemukan"
            
            tracking_updates = TrackingUpdate.query.filter_by(transaction_id=transaction_id).order_by(TrackingUpdate.created_at.desc()).all()
            
            # If no tracking updates exist, create an initial "Diproses" status
            if not tracking_updates:
                initial_update = TrackingUpdate(
                    transaction_id=transaction_id,
                    status=ShippingStatus.PROCESSED,
                    notes="Pesanan sedang diproses",
                    location="Toko Penjual",
                    updated_by=transaction.transaction_details[0].product.seller_id if transaction.transaction_details else None
                )
                db.session.add(initial_update)
                db.session.commit()
                tracking_updates = [initial_update]
            
            current_status = tracking_updates[0].status if tracking_updates else ShippingStatus.PROCESSED
            
            return {
                'transaction': transaction,
                'tracking_updates': tracking_updates,
                'current_status': current_status
            }, None
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error in get_transaction_tracking: {str(e)}")
            return None, "Terjadi kesalahan saat mengambil data tracking"
        except Exception as e:
            logger.error(f"Unexpected error in get_transaction_tracking: {str(e)}")
            return None, "Terjadi kesalahan yang tidak diketahui"
    
    @staticmethod
    def update_shipping_status(transaction_id, new_status, user_id, notes=None, location=None):
        """Update shipping status for a transaction"""
        try:
            # Validate transaction exists
            transaction = Transaction.query.get(transaction_id)
            if not transaction:
                return False, "Transaksi tidak ditemukan"
            
            # Validate status
            try:
                status_enum = ShippingStatus(new_status)
            except ValueError:
                return False, "Status pengiriman tidak valid"
            
            # Get current status
            latest_update = TrackingUpdate.query.filter_by(transaction_id=transaction_id).order_by(TrackingUpdate.created_at.desc()).first()
            current_status = latest_update.status if latest_update else None
            
            # Validate status transition
            if current_status == status_enum:
                return False, f"Status pengiriman sudah {status_enum.value}"
            
            # Create new tracking update
            tracking_update = TrackingUpdate(
                transaction_id=transaction_id,
                status=status_enum,
                notes=notes or f"Status diubah menjadi {status_enum.value}",
                location=location or "Lokasi tidak ditentukan",
                updated_by=user_id
            )
            
            db.session.add(tracking_update)
            
            # Update transaction status if needed
            if status_enum == ShippingStatus.DELIVERED:
                # If we want to update the main transaction status as well
                pass
            
            db.session.commit()
            
            return True, f"Status pengiriman berhasil diubah menjadi {status_enum.value}"
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error in update_shipping_status: {str(e)}")
            return False, "Terjadi kesalahan saat mengupdate status pengiriman"
        except Exception as e:
            logger.error(f"Unexpected error in update_shipping_status: {str(e)}")
            return False, "Terjadi kesalahan yang tidak diketahui"
    
    @staticmethod
    def get_available_status_transitions(current_status):
        """Get available status transitions based on current status"""
        all_statuses = list(ShippingStatus)
        
        # Define valid transitions
        valid_transitions = {
            ShippingStatus.PROCESSED: [ShippingStatus.SHIPPED],
            ShippingStatus.SHIPPED: [ShippingStatus.DELIVERED],
            ShippingStatus.DELIVERED: []  # Terminal state
        }
        
        # Return valid transitions or empty list if current_status not found
        return valid_transitions.get(current_status, [])
    
    @staticmethod
    def get_dummy_tracking_locations():
        """Get dummy tracking locations for demonstration"""
        return [
            "Gudang Pusat IkTar",
            "Pusat Sortir Jakarta",
            "Pusat Distribusi Regional",
            "Kantor Cabang Lokal",
            "Kurir Lokal",
            "Alamat Pengiriman"
        ]
