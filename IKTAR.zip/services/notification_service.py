from database import db
from models.notification import Notification, NotificationType, TransactionStatus
from models.transaction_checkout import Transaction
from datetime import datetime

class NotificationService:
    
    @staticmethod
    def create_notification(user_id, notification_type, title, message, transaction_id=None):
        """Create a new notification"""
        try:
            notification = Notification(
                user_id=user_id,
                transaction_id=transaction_id,
                type=notification_type,
                title=title,
                message=message
            )
            
            db.session.add(notification)
            db.session.commit()
            return notification
        except Exception as e:
            db.session.rollback()
            raise e
    
    @staticmethod
    def get_user_notifications(user_id, limit=50, unread_only=False):
        """Get notifications for a user"""
        query = Notification.query.filter_by(user_id=user_id)
        
        if unread_only:
            query = query.filter_by(is_read=False)
        
        return query.order_by(Notification.created_at.desc()).limit(limit).all()
    
    @staticmethod
    def get_unread_count(user_id):
        """Get count of unread notifications"""
        return Notification.query.filter_by(user_id=user_id, is_read=False).count()
    
    @staticmethod
    def mark_as_read(notification_id, user_id):
        """Mark a notification as read"""
        notification = Notification.query.filter_by(
            id=notification_id, 
            user_id=user_id
        ).first()
        
        if notification:
            notification.mark_as_read()
            return True
        return False
    
    @staticmethod
    def mark_all_as_read(user_id):
        """Mark all notifications as read for a user"""
        try:
            notifications = Notification.query.filter_by(
                user_id=user_id, 
                is_read=False
            ).all()
            
            for notification in notifications:
                notification.is_read = True
                notification.read_at = datetime.utcnow()
            
            db.session.commit()
            return len(notifications)
        except Exception as e:
            db.session.rollback()
            raise e
    
    @staticmethod
    def notify_transaction_status_change(transaction, old_status, new_status, updated_by):
        """Create notification when transaction status changes"""
        status_messages = {
            TransactionStatus.CONFIRMED: {
                'title': 'Pesanan Dikonfirmasi',
                'message': f'Pesanan #{transaction.get_order_number()} telah dikonfirmasi oleh penjual dan sedang diproses.',
                'type': NotificationType.ORDER_CONFIRMED
            },
            TransactionStatus.PROCESSING: {
                'title': 'Pesanan Sedang Diproses',
                'message': f'Pesanan #{transaction.get_order_number()} sedang diproses dan akan segera dikirim.',
                'type': NotificationType.TRANSACTION_STATUS
            },
            TransactionStatus.SHIPPED: {
                'title': 'Pesanan Dikirim',
                'message': f'Pesanan #{transaction.get_order_number()} telah dikirim. Mohon tunggu hingga pesanan tiba.',
                'type': NotificationType.ORDER_SHIPPED
            },
            TransactionStatus.DELIVERED: {
                'title': 'Pesanan Diterima',
                'message': f'Pesanan #{transaction.get_order_number()} telah selesai. Terima kasih telah berbelanja di IkTar!',
                'type': NotificationType.ORDER_DELIVERED
            },
            TransactionStatus.CANCELLED: {
                'title': 'Pesanan Dibatalkan',
                'message': f'Pesanan #{transaction.get_order_number()} telah dibatalkan. Silakan hubungi customer service untuk informasi lebih lanjut.',
                'type': NotificationType.ORDER_CANCELLED
            }
        }
        
        if new_status in status_messages:
            notification_data = status_messages[new_status]
            return NotificationService.create_notification(
                user_id=transaction.buyer_id,
                notification_type=notification_data['type'],
                title=notification_data['title'],
                message=notification_data['message'],
                transaction_id=transaction.id
            )
        
        return None
    
    @staticmethod
    def delete_old_notifications(days=30):
        """Delete notifications older than specified days"""
        from datetime import timedelta
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        old_notifications = Notification.query.filter(
            Notification.created_at < cutoff_date,
            Notification.is_read == True
        ).all()
        
        for notification in old_notifications:
            db.session.delete(notification)
        
        db.session.commit()
        return len(old_notifications)
