import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from flask import current_app, render_template_string
import logging

class EmailService:
    @staticmethod
    def send_email(to_email, subject, html_body, text_body=None):
        """Send email using SMTP"""
        try:
            # Get email configuration
            smtp_server = current_app.config.get('MAIL_SERVER')
            smtp_port = current_app.config.get('MAIL_PORT')
            username = current_app.config.get('MAIL_USERNAME')
            password = current_app.config.get('MAIL_PASSWORD')
            use_tls = current_app.config.get('MAIL_USE_TLS')
            
            if not all([smtp_server, username, password]):
                current_app.logger.warning("Email configuration incomplete")
                return False
            
            # Create message
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = username
            msg['To'] = to_email
            
            # Add text and HTML parts
            if text_body:
                text_part = MIMEText(text_body, 'plain')
                msg.attach(text_part)
            
            html_part = MIMEText(html_body, 'html')
            msg.attach(html_part)
            
            # Send email
            server = smtplib.SMTP(smtp_server, smtp_port)
            if use_tls:
                server.starttls()
            server.login(username, password)
            server.send_message(msg)
            server.quit()
            
            current_app.logger.info(f"Email sent successfully to {to_email}")
            return True
            
        except Exception as e:
            current_app.logger.error(f"Failed to send email to {to_email}: {str(e)}")
            return False
    
    @staticmethod
    def send_password_reset_email(user, reset_token):
        """Send password reset email"""
        reset_url = f"http://localhost:5000/auth/reset-password/{reset_token}"
        
        html_template = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Reset Password - Iktar</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #2563eb;">Reset Password Anda</h2>
                <p>Halo {{ user_name }},</p>
                <p>Kami menerima permintaan untuk reset password akun Anda di Iktar.</p>
                <p>Klik tombol di bawah ini untuk reset password:</p>
                <div style="text-align: center; margin: 30px 0;">
                    <a href="{{ reset_url }}" 
                       style="background-color: #2563eb; color: white; padding: 12px 30px; 
                              text-decoration: none; border-radius: 5px; display: inline-block;">
                        Reset Password
                    </a>
                </div>
                <p>Atau copy dan paste link berikut di browser Anda:</p>
                <p style="word-break: break-all; color: #666;">{{ reset_url }}</p>
                <p><strong>Link ini akan expired dalam 1 jam.</strong></p>
                <p>Jika Anda tidak meminta reset password, abaikan email ini.</p>
                <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
                <p style="color: #666; font-size: 12px;">
                    Email ini dikirim otomatis, mohon tidak membalas email ini.
                </p>
            </div>
        </body>
        </html>
        """
        
        text_template = """
        Reset Password Anda - Iktar
        
        Halo {{ user_name }},
        
        Kami menerima permintaan untuk reset password akun Anda di Iktar.
        
        Klik link berikut untuk reset password:
        {{ reset_url }}
        
        Link ini akan expired dalam 1 jam.
        
        Jika Anda tidak meminta reset password, abaikan email ini.
        """
        
        html_body = render_template_string(html_template, 
                                         user_name=user.name, 
                                         reset_url=reset_url)
        text_body = render_template_string(text_template, 
                                         user_name=user.name, 
                                         reset_url=reset_url)
        
        return EmailService.send_email(
            to_email=user.email,
            subject="Reset Password - Iktar",
            html_body=html_body,
            text_body=text_body
        )
    
    @staticmethod
    def send_welcome_email(user):
        """Send welcome email to new users"""
        html_template = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Selamat Datang di Iktar</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="color: #2563eb;">Selamat Datang di Iktar! 🐟</h2>
                <p>Halo {{ user_name }},</p>
                <p>Terima kasih telah bergabung dengan Iktar - Marketplace Ikan Segar terpercaya!</p>
                
                {% if user_role == 'buyer' %}
                <p>Sebagai pembeli, Anda dapat:</p>
                <ul>
                    <li>Menjelajahi berbagai jenis ikan segar berkualitas</li>
                    <li>Menambahkan produk ke keranjang belanja</li>
                    <li>Melakukan pemesanan dengan mudah</li>
                    <li>Melacak status pesanan Anda</li>
                    <li>Memberikan review untuk produk</li>
                </ul>
                {% else %}
                <p>Sebagai penjual, Anda dapat:</p>
                <ul>
                    <li>Menambahkan produk ikan untuk dijual</li>
                    <li>Mengelola stok dan harga produk</li>
                    <li>Memproses pesanan dari pembeli</li>
                    <li>Melacak penjualan dan pendapatan</li>
                    <li>Berkomunikasi dengan pembeli</li>
                </ul>
                {% endif %}
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="http://localhost:5000" 
                       style="background-color: #2563eb; color: white; padding: 12px 30px; 
                              text-decoration: none; border-radius: 5px; display: inline-block;">
                        Mulai Belanja Sekarang
                    </a>
                </div>
                
                <p>Jika Anda memiliki pertanyaan, jangan ragu untuk menghubungi tim support kami.</p>
                <p>Selamat berbelanja!</p>
                
                <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
                <p style="color: #666; font-size: 12px;">
                    Tim Iktar<br>
                    Email ini dikirim otomatis, mohon tidak membalas email ini.
                </p>
            </div>
        </body>
        </html>
        """
        
        html_body = render_template_string(html_template, 
                                         user_name=user.name,
                                         user_role=user.role.value)
        
        return EmailService.send_email(
            to_email=user.email,
            subject="Selamat Datang di Iktar! 🐟",
            html_body=html_body
        )
