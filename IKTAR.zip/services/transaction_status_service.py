from database import db
from models.notification import TransactionStatusUpdate, TransactionStatus
from models.transaction_checkout import Transaction
from services.notification_service import NotificationService
from datetime import datetime

class TransactionStatusService:
    
    @staticmethod
    def update_transaction_status(transaction_id, new_status, updated_by, notes=None):
        """Update transaction status and create notification"""
        try:
            transaction = Transaction.query.get(transaction_id)
            if not transaction:
                return False, "Transaksi tidak ditemukan"
            
            old_status = transaction.status
            
            # Validate status transition
            if not TransactionStatusService._is_valid_status_transition(old_status, new_status):
                return False, f"Tidak dapat mengubah status dari {old_status.value} ke {new_status.value}"
            
            # Update transaction status
            transaction.status = new_status
            transaction.updated_at = datetime.utcnow()
            
            # Create status update record
            status_update = TransactionStatusUpdate(
                transaction_id=transaction_id,
                old_status=old_status,
                new_status=new_status,
                updated_by=updated_by,
                notes=notes
            )
            
            db.session.add(status_update)
            db.session.commit()
            
            # Create notification for buyer
            NotificationService.notify_transaction_status_change(
                transaction, old_status, new_status, updated_by
            )
            
            return True, "Status transaksi berhasil diperbarui"
            
        except Exception as e:
            db.session.rollback()
            return False, f"Terjadi kesalahan: {str(e)}"
    
    @staticmethod
    def _is_valid_status_transition(old_status, new_status):
        """Validate if status transition is allowed"""
        valid_transitions = {
            TransactionStatus.PENDING: [TransactionStatus.CONFIRMED, TransactionStatus.CANCELLED],
            TransactionStatus.CONFIRMED: [TransactionStatus.PROCESSING, TransactionStatus.CANCELLED],
            TransactionStatus.PROCESSING: [TransactionStatus.SHIPPED, TransactionStatus.CANCELLED],
            TransactionStatus.SHIPPED: [TransactionStatus.DELIVERED],
            TransactionStatus.DELIVERED: [],  # Final status
            TransactionStatus.CANCELLED: []   # Final status
        }
        
        return new_status in valid_transitions.get(old_status, [])
    
    @staticmethod
    def get_transaction_history(transaction_id):
        """Get status update history for a transaction"""
        return TransactionStatusUpdate.query.filter_by(
            transaction_id=transaction_id
        ).order_by(TransactionStatusUpdate.created_at.desc()).all()
    
    @staticmethod
    def get_seller_transactions(seller_id, status=None):
        """Get transactions for a seller, optionally filtered by status"""
        from models.product_updated import Product
        
        query = db.session.query(Transaction).join(
            Transaction.transaction_details
        ).join(
            TransactionDetail.product
        ).filter(
            Product.seller_id == seller_id
        )
        
        if status:
            query = query.filter(Transaction.status == status)
        
        return query.order_by(Transaction.created_at.desc()).all()
    
    @staticmethod
    def get_available_status_transitions(current_status):
        """Get available status transitions for current status"""
        transitions = {
            TransactionStatus.PENDING: [
                (TransactionStatus.CONFIRMED, 'Konfirmasi Pesanan'),
                (TransactionStatus.CANCELLED, 'Batalkan Pesanan')
            ],
            TransactionStatus.CONFIRMED: [
                (TransactionStatus.PROCESSING, 'Mulai Proses'),
                (TransactionStatus.CANCELLED, 'Batalkan Pesanan')
            ],
            TransactionStatus.PROCESSING: [
                (TransactionStatus.SHIPPED, 'Kirim Pesanan'),
                (TransactionStatus.CANCELLED, 'Batalkan Pesanan')
            ],
            TransactionStatus.SHIPPED: [
                (TransactionStatus.DELIVERED, 'Tandai Selesai')
            ],
            TransactionStatus.DELIVERED: [],
            TransactionStatus.CANCELLED: []
        }
        
        return transitions.get(current_status, [])
