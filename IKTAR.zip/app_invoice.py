from flask import Flask, render_template, redirect, url_for
from flask_login import LoginManager, current_user
from flask_migrate import Migrate
from models.user import db, User, load_user
from routes.auth import auth_bp
from routes.invoice import invoice_bp
from utils.decorators import buyer_required, seller_required
import os

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'iktar-secret-key-change-in-production')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///iktar.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['WTF_CSRF_ENABLED'] = True
    
    # Initialize extensions
    db.init_app(app)
    migrate = Migrate(app, db)
    
    # Initialize Flask-Login
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Silakan login untuk mengakses halaman ini.'
    login_manager.login_message_category = 'info'
    
    # User loader
    @login_manager.user_loader
    def load_user_callback(user_id):
        return load_user(user_id)
    
    # Register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(invoice_bp)
    
    # Main routes
    @app.route('/')
    def home():
        return render_template('home.html')
    
    @app.route('/buyer/dashboard')
    @buyer_required
    def buyer_dashboard():
        return render_template('buyer/dashboard.html')
    
    @app.route('/seller/dashboard')
    @seller_required
    def seller_dashboard():
        return render_template('seller/dashboard.html')
    
    # Context processors
    @app.context_processor
    def inject_user():
        return dict(current_user=current_user)
    
    # Create tables
    with app.app_context():
        db.create_all()
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
