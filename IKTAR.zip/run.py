#!/usr/bin/env python3
"""
IkTar - Platform Jual Beli Ikan Air Tawar
Main application runner
"""

import os
import sys

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def main():
    """Main application entry point"""
    try:
        from app import create_app, db
        from app.models import User, Product, UserRole
        
        app = create_app()
        
        with app.app_context():
            try:
                # Create tables if they don't exist
                db.create_all()
                print("✅ Database tables created successfully!")
                
                # Create sample data in development
                create_sample_data()
                    
            except Exception as e:
                print(f"⚠️ Database setup error: {e}")
                return
        
        print("🐟 IkTar Application Starting...")
        print("📍 URL: http://localhost:5000")
        print("👑 Admin: admin@iktar.com / admin123")
        print("🏪 Seller: seller@iktar.com / seller123")
        print("🛒 Buyer: buyer@iktar.com / buyer123")
        print("=" * 50)
        
        # Run the application
        app.run(
            host='0.0.0.0',
            port=int(os.environ.get('PORT', 5000)),
            debug=True
        )
        
    except ImportError as e:
        print(f"❌ Import Error: {e}")
        print("💡 Please install required packages:")
        print("   pip install Flask Flask-SQLAlchemy Flask-Login Flask-WTF")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Application Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

def create_sample_data():
    """Create sample data for development"""
    try:
        from app import db
        from app.models import User, Product, UserRole
        
        # Create admin user
        if not User.query.filter_by(email='admin@iktar.com').first():
            admin = User(
                name='Administrator',
                email='admin@iktar.com',
                role=UserRole.ADMIN
            )
            admin.set_password('admin123')
            db.session.add(admin)
        
        # Create sample seller
        if not User.query.filter_by(email='seller@iktar.com').first():
            seller = User(
                name='Penjual Demo',
                email='seller@iktar.com',
                role=UserRole.SELLER
            )
            seller.set_password('seller123')
            db.session.add(seller)
            db.session.commit()
            
            # Create sample products
            products = [
                {
                    'name': 'Ikan Guppy Premium',
                    'description': 'Ikan guppy berkualitas tinggi dengan warna-warna indah. Cocok untuk aquarium hias. Mudah dipelihara dan cocok untuk pemula.',
                    'price': 15000,
                    'stock': 50,
                    'category': 'hias'
                },
                {
                    'name': 'Ikan Lele Segar',
                    'description': 'Ikan lele segar langsung dari kolam. Daging empuk dan bergizi tinggi. Cocok untuk berbagai masakan.',
                    'price': 25000,
                    'stock': 30,
                    'category': 'konsumsi'
                },
                {
                    'name': 'Ikan Arwana Silver',
                    'description': 'Ikan arwana silver berkualitas tinggi. Cocok untuk aquarium besar. Ikan predator yang eksotis dan menarik.',
                    'price': 500000,
                    'stock': 5,
                    'category': 'predator'
                },
                {
                    'name': 'Bibit Ikan Nila',
                    'description': 'Bibit ikan nila unggul untuk budidaya. Pertumbuhan cepat dan tahan penyakit. Cocok untuk pemula dalam budidaya.',
                    'price': 5000,
                    'stock': 100,
                    'category': 'bibit'
                }
            ]
            
            for prod_data in products:
                product = Product(
                    seller_id=seller.id,
                    **prod_data
                )
                db.session.add(product)
        
        # Create sample buyer
        if not User.query.filter_by(email='buyer@iktar.com').first():
            buyer = User(
                name='Pembeli Demo',
                email='buyer@iktar.com',
                role=UserRole.BUYER
            )
            buyer.set_password('buyer123')
            db.session.add(buyer)
        
        db.session.commit()
        print("✅ Sample data created successfully!")
        
    except Exception as e:
        print(f"⚠️ Error creating sample data: {e}")
        db.session.rollback()

if __name__ == '__main__':
    main()
