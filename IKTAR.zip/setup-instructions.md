# === SETUP LOCAL DEVELOPMENT ===

# 1. Download project dari v0
# Klik "Download Code" di v0 interface

# 2. Extract dan masuk ke folder project
cd iktarproductpage122

# 3. Install dependencies
npm install

# 4. Buat file environment
echo "NEXT_PUBLIC_API_URL=" > .env.local

# 5. Jalankan development server
npm run dev

# 6. Buka browser ke http://localhost:3000
