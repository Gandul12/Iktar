# === LANGKAH REORGANISASI ===

# 1. Buat folder backend
mkdir backend
mkdir backend/app
mkdir backend/app/models
mkdir backend/app/routes
mkdir backend/app/api

# 2. Pindahkan file Python ke backend/
move app*.py backend/
move run.py backend/
move config.py backend/
move requirements.txt backend/

# 3. Pindahkan folder models, routes, dll
move models backend/app/
move routes backend/app/
move templates backend/app/
move forms backend/app/

# 4. Buat file __init__.py yang diperlukan
echo. > backend/app/__init__.py
echo. > backend/app/models/__init__.py
echo. > backend/app/routes/__init__.py
echo. > backend/app/api/__init__.py
\`\`\`

\`\`\`python file="backend/run.py"
from flask import Flask
from flask_cors import CORS
import os
import sys

# Add the backend directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

app = Flask(__name__)
CORS(app)

# Simple configuration
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///iktar.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Simple routes for testing
@app.route('/')
def home():
    return {'message': 'IkTar Backend API is running!'}

@app.route('/api/products')
def get_products():
    return {
        'products': [
            {
                'id': 1,
                'name': 'Ikan Salmon Premium',
                'price': 150000,
                'image': '/placeholder.svg?height=200&width=200',
                'category': 'Salmon'
            },
            {
                'id': 2,
                'name': 'Ikan Tuna Segar',
                'price': 120000,
                'image': '/placeholder.svg?height=200&width=200',
                'category': 'Tuna'
            }
        ]
    }

@app.route('/api/stats')
def get_stats():
    return {
        'totalProducts': 150,
        'totalSellers': 25,
        'totalBuyers': 500
    }

if __name__ == '__main__':
    app.run(debug=True, port=5000)
