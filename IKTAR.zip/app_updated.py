from flask import Flask, render_template, session, redirect, url_for, request, flash
from database import db
from routes.auth import auth
from routes.seller import seller
from routes.main import main
import os

app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'iktar-secret-key-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///iktar.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# File upload configuration
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5MB max file size
app.config['UPLOAD_FOLDER'] = 'static/uploads'

# Initialize extensions
db.init_app(app)

# Register blueprints
app.register_blueprint(auth)
app.register_blueprint(seller)
app.register_blueprint(main)

# Create database tables and upload directories
@app.before_first_request
def create_tables():
    db.create_all()
    
    # Create upload directories
    os.makedirs('static/uploads', exist_ok=True)
    os.makedirs('static/images', exist_ok=True)

# Error handlers
@app.errorhandler(413)
def too_large(e):
    flash('File terlalu besar. Maksimal 5MB.', 'error')
    return redirect(request.url)

@app.errorhandler(404)
def not_found(e):
    return render_template('404.html'), 404

if __name__ == '__main__':
    app.run(debug=True)
