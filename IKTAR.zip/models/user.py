from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import enum

db = SQLAlchemy()

class UserRole(enum.Enum):
    BUYER = 'buyer'
    SELLER = 'seller'

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum(UserRole), nullable=False, default=UserRole.BUYER)
    is_active = db.Column(db.Boolean, default=True)
    
    # Session tracking
    last_login = db.Column(db.DateTime)
    last_activity = db.Column(db.DateTime)
    login_count = db.Column(db.Integer, default=0)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __init__(self, name, email, password, role=UserRole.BUYER):
        self.name = name
        self.email = email.lower().strip()
        self.set_password(password)
        self.role = role
    
    def set_password(self, password):
        """Hash and set password"""
        self.password_hash = generate_password_hash(password, method='pbkdf2:sha256')
    
    def check_password(self, password):
        """Check if provided password matches hash"""
        return check_password_hash(self.password_hash, password)
    
    def is_buyer(self):
        """Check if user is a buyer"""
        return self.role == UserRole.BUYER
    
    def is_seller(self):
        """Check if user is a seller"""
        return self.role == UserRole.SELLER
    
    def get_role_display(self):
        """Get human-readable role name"""
        return 'Pembeli' if self.is_buyer() else 'Penjual'
    
    def get_dashboard_url(self):
        """Get appropriate dashboard URL based on role"""
        if self.is_seller():
            return 'seller.dashboard'
        return 'buyer.dashboard'
    
    def update_last_activity(self):
        """Update last activity timestamp"""
        self.last_activity = datetime.utcnow()
        db.session.commit()
    
    def record_login(self):
        """Record successful login"""
        self.last_login = datetime.utcnow()
        self.last_activity = datetime.utcnow()
        self.login_count += 1
        db.session.commit()
    
    def is_session_expired(self, timeout_minutes=30):
        """Check if user session has expired"""
        if not self.last_activity:
            return True
        
        timeout = timedelta(minutes=timeout_minutes)
        return datetime.utcnow() - self.last_activity > timeout
    
    def get_id(self):
        """Required by Flask-Login"""
        return str(self.id)
    
    def is_authenticated(self):
        """Required by Flask-Login"""
        return True
    
    def is_anonymous(self):
        """Required by Flask-Login"""
        return False
    
    def __repr__(self):
        return f'<User {self.email} ({self.role.value})>'

# User loader function for Flask-Login
def load_user(user_id):
    """Load user by ID for Flask-Login"""
    try:
        user = User.query.get(int(user_id))
        if user and user.is_active:
            # Check session timeout
            if user.is_session_expired():
                return None
            # Update last activity
            user.update_last_activity()
            return user
        return None
    except (TypeError, ValueError):
        return None
