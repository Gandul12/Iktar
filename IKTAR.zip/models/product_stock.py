from database import db
from datetime import datetime
from sqlalchemy import event

class Product(db.Model):
    __tablename__ = 'products'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, nullable=False, default=0)
    min_stock = db.Column(db.Integer, default=5)  # Minimum stock threshold
    category = db.Column(db.String(50), nullable=False)
    image_url = db.Column(db.String(200))
    unit = db.Column(db.String(20), default='kg')
    is_active = db.Column(db.Boolean, default=True)
    seller_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    seller = db.relationship('User', backref=db.backref('products', lazy=True))
    
    def __repr__(self):
        return f'<Product {self.name}>'
    
    @property
    def is_in_stock(self):
        """Check if product is in stock"""
        return self.stock > 0 and self.is_active
    
    @property
    def is_low_stock(self):
        """Check if product stock is below minimum threshold"""
        return self.stock <= self.min_stock and self.stock > 0
    
    @property
    def stock_status(self):
        """Get stock status for display"""
        if self.stock == 0:
            return 'out_of_stock'
        elif self.is_low_stock:
            return 'low_stock'
        else:
            return 'in_stock'
    
    @property
    def stock_badge_class(self):
        """Get CSS class for stock badge"""
        status_classes = {
            'out_of_stock': 'bg-danger',
            'low_stock': 'bg-warning',
            'in_stock': 'bg-success'
        }
        return status_classes.get(self.stock_status, 'bg-secondary')
    
    @property
    def stock_badge_text(self):
        """Get text for stock badge"""
        if self.stock == 0:
            return 'Stok Habis'
        elif self.is_low_stock:
            return f'Stok Menipis ({self.stock})'
        else:
            return f'Stok: {self.stock}'
    
    def can_purchase(self, quantity):
        """Check if product can be purchased with given quantity"""
        return self.is_active and self.stock >= quantity
    
    def reduce_stock(self, quantity, transaction_detail_id=None, user_id=None):
        """Reduce product stock and create stock movement record"""
        if not self.can_purchase(quantity):
            raise ValueError(f"Insufficient stock. Available: {self.stock}, Requested: {quantity}")
        
        # Record stock movement
        from models.transaction_updated import StockMovement
        
        stock_before = self.stock
        self.stock -= quantity
        stock_after = self.stock
        
        # Create stock movement record
        movement = StockMovement(
            product_id=self.id,
            transaction_detail_id=transaction_detail_id,
            movement_type='sale',
            quantity_change=-quantity,
            stock_before=stock_before,
            stock_after=stock_after,
            notes=f'Stock reduced due to sale',
            created_by=user_id or 1  # Default to system user
        )
        
        db.session.add(movement)
        self.updated_at = datetime.utcnow()
        
        return True
    
    def increase_stock(self, quantity, movement_type='restock', notes=None, user_id=None):
        """Increase product stock and create stock movement record"""
        from models.transaction_updated import StockMovement
        
        stock_before = self.stock
        self.stock += quantity
        stock_after = self.stock
        
        # Create stock movement record
        movement = StockMovement(
            product_id=self.id,
            movement_type=movement_type,
            quantity_change=quantity,
            stock_before=stock_before,
            stock_after=stock_after,
            notes=notes or f'Stock increased via {movement_type}',
            created_by=user_id or 1
        )
        
        db.session.add(movement)
        self.updated_at = datetime.utcnow()
        
        return True

# Event listener to automatically deactivate products when stock reaches 0
@event.listens_for(Product.stock, 'set')
def product_stock_changed(target, value, oldvalue, initiator):
    """Automatically handle product status when stock changes"""
    if value == 0 and target.is_active:
        # Optionally auto-deactivate when stock is 0
        # target.is_active = False
        pass
