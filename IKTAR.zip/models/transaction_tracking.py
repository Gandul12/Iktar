from database import db
from datetime import datetime
from enum import Enum

class ShippingStatus(Enum):
    PROCESSED = "Diproses"
    SHIPPED = "Dikirim"
    DELIVERED = "Diterima"

class TrackingUpdate(db.Model):
    __tablename__ = 'tracking_updates'
    
    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.Integer, db.ForeignKey('transactions.id'), nullable=False)
    status = db.Column(db.Enum(ShippingStatus), nullable=False)
    notes = db.Column(db.Text)
    location = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    transaction = db.relationship('Transaction', backref=db.backref('tracking_updates', lazy=True, order_by='TrackingUpdate.created_at.desc()'))
    updater = db.relationship('User', backref=db.backref('tracking_updates', lazy=True))
    
    def __repr__(self):
        return f'<TrackingUpdate {self.id}: {self.status.value}>'
    
    @property
    def status_badge_class(self):
        status_classes = {
            ShippingStatus.PROCESSED: 'bg-info',
            ShippingStatus.SHIPPED: 'bg-primary',
            ShippingStatus.DELIVERED: 'bg-success'
        }
        return status_classes.get(self.status, 'bg-secondary')
    
    @property
    def status_icon(self):
        status_icons = {
            ShippingStatus.PROCESSED: 'fa-box',
            ShippingStatus.SHIPPED: 'fa-shipping-fast',
            ShippingStatus.DELIVERED: 'fa-check-circle'
        }
        return status_icons.get(self.status, 'fa-circle')
