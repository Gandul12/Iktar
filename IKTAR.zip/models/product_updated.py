from database import db
from datetime import datetime

class Product(db.Model):
    __tablename__ = 'products'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, nullable=False, default=0)
    category = db.Column(db.String(50), nullable=False)
    image_url = db.Column(db.String(200))
    unit = db.Column(db.String(20), default='kg')  # kg, ekor, pasang
    is_active = db.Column(db.Boolean, default=True)
    seller_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    seller = db.relationship('User', backref=db.backref('products', lazy=True))
    transactions = db.relationship('Transaction', backref='product', lazy=True)
    
    def __repr__(self):
        return f'<Product {self.name}>'
    
    @property
    def category_display(self):
        category_map = {
            'hias': 'Ikan Hias',
            'konsumsi': 'Ikan Konsumsi',
            'predator': 'Ikan Predator',
            'bibit': 'Bibit Ikan'
        }
        return category_map.get(self.category, self.category.title())
    
    @property
    def status_display(self):
        return 'Aktif' if self.is_active else 'Tidak Aktif'
    
    def can_be_deleted(self):
        """Check if product can be deleted (no transactions)"""
        from models.transaction import Transaction
        return not Transaction.query.filter_by(product_id=self.id).first()
