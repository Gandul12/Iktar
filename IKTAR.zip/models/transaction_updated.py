from database import db
from datetime import datetime
from enum import Enum

class TransactionStatus(Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    SHIPPED = "shipped"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"

class Transaction(db.Model):
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    transaction_date = db.Column(db.DateTime, default=datetime.utcnow)
    total_price = db.Column(db.Float, nullable=False)
    status = db.Column(db.Enum(TransactionStatus), default=TransactionStatus.PENDING)
    shipping_address = db.Column(db.Text)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    buyer = db.relationship('User', backref=db.backref('transactions', lazy=True))
    transaction_details = db.relationship('TransactionDetail', backref='transaction', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Transaction {self.id}>'
    
    @property
    def status_display(self):
        status_map = {
            TransactionStatus.PENDING: 'Menunggu Konfirmasi',
            TransactionStatus.CONFIRMED: 'Dikonfirmasi',
            TransactionStatus.SHIPPED: 'Dikirim',
            TransactionStatus.DELIVERED: 'Diterima',
            TransactionStatus.CANCELLED: 'Dibatalkan'
        }
        return status_map.get(self.status, self.status.value)
    
    def get_total_items(self):
        """Get total quantity of items in this transaction"""
        return sum(detail.quantity for detail in self.transaction_details)

class TransactionDetail(db.Model):
    __tablename__ = 'transaction_details'
    
    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.Integer, db.ForeignKey('transactions.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    unit_price = db.Column(db.Float, nullable=False)
    subtotal = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    product = db.relationship('Product', backref=db.backref('transaction_details', lazy=True))
    
    def __repr__(self):
        return f'<TransactionDetail {self.id}>'
    
    def calculate_subtotal(self):
        """Calculate subtotal for this detail"""
        return self.quantity * self.unit_price

class StockMovement(db.Model):
    __tablename__ = 'stock_movements'
    
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    transaction_detail_id = db.Column(db.Integer, db.ForeignKey('transaction_details.id'), nullable=True)
    movement_type = db.Column(db.String(20), nullable=False)  # 'sale', 'restock', 'adjustment'
    quantity_change = db.Column(db.Integer, nullable=False)  # Positive for increase, negative for decrease
    stock_before = db.Column(db.Integer, nullable=False)
    stock_after = db.Column(db.Integer, nullable=False)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Relationships
    product = db.relationship('Product', backref=db.backref('stock_movements', lazy=True))
    transaction_detail = db.relationship('TransactionDetail', backref=db.backref('stock_movement', uselist=False))
    user = db.relationship('User', backref=db.backref('stock_movements', lazy=True))
    
    def __repr__(self):
        return f'<StockMovement {self.id}>'
