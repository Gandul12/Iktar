from database import db
from datetime import datetime
from enum import Enum

class TransactionStatus(Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    PROCESSING = "processing"
    SHIPPED = "shipped"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"

class Transaction(db.Model):
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    status = db.Column(db.Enum(TransactionStatus), default=TransactionStatus.PENDING)
    
    # Customer Information
    customer_name = db.Column(db.String(100), nullable=False)
    customer_phone = db.Column(db.String(20), nullable=False)
    shipping_address = db.Column(db.Text, nullable=False)
    notes = db.Column(db.Text)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    buyer = db.relationship('User', backref=db.backref('transactions', lazy=True))
    transaction_details = db.relationship('TransactionDetail', backref='transaction', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Transaction {self.id}>'
    
    @property
    def status_display(self):
        status_map = {
            TransactionStatus.PENDING: 'Menunggu Konfirmasi',
            TransactionStatus.CONFIRMED: 'Dikonfirmasi',
            TransactionStatus.PROCESSING: 'Diproses',
            TransactionStatus.SHIPPED: 'Dikirim',
            TransactionStatus.DELIVERED: 'Diterima',
            TransactionStatus.CANCELLED: 'Dibatalkan'
        }
        return status_map.get(self.status, self.status.value)
    
    @property
    def status_badge_class(self):
        status_classes = {
            TransactionStatus.PENDING: 'bg-warning text-dark',
            TransactionStatus.CONFIRMED: 'bg-info',
            TransactionStatus.PROCESSING: 'bg-primary',
            TransactionStatus.SHIPPED: 'bg-secondary',
            TransactionStatus.DELIVERED: 'bg-success',
            TransactionStatus.CANCELLED: 'bg-danger'
        }
        return status_classes.get(self.status, 'bg-secondary')
    
    def get_total_items(self):
        """Get total quantity of items in this transaction"""
        return sum(detail.quantity for detail in self.transaction_details)
    
    def get_order_number(self):
        """Generate formatted order number"""
        return f"IKT-{self.created_at.strftime('%Y%m%d')}-{self.id:04d}"

class TransactionDetail(db.Model):
    __tablename__ = 'transaction_details'
    
    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.Integer, db.ForeignKey('transactions.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    unit_price = db.Column(db.Float, nullable=False)
    subtotal = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    product = db.relationship('Product', backref=db.backref('transaction_details', lazy=True))
    
    def __repr__(self):
        return f'<TransactionDetail {self.id}>'
    
    def calculate_subtotal(self):
        """Calculate subtotal for this detail"""
        return self.quantity * self.unit_price
