from app import db
from datetime import datetime

class ShippingAddress(db.Model):
    __tablename__ = 'shipping_addresses'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    recipient_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    address_line = db.Column(db.Text, nullable=False)
    district = db.Column(db.String(100), nullable=False)  # Kecamatan
    city = db.Column(db.String(100), nullable=False)      # Kota/Kabupaten
    province = db.Column(db.String(100), nullable=False)  # Provinsi
    postal_code = db.Column(db.String(10), nullable=False)
    is_default = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship
    user = db.relationship('User', backref=db.backref('shipping_addresses', lazy=True, cascade='all, delete-orphan'))
    
    def __repr__(self):
        return f'<ShippingAddress {self.recipient_name} - {self.city}>'
    
    @property
    def full_address(self):
        """Get formatted full address"""
        return f"{self.address_line}, {self.district}, {self.city}, {self.province} {self.postal_code}"
    
    @property
    def short_address(self):
        """Get shortened address for display"""
        address_parts = self.address_line.split(',')
        short_address = address_parts[0] if address_parts else self.address_line
        if len(short_address) > 50:
            short_address = short_address[:47] + "..."
        return f"{short_address}, {self.city}"
    
    def to_dict(self):
        """Convert to dictionary for JSON responses"""
        return {
            'id': self.id,
            'recipient_name': self.recipient_name,
            'phone': self.phone,
            'address_line': self.address_line,
            'district': self.district,
            'city': self.city,
            'province': self.province,
            'postal_code': self.postal_code,
            'is_default': self.is_default,
            'full_address': self.full_address,
            'short_address': self.short_address
        }
    
    @staticmethod
    def get_user_addresses(user_id):
        """Get all addresses for a user, ordered by default first"""
        return ShippingAddress.query.filter_by(user_id=user_id)\
                                  .order_by(ShippingAddress.is_default.desc(), 
                                           ShippingAddress.created_at.desc()).all()
    
    @staticmethod
    def get_default_address(user_id):
        """Get user's default address"""
        return ShippingAddress.query.filter_by(user_id=user_id, is_default=True).first()
    
    @staticmethod
    def set_as_default(address_id, user_id):
        """Set an address as default and unset others"""
        try:
            # First, unset all default addresses for this user
            ShippingAddress.query.filter_by(user_id=user_id)\
                                .update({'is_default': False})
            
            # Then set the specified address as default
            address = ShippingAddress.query.filter_by(id=address_id, user_id=user_id).first()
            if address:
                address.is_default = True
                db.session.commit()
                return True, "Alamat berhasil dijadikan default"
            else:
                db.session.rollback()
                return False, "Alamat tidak ditemukan"
        except Exception as e:
            db.session.rollback()
            return False, f"Gagal mengubah alamat default: {str(e)}"
    
    def save(self):
        """Save address to database"""
        try:
            # If this is set as default, unset other default addresses
            if self.is_default:
                ShippingAddress.query.filter_by(user_id=self.user_id)\
                                   .filter(ShippingAddress.id != self.id)\
                                   .update({'is_default': False})
            
            db.session.add(self)
            db.session.commit()
            return True, "Alamat berhasil disimpan"
        except Exception as e:
            db.session.rollback()
            return False, f"Gagal menyimpan alamat: {str(e)}"
    
    def delete(self):
        """Delete address from database"""
        try:
            # If this was the default address, set another as default
            if self.is_default:
                other_address = ShippingAddress.query.filter_by(user_id=self.user_id)\
                                                   .filter(ShippingAddress.id != self.id)\
                                                   .first()
                if other_address:
                    other_address.is_default = True
            
            db.session.delete(self)
            db.session.commit()
            return True, "Alamat berhasil dihapus"
        except Exception as e:
            db.session.rollback()
            return False, f"Gagal menghapus alamat: {str(e)}"

# Indonesian provinces for dropdown
INDONESIAN_PROVINCES = [
    'Aceh', 'Sumatera Utara', 'Sumatera Barat', 'Riau', 'Kepulauan Riau', 'Jambi',
    'Sumatera Selatan', 'Bangka Belitung', 'Bengkulu', 'Lampung', 'DKI Jakarta',
    'Jawa Barat', 'Jawa Tengah', 'DI Yogyakarta', 'Jawa Timur', 'Banten',
    'Bali', 'Nusa Tenggara Barat', 'Nusa Tenggara Timur', 'Kalimantan Barat',
    'Kalimantan Tengah', 'Kalimantan Selatan', 'Kalimantan Timur', 'Kalimantan Utara',
    'Sulawesi Utara', 'Sulawesi Tengah', 'Sulawesi Selatan', 'Sulawesi Tenggara',
    'Gorontalo', 'Sulawesi Barat', 'Maluku', 'Maluku Utara', 'Papua', 'Papua Barat',
    'Papua Selatan', 'Papua Tengah', 'Papua Pegunungan', 'Papua Barat Daya'
]
