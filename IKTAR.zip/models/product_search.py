from database import db
from datetime import datetime
from sqlalchemy import or_, and_, func

class Product(db.Model):
    __tablename__ = 'products'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, index=True)  # Add index for search
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False, index=True)  # Add index for price filter
    stock = db.Column(db.Integer, nullable=False, default=0)
    min_stock = db.Column(db.Integer, default=5)
    category = db.Column(db.String(50), nullable=False, index=True)  # Add index for category filter
    image_url = db.Column(db.String(200))
    unit = db.Column(db.String(20), default='kg')
    is_active = db.Column(db.Boolean, default=True, index=True)  # Add index for active filter
    seller_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    seller = db.relationship('User', backref=db.backref('products', lazy=True))
    
    def __repr__(self):
        return f'<Product {self.name}>'
    
    @property
    def category_display(self):
        category_map = {
            'hias': 'Ikan Hias',
            'konsumsi': 'Ikan Konsumsi',
            'predator': 'Ikan Predator',
            'bibit': 'Bibit Ikan'
        }
        return category_map.get(self.category, self.category.title())
    
    @property
    def is_in_stock(self):
        return self.stock > 0 and self.is_active
    
    @property
    def is_low_stock(self):
        return self.stock <= self.min_stock and self.stock > 0
    
    @property
    def stock_status(self):
        if self.stock == 0:
            return 'out_of_stock'
        elif self.is_low_stock:
            return 'low_stock'
        else:
            return 'in_stock'
    
    @property
    def stock_badge_class(self):
        status_classes = {
            'out_of_stock': 'bg-danger',
            'low_stock': 'bg-warning text-dark',
            'in_stock': 'bg-success'
        }
        return status_classes.get(self.stock_status, 'bg-secondary')
    
    @property
    def stock_badge_text(self):
        if self.stock == 0:
            return 'Stok Habis'
        elif self.is_low_stock:
            return f'Stok Menipis ({self.stock})'
        else:
            return f'Stok: {self.stock}'
    
    @classmethod
    def search_and_filter(cls, search_query=None, category=None, price_min=None, 
                         price_max=None, sort_by='name', sort_order='asc', 
                         only_in_stock=False, page=1, per_page=12):
        """
        Advanced search and filter method
        """
        query = cls.query.filter(cls.is_active == True)
        
        # Search by name and description
        if search_query:
            search_term = f"%{search_query.strip()}%"
            query = query.filter(
                or_(
                    cls.name.ilike(search_term),
                    cls.description.ilike(search_term)
                )
            )
        
        # Filter by category
        if category and category != 'all':
            query = query.filter(cls.category == category)
        
        # Filter by price range
        if price_min is not None:
            try:
                price_min = float(price_min)
                query = query.filter(cls.price >= price_min)
            except (ValueError, TypeError):
                pass
        
        if price_max is not None:
            try:
                price_max = float(price_max)
                query = query.filter(cls.price <= price_max)
            except (ValueError, TypeError):
                pass
        
        # Filter only products in stock
        if only_in_stock:
            query = query.filter(cls.stock > 0)
        
        # Sorting
        if sort_by == 'price':
            if sort_order == 'desc':
                query = query.order_by(cls.price.desc())
            else:
                query = query.order_by(cls.price.asc())
        elif sort_by == 'stock':
            if sort_order == 'desc':
                query = query.order_by(cls.stock.desc())
            else:
                query = query.order_by(cls.stock.asc())
        elif sort_by == 'created_at':
            if sort_order == 'desc':
                query = query.order_by(cls.created_at.desc())
            else:
                query = query.order_by(cls.created_at.asc())
        else:  # Default: sort by name
            if sort_order == 'desc':
                query = query.order_by(cls.name.desc())
            else:
                query = query.order_by(cls.name.asc())
        
        # Pagination
        return query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
    
    @classmethod
    def get_categories(cls):
        """Get all available categories"""
        return db.session.query(cls.category).distinct().all()
    
    @classmethod
    def get_price_range(cls):
        """Get min and max price for price range filter"""
        result = db.session.query(
            func.min(cls.price).label('min_price'),
            func.max(cls.price).label('max_price')
        ).filter(cls.is_active == True).first()
        
        return {
            'min_price': result.min_price or 0,
            'max_price': result.max_price or 100000
        }
    
    @classmethod
    def get_search_suggestions(cls, query, limit=5):
        """Get search suggestions based on partial query"""
        if not query or len(query) < 2:
            return []
        
        search_term = f"%{query.strip()}%"
        results = cls.query.filter(
            and_(
                cls.is_active == True,
                cls.name.ilike(search_term)
            )
        ).limit(limit).all()
        
        return [product.name for product in results]
