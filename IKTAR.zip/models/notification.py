from database import db
from datetime import datetime
from enum import Enum

class NotificationType(Enum):
    TRANSACTION_STATUS = "transaction_status"
    ORDER_CONFIRMED = "order_confirmed"
    ORDER_SHIPPED = "order_shipped"
    ORDER_DELIVERED = "order_delivered"
    ORDER_CANCELLED = "order_cancelled"
    PAYMENT_RECEIVED = "payment_received"
    STOCK_ALERT = "stock_alert"

class TransactionStatus(Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    PROCESSING = "processing"
    SHIPPED = "shipped"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"

class Notification(db.Model):
    __tablename__ = 'notifications'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    transaction_id = db.Column(db.Integer, db.ForeignKey('transactions.id'), nullable=True)
    type = db.Column(db.Enum(NotificationType), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    read_at = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('notifications', lazy=True))
    transaction = db.relationship('Transaction', backref=db.backref('notifications', lazy=True))
    
    def __repr__(self):
        return f'<Notification {self.id}: {self.title}>'
    
    @property
    def icon_class(self):
        """Get icon class based on notification type"""
        icon_map = {
            NotificationType.TRANSACTION_STATUS: 'fas fa-info-circle',
            NotificationType.ORDER_CONFIRMED: 'fas fa-check-circle text-success',
            NotificationType.ORDER_SHIPPED: 'fas fa-shipping-fast text-primary',
            NotificationType.ORDER_DELIVERED: 'fas fa-box-open text-success',
            NotificationType.ORDER_CANCELLED: 'fas fa-times-circle text-danger',
            NotificationType.PAYMENT_RECEIVED: 'fas fa-credit-card text-success',
            NotificationType.STOCK_ALERT: 'fas fa-exclamation-triangle text-warning'
        }
        return icon_map.get(self.type, 'fas fa-bell')
    
    @property
    def time_ago(self):
        """Get human readable time difference"""
        now = datetime.utcnow()
        diff = now - self.created_at
        
        if diff.days > 0:
            return f"{diff.days} hari yang lalu"
        elif diff.seconds > 3600:
            hours = diff.seconds // 3600
            return f"{hours} jam yang lalu"
        elif diff.seconds > 60:
            minutes = diff.seconds // 60
            return f"{minutes} menit yang lalu"
        else:
            return "Baru saja"
    
    def mark_as_read(self):
        """Mark notification as read"""
        if not self.is_read:
            self.is_read = True
            self.read_at = datetime.utcnow()
            db.session.commit()

# Update Transaction model with status
class TransactionStatusUpdate(db.Model):
    __tablename__ = 'transaction_status_updates'
    
    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.Integer, db.ForeignKey('transactions.id'), nullable=False)
    old_status = db.Column(db.Enum(TransactionStatus), nullable=True)
    new_status = db.Column(db.Enum(TransactionStatus), nullable=False)
    updated_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    transaction = db.relationship('Transaction', backref=db.backref('status_updates', lazy=True))
    updater = db.relationship('User', backref=db.backref('status_updates', lazy=True))
    
    def __repr__(self):
        return f'<StatusUpdate {self.id}: {self.old_status} -> {self.new_status}>'
