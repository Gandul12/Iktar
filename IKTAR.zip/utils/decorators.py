from functools import wraps
from flask import abort, redirect, url_for, flash, request, session, current_app
from flask_login import current_user, login_required
from models.user import UserRole
from datetime import datetime, timedelta

def role_required(*roles):
    """
    Decorator to require specific roles for accessing routes
    Usage: @role_required('buyer') or @role_required('seller')
    """
    def decorator(f):
        @wraps(f)
        @login_required
        def decorated_function(*args, **kwargs):
            # Check if user is authenticated
            if not current_user.is_authenticated:
                flash('Silakan login terlebih dahulu.', 'warning')
                return redirect(url_for('auth.login', next=request.url))
            
            # Check if user is active
            if not current_user.is_active:
                flash('Akun Anda telah dinonaktifkan.', 'error')
                return redirect(url_for('auth.login'))
            
            # Convert string roles to UserRole enum
            required_roles = []
            for role in roles:
                if isinstance(role, str):
                    if role == 'buyer':
                        required_roles.append(UserRole.BUYER)
                    elif role == 'seller':
                        required_roles.append(UserRole.SELLER)
                else:
                    required_roles.append(role)
            
            # Check if user has required role
            if current_user.role not in required_roles:
                flash('Anda tidak memiliki akses ke halaman ini.', 'error')
                # Redirect to appropriate dashboard
                if current_user.is_seller():
                    return redirect(url_for('seller.dashboard'))
                else:
                    return redirect(url_for('buyer.dashboard'))
            
            # Update last activity
            current_user.update_last_activity()
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def buyer_required(f):
    """Decorator to require buyer role"""
    return role_required('buyer')(f)

def seller_required(f):
    """Decorator to require seller role"""
    return role_required('seller')(f)

def anonymous_required(f):
    """Decorator to require user to be anonymous (not logged in)"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if current_user.is_authenticated:
            flash('Anda sudah login.', 'info')
            # Redirect to appropriate dashboard
            if current_user.is_seller():
                return redirect(url_for('seller.dashboard'))
            else:
                return redirect(url_for('buyer.dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def session_timeout_check(f):
    """Decorator to check session timeout"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if current_user.is_authenticated:
            # Check session timeout
            timeout_minutes = current_app.config.get('PERMANENT_SESSION_LIFETIME', timedelta(minutes=30)).total_seconds() / 60
            
            if current_user.is_session_expired(timeout_minutes):
                from flask_login import logout_user
                logout_user()
                session.clear()
                flash('Sesi Anda telah berakhir. Silakan login kembali.', 'warning')
                return redirect(url_for('auth.login'))
        
        return f(*args, **kwargs)
    return decorated_function
