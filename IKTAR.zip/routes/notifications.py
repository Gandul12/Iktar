from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for, flash
from services.notification_service import NotificationService
from functools import wraps

notifications_bp = Blueprint('notifications', __name__)

def buyer_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Silakan login terlebih dahulu', 'error')
            return redirect(url_for('auth.login'))
        
        if session.get('user_role') != 'buyer':
            flash('Akses ditolak. Hanya pembeli yang dapat mengakses halaman ini.', 'error')
            return redirect(url_for('home'))
        
        return f(*args, **kwargs)
    return decorated_function

@notifications_bp.route('/notifikasi')
@buyer_required
def notifications():
    """Display notifications page for buyer"""
    user_id = session['user_id']
    
    # Get all notifications
    all_notifications = NotificationService.get_user_notifications(user_id)
    unread_notifications = NotificationService.get_user_notifications(user_id, unread_only=True)
    unread_count = NotificationService.get_unread_count(user_id)
    
    return render_template('buyer/notifications.html',
                         notifications=all_notifications,
                         unread_notifications=unread_notifications,
                         unread_count=unread_count)

@notifications_bp.route('/api/notifications/unread-count')
@buyer_required
def get_unread_count():
    """API endpoint to get unread notification count"""
    user_id = session['user_id']
    count = NotificationService.get_unread_count(user_id)
    return jsonify({'count': count})

@notifications_bp.route('/api/notifications/<int:notification_id>/read', methods=['POST'])
@buyer_required
def mark_notification_read(notification_id):
    """Mark a notification as read"""
    user_id = session['user_id']
    
    success = NotificationService.mark_as_read(notification_id, user_id)
    
    if success:
        return jsonify({'success': True, 'message': 'Notifikasi ditandai sudah dibaca'})
    else:
        return jsonify({'success': False, 'message': 'Notifikasi tidak ditemukan'}), 404

@notifications_bp.route('/api/notifications/mark-all-read', methods=['POST'])
@buyer_required
def mark_all_notifications_read():
    """Mark all notifications as read"""
    user_id = session['user_id']
    
    try:
        count = NotificationService.mark_all_as_read(user_id)
        return jsonify({
            'success': True, 
            'message': f'{count} notifikasi ditandai sudah dibaca',
            'count': count
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@notifications_bp.route('/api/notifications/latest')
@buyer_required
def get_latest_notifications():
    """Get latest notifications for real-time updates"""
    user_id = session['user_id']
    
    notifications = NotificationService.get_user_notifications(user_id, limit=10)
    unread_count = NotificationService.get_unread_count(user_id)
    
    notifications_data = []
    for notification in notifications:
        notifications_data.append({
            'id': notification.id,
            'title': notification.title,
            'message': notification.message,
            'is_read': notification.is_read,
            'time_ago': notification.time_ago,
            'icon_class': notification.icon_class,
            'created_at': notification.created_at.isoformat()
        })
    
    return jsonify({
        'notifications': notifications_data,
        'unread_count': unread_count
    })
