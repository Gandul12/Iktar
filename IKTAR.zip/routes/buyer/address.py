from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from functools import wraps
from services.address_service import AddressService
from models.shipping_address import ShippingAddress, INDONESIAN_PROVINCES

address_routes = Blueprint('address_routes', __name__, url_prefix='/buyer')

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Silakan login terlebih dahulu.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def buyer_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_role' not in session or session['user_role'] != 'buyer':
            flash('Akses ditolak. Halaman ini hanya untuk pembeli.', 'error')
            return redirect(url_for('home'))
        return f(*args, **kwargs)
    return decorated_function

@address_routes.route('/alamat')
@login_required
@buyer_required
def address_list():
    """Display list of user's shipping addresses"""
    user_id = session['user_id']
    addresses = AddressService.get_user_addresses(user_id)
    
    return render_template('buyer/address_list.html', 
                         addresses=addresses,
                         total_addresses=len(addresses))

@address_routes.route('/alamat/tambah', methods=['GET', 'POST'])
@login_required
@buyer_required
def add_address():
    """Add new shipping address"""
    if request.method == 'POST':
        user_id = session['user_id']
        
        # Get form data
        form_data = {
            'recipient_name': request.form.get('recipient_name', ''),
            'phone': request.form.get('phone', ''),
            'address_line': request.form.get('address_line', ''),
            'district': request.form.get('district', ''),
            'city': request.form.get('city', ''),
            'province': request.form.get('province', ''),
            'postal_code': request.form.get('postal_code', ''),
            'is_default': 'is_default' in request.form
        }
        
        # Create address
        success, address, errors = AddressService.create_address(form_data, user_id)
        
        if success:
            flash('Alamat berhasil ditambahkan!', 'success')
            return redirect(url_for('address_routes.address_list'))
        else:
            for error in errors:
                flash(error, 'error')
            return render_template('buyer/address_form.html',
                                 form_data=form_data,
                                 provinces=INDONESIAN_PROVINCES,
                                 form_title='Tambah Alamat Baru',
                                 form_action=url_for('address_routes.add_address'))
    
    # GET request - show form
    form_data = {
        'recipient_name': '',
        'phone': '',
        'address_line': '',
        'district': '',
        'city': '',
        'province': '',
        'postal_code': '',
        'is_default': False
    }
    
    return render_template('buyer/address_form.html',
                         form_data=form_data,
                         provinces=INDONESIAN_PROVINCES,
                         form_title='Tambah Alamat Baru',
                         form_action=url_for('address_routes.add_address'))

@address_routes.route('/alamat/edit/<int:address_id>', methods=['GET', 'POST'])
@login_required
@buyer_required
def edit_address(address_id):
    """Edit existing shipping address"""
    user_id = session['user_id']
    
    # Get address
    address = ShippingAddress.query.filter_by(id=address_id, user_id=user_id).first()
    if not address:
        flash('Alamat tidak ditemukan.', 'error')
        return redirect(url_for('address_routes.address_list'))
    
    if request.method == 'POST':
        # Get form data
        form_data = {
            'recipient_name': request.form.get('recipient_name', ''),
            'phone': request.form.get('phone', ''),
            'address_line': request.form.get('address_line', ''),
            'district': request.form.get('district', ''),
            'city': request.form.get('city', ''),
            'province': request.form.get('province', ''),
            'postal_code': request.form.get('postal_code', ''),
            'is_default': 'is_default' in request.form
        }
        
        # Update address
        success, updated_address, errors = AddressService.update_address(address_id, form_data, user_id)
        
        if success:
            flash('Alamat berhasil diperbarui!', 'success')
            return redirect(url_for('address_routes.address_list'))
        else:
            for error in errors:
                flash(error, 'error')
            return render_template('buyer/address_form.html',
                                 form_data=form_data,
                                 provinces=INDONESIAN_PROVINCES,
                                 form_title='Edit Alamat',
                                 form_action=url_for('address_routes.edit_address', address_id=address_id),
                                 address=address)
    
    # GET request - show form with existing data
    form_data = {
        'recipient_name': address.recipient_name,
        'phone': address.phone,
        'address_line': address.address_line,
        'district': address.district,
        'city': address.city,
        'province': address.province,
        'postal_code': address.postal_code,
        'is_default': address.is_default
    }
    
    return render_template('buyer/address_form.html',
                         form_data=form_data,
                         provinces=INDONESIAN_PROVINCES,
                         form_title='Edit Alamat',
                         form_action=url_for('address_routes.edit_address', address_id=address_id),
                         address=address)

@address_routes.route('/alamat/hapus/<int:address_id>', methods=['POST'])
@login_required
@buyer_required
def delete_address(address_id):
    """Delete shipping address"""
    user_id = session['user_id']
    
    success, message = AddressService.delete_address(address_id, user_id)
    
    if success:
        flash('Alamat berhasil dihapus.', 'success')
    else:
        flash(message, 'error')
    
    return redirect(url_for('address_routes.address_list'))

@address_routes.route('/alamat/set-default/<int:address_id>', methods=['POST'])
@login_required
@buyer_required
def set_default_address(address_id):
    """Set address as default"""
    user_id = session['user_id']
    
    success, message = AddressService.set_default_address(address_id, user_id)
    
    if success:
        flash('Alamat default berhasil diubah.', 'success')
    else:
        flash(message, 'error')
    
    return redirect(url_for('address_routes.address_list'))

@address_routes.route('/api/alamat')
@login_required
@buyer_required
def api_get_addresses():
    """API endpoint to get user addresses for checkout"""
    user_id = session['user_id']
    address_data = AddressService.get_address_for_checkout(user_id)
    
    return jsonify({
        'success': True,
        'addresses': [addr.to_dict() for addr in address_data['addresses']],
        'default_address': address_data['default_address'].to_dict() if address_data['default_address'] else None,
        'has_addresses': address_data['has_addresses']
    })

@address_routes.route('/api/alamat/<int:address_id>')
@login_required
@buyer_required
def api_get_address(address_id):
    """API endpoint to get specific address"""
    user_id = session['user_id']
    address = ShippingAddress.query.filter_by(id=address_id, user_id=user_id).first()
    
    if not address:
        return jsonify({'success': False, 'message': 'Alamat tidak ditemukan'}), 404
    
    return jsonify({
        'success': True,
        'address': address.to_dict()
    })
