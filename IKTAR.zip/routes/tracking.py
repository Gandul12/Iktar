from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for, flash
from services.tracking_service import TrackingService
from models.transaction_tracking import ShippingStatus
from utils.decorators import login_required, role_required
from functools import wraps
from datetime import datetime

tracking_bp = Blueprint('tracking', __name__)

def transaction_owner_required(f):
    @wraps(f)
    def decorated_function(transaction_id, *args, **kwargs):
        if 'user_id' not in session:
            flash('Silakan login terlebih dahulu', 'error')
            return redirect(url_for('auth.login'))
        
        user_id = session['user_id']
        user_role = session.get('user_role')
        
        # Get tracking data
        tracking_data, error = TrackingService.get_transaction_tracking(transaction_id)
        
        if error:
            flash(error, 'error')
            return redirect(url_for('home'))
        
        transaction = tracking_data['transaction']
        
        # Check if user is buyer of this transaction
        if user_role == 'buyer' and transaction.buyer_id == user_id:
            return f(transaction_id, *args, **kwargs)
        
        # Check if user is seller of any product in this transaction
        if user_role == 'seller':
            seller_owns_transaction = any(
                detail.product.seller_id == user_id 
                for detail in transaction.transaction_details
            )
            if seller_owns_transaction:
                return f(transaction_id, *args, **kwargs)
        
        flash('Anda tidak memiliki akses ke transaksi ini', 'error')
        if user_role == 'buyer':
            return redirect(url_for('transactions.buyer_transactions'))
        else:
            return redirect(url_for('transaction_status.seller_transactions'))
    
    return decorated_function

@tracking_bp.route('/tracking/<int:transaction_id>')
@login_required
@transaction_owner_required
def tracking_page(transaction_id):
    """Display tracking information for a transaction"""
    tracking_data, error = TrackingService.get_transaction_tracking(transaction_id)
    
    if error:
        flash(error, 'error')
        return redirect(url_for('home'))
    
    # Get all possible statuses for progress bar
    all_statuses = list(ShippingStatus)
    
    # Calculate progress percentage
    current_status = tracking_data['current_status']
    current_index = all_statuses.index(current_status)
    progress_percentage = int((current_index + 1) / len(all_statuses) * 100)
    
    return render_template('tracking.html',
                         tracking_data=tracking_data,
                         all_statuses=all_statuses,
                         current_status=current_status,
                         progress_percentage=progress_percentage,
                         ShippingStatus=ShippingStatus)

@tracking_bp.route('/seller/transaction/<int:transaction_id>/update-status', methods=['GET', 'POST'])
@login_required
@role_required('seller')
@transaction_owner_required
def update_shipping_status(transaction_id):
    """Update shipping status for a transaction"""
    tracking_data, error = TrackingService.get_transaction_tracking(transaction_id)
    
    if error:
        flash(error, 'error')
        return redirect(url_for('transaction_status.seller_transactions'))
    
    current_status = tracking_data['current_status']
    available_transitions = TrackingService.get_available_status_transitions(current_status)
    dummy_locations = TrackingService.get_dummy_tracking_locations()
    
    if request.method == 'POST':
        new_status = request.form.get('status')
        notes = request.form.get('notes', '').strip()
        location = request.form.get('location', '').strip()
        
        success, message = TrackingService.update_shipping_status(
            transaction_id, new_status, session['user_id'], notes, location
        )
        
        if success:
            flash(message, 'success')
            return redirect(url_for('tracking.tracking_page', transaction_id=transaction_id))
        else:
            flash(message, 'error')
    
    return render_template('seller/update_status.html',
                         tracking_data=tracking_data,
                         available_transitions=available_transitions,
                         dummy_locations=dummy_locations)

@tracking_bp.route('/api/tracking/<int:transaction_id>/updates')
@login_required
@transaction_owner_required
def get_tracking_updates(transaction_id):
    """Get tracking updates for a transaction (API endpoint)"""
    tracking_data, error = TrackingService.get_transaction_tracking(transaction_id)
    
    if error:
        return jsonify({'error': error}), 400
    
    updates = []
    for update in tracking_data['tracking_updates']:
        updates.append({
            'id': update.id,
            'status': update.status.value,
            'notes': update.notes,
            'location': update.location,
            'created_at': update.created_at.isoformat(),
            'updated_by': update.updater.name if update.updater else 'System'
        })
    
    return jsonify({
        'transaction_id': transaction_id,
        'current_status': tracking_data['current_status'].value,
        'updates': updates
    })
