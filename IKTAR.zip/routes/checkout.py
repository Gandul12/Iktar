from flask import Blueprint, render_template, session, redirect, url_for, flash, request, jsonify
from functools import wraps
from services.stock_service import StockService
from models.product_stock import Product
from models.transaction_updated import Transaction, TransactionDetail
from models.user import User
import json

checkout = Blueprint('checkout', __name__)

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Silakan login terlebih dahulu.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def buyer_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_role' not in session or session['user_role'] != 'buyer':
            flash('Akses ditolak. Halaman ini hanya untuk pembeli.', 'error')
            return redirect(url_for('home'))
        return f(*args, **kwargs)
    return decorated_function

@checkout.route('/cart')
@login_required
@buyer_required
def view_cart():
    """Display shopping cart with stock validation"""
    cart = session.get('cart', [])
    
    if not cart:
        return render_template('cart_empty.html')
    
    # Validate cart items and get updated information
    is_available, unavailable_items, updated_cart = StockService.check_cart_availability(cart)
    
    # Get full product information for cart items
    cart_products = []
    total_price = 0
    
    for item in updated_cart:
        product = Product.query.get(item['id'])
        if product:
            item_total = product.price * item['quantity']
            total_price += item_total
            
            cart_products.append({
                'product': product,
                'quantity': item['quantity'],
                'subtotal': item_total,
                'max_available': item.get('max_available', product.stock)
            })
    
    return render_template('cart.html', 
                         cart_products=cart_products,
                         total_price=total_price,
                         unavailable_items=unavailable_items,
                         has_issues=len(unavailable_items) > 0)

@checkout.route('/add-to-cart', methods=['POST'])
@login_required
@buyer_required
def add_to_cart():
    """Add product to cart with stock validation"""
    data = request.get_json()
    product_id = data.get('product_id')
    quantity = data.get('quantity', 1)
    
    try:
        quantity = int(quantity)
        if quantity <= 0:
            return jsonify({'success': False, 'message': 'Quantity must be positive'})
    except (ValueError, TypeError):
        return jsonify({'success': False, 'message': 'Invalid quantity'})
    
    product = Product.query.get(product_id)
    if not product:
        return jsonify({'success': False, 'message': 'Product not found'})
    
    if not product.is_active:
        return jsonify({'success': False, 'message': 'Product is not available'})
    
    # Get current cart
    cart = session.get('cart', [])
    
    # Check if product already in cart
    existing_item = None
    for item in cart:
        if item['id'] == product_id:
            existing_item = item
            break
    
    if existing_item:
        new_quantity = existing_item['quantity'] + quantity
    else:
        new_quantity = quantity
    
    # Check stock availability
    if not product.can_purchase(new_quantity):
        return jsonify({
            'success': False, 
            'message': f'Insufficient stock. Available: {product.stock}, Requested: {new_quantity}'
        })
    
    # Update cart
    if existing_item:
        existing_item['quantity'] = new_quantity
    else:
        cart.append({
            'id': product_id,
            'name': product.name,
            'price': product.price,
            'quantity': quantity,
            'image_url': product.image_url
        })
    
    session['cart'] = cart
    session.modified = True
    
    # Calculate cart totals
    cart_count = sum(item['quantity'] for item in cart)
    cart_total = sum(item['price'] * item['quantity'] for item in cart)
    
    return jsonify({
        'success': True,
        'message': f'{product.name} added to cart',
        'cart_count': cart_count,
        'cart_total': cart_total
    })

@checkout.route('/update-cart', methods=['POST'])
@login_required
@buyer_required
def update_cart():
    """Update cart item quantity with stock validation"""
    data = request.get_json()
    product_id = data.get('product_id')
    quantity = data.get('quantity', 0)
    
    try:
        quantity = int(quantity)
        if quantity < 0:
            return jsonify({'success': False, 'message': 'Quantity cannot be negative'})
    except (ValueError, TypeError):
        return jsonify({'success': False, 'message': 'Invalid quantity'})
    
    cart = session.get('cart', [])
    
    # Find and update item
    for i, item in enumerate(cart):
        if item['id'] == product_id:
            if quantity == 0:
                # Remove item from cart
                cart.pop(i)
            else:
                # Validate stock
                product = Product.query.get(product_id)
                if not product or not product.can_purchase(quantity):
                    available_stock = product.stock if product else 0
                    return jsonify({
                        'success': False,
                        'message': f'Insufficient stock. Available: {available_stock}'
                    })
                
                # Update quantity
                item['quantity'] = quantity
            break
    
    session['cart'] = cart
    session.modified = True
    
    # Calculate new totals
    cart_count = sum(item['quantity'] for item in cart)
    cart_total = sum(item['price'] * item['quantity'] for item in cart)
    
    return jsonify({
        'success': True,
        'cart_count': cart_count,
        'cart_total': cart_total
    })

@checkout.route('/checkout', methods=['GET', 'POST'])
@login_required
@buyer_required
def checkout_process():
    """Process checkout"""
    cart = session.get('cart', [])
    
    if not cart:
        flash('Keranjang belanja kosong.', 'error')
        return redirect(url_for('view_cart'))
    
    if request.method == 'POST':
        shipping_address = request.form.get('shipping_address', '').strip()
        notes = request.form.get('notes', '').strip()
        
        if not shipping_address:
            flash('Alamat pengiriman wajib diisi.', 'error')
            return render_template('checkout.html', cart=cart)
        
        # Process checkout
        success, transaction_id, error_message = StockService.process_checkout(
            cart, 
            session['user_id'], 
            shipping_address, 
            notes
        )
        
        if success:
            # Clear cart
            session.pop('cart', None)
            session.modified = True
            
            flash('Pesanan berhasil dibuat! Terima kasih atas pembelian Anda.', 'success')
            return redirect(url_for('transaction_detail', id=transaction_id))
        else:
            flash(f'Checkout gagal: {error_message}', 'error')
            return redirect(url_for('view_cart'))
    
    # GET request - show checkout form
    # Validate cart one more time
    is_available, unavailable_items, updated_cart = StockService.check_cart_availability(cart)
    
    if not is_available:
        flash('Beberapa item di keranjang tidak tersedia. Silakan periksa kembali.', 'error')
        return redirect(url_for('view_cart'))
    
    # Calculate totals
    cart_products = []
    total_price = 0
    
    for item in cart:
        product = Product.query.get(item['id'])
        if product:
            subtotal = product.price * item['quantity']
            total_price += subtotal
            cart_products.append({
                'product': product,
                'quantity': item['quantity'],
                'subtotal': subtotal
            })
    
    return render_template('checkout.html', 
                         cart_products=cart_products,
                         total_price=total_price)

@checkout.route('/check-stock/<int:product_id>')
def check_product_stock(product_id):
    """API endpoint to check product stock"""
    product = Product.query.get(product_id)
    
    if not product:
        return jsonify({'error': 'Product not found'}), 404
    
    return jsonify({
        'product_id': product.id,
        'stock': product.stock,
        'is_in_stock': product.is_in_stock,
        'is_low_stock': product.is_low_stock,
        'stock_status': product.stock_status,
        'min_stock': product.min_stock
    })

@checkout.route('/transaction/<int:id>')
@login_required
def transaction_detail(id):
    """View transaction detail"""
    transaction = Transaction.query.get_or_404(id)
    
    # Check if user can view this transaction
    if transaction.buyer_id != session['user_id'] and session.get('user_role') != 'admin':
        # Allow sellers to view transactions for their products
        if session.get('user_role') == 'seller':
            seller_product_ids = [p.id for p in Product.query.filter_by(seller_id=session['user_id']).all()]
            transaction_product_ids = [d.product_id for d in transaction.transaction_details]
            
            if not any(pid in seller_product_ids for pid in transaction_product_ids):
                flash('Anda tidak memiliki akses untuk melihat transaksi ini.', 'error')
                return redirect(url_for('home'))
        else:
            flash('Anda tidak memiliki akses untuk melihat transaksi ini.', 'error')
            return redirect(url_for('home'))
    
    return render_template('transaction_detail.html', transaction=transaction)
