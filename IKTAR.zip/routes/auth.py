from flask import Blueprint, render_template, redirect, url_for, flash, request, session, current_app
from flask_login import login_user, logout_user, login_required, current_user
from models.user import User, UserRole, db
from forms.auth_forms import (RegistrationForm, LoginForm, ChangePasswordForm, 
                             ForgotPasswordForm, ResetPasswordForm)
from services.token_service import TokenService
from services.email_service import EmailService
from utils.decorators import anonymous_required, session_timeout_check
from datetime import datetime, timedelta
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.before_request
@session_timeout_check
def check_session_timeout():
    """Check session timeout before each request"""
    pass

@auth_bp.route('/register', methods=['GET', 'POST'])
@anonymous_required
def register():
    """User registration with enhanced validation"""
    form = RegistrationForm()
    
    if form.validate_on_submit():
        try:
            # Create new user
            role = UserRole.BUYER if form.role.data == 'buyer' else UserRole.SELLER
            user = User(
                name=form.name.data.strip(),
                email=form.email.data.lower().strip(),
                password=form.password.data,
                role=role
            )
            
            # Save to database
            db.session.add(user)
            db.session.commit()
            
            # Log the registration
            logger.info(f"New user registered: {user.email} as {user.role.value}")
            
            # Auto-login after registration
            login_user(user, remember=True)
            user.record_login()
            
            # Set session data
            session.permanent = True
            session['user_id'] = user.id
            session['user_name'] = user.name
            session['user_role'] = user.role.value
            session['login_time'] = datetime.utcnow().isoformat()
            
            flash(f'Selamat datang, {user.name}! Akun Anda berhasil dibuat.', 'success')
            
            # Redirect based on role
            if user.is_seller():
                return redirect(url_for('seller.dashboard'))
            else:
                return redirect(url_for('buyer.dashboard'))
                
        except Exception as e:
            db.session.rollback()
            logger.error(f"Registration error: {e}")
            flash('Terjadi kesalahan saat membuat akun. Silakan coba lagi.', 'error')
    
    return render_template('auth/register.html', form=form)

@auth_bp.route('/login', methods=['GET', 'POST'])
@anonymous_required
def login():
    """User login with enhanced security"""
    form = LoginForm()
    
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data.lower().strip()).first()
        
        if user and user.check_password(form.password.data):
            if not user.is_active:
                flash('Akun Anda telah dinonaktifkan. Hubungi administrator.', 'error')
                logger.warning(f"Login attempt on inactive account: {user.email}")
                return render_template('auth/login.html', form=form)
            
            # Log the user in
            remember_me = form.remember_me.data
            login_user(user, remember=remember_me)
            user.record_login()
            
            # Set session data
            session.permanent = True
            session['user_id'] = user.id
            session['user_name'] = user.name
            session['user_role'] = user.role.value
            session['login_time'] = datetime.utcnow().isoformat()
            
            # Log successful login
            logger.info(f"User logged in: {user.email} (remember: {remember_me})")
            
            flash(f'Selamat datang kembali, {user.name}!', 'success')
            
            # Redirect to next page or dashboard
            next_page = request.args.get('next')
            if next_page and next_page.startswith('/'):
                return redirect(next_page)
            
            # Redirect based on role
            if user.is_seller():
                return redirect(url_for('seller.dashboard'))
            else:
                return redirect(url_for('buyer.dashboard'))
        else:
            # Log failed login attempt
            logger.warning(f"Failed login attempt for email: {form.email.data}")
            flash('Email atau password salah. Silakan coba lagi.', 'error')
    
    return render_template('auth/login.html', form=form)

@auth_bp.route('/logout')
@login_required
def logout():
    """Enhanced logout with session cleanup"""
    user_name = current_user.name if current_user.is_authenticated else 'User'
    user_email = current_user.email if current_user.is_authenticated else 'Unknown'
    
    # Log the logout
    logger.info(f"User logged out: {user_email}")
    
    # Logout user
    logout_user()
    
    # Clear all session data
    session.clear()
    
    flash(f'Sampai jumpa, {user_name}! Anda telah berhasil logout.', 'info')
    return redirect(url_for('main.home'))

@auth_bp.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    """Change password for authenticated users"""
    form = ChangePasswordForm()
    
    if form.validate_on_submit():
        try:
            # Verify current password
            if not current_user.check_password(form.current_password.data):
                flash('Password saat ini salah. Silakan coba lagi.', 'error')
                return render_template('auth/change_password.html', form=form)
            
            # Check if new password is different from current
            if current_user.check_password(form.new_password.data):
                flash('Password baru harus berbeda dari password saat ini.', 'warning')
                return render_template('auth/change_password.html', form=form)
            
            # Update password
            current_user.set_password(form.new_password.data)
            current_user.updated_at = datetime.utcnow()
            db.session.commit()
            
            # Log password change
            logger.info(f"Password changed for user: {current_user.email}")
            
            flash('Password berhasil diubah. Silakan login kembali untuk keamanan.', 'success')
            
            # Logout user for security
            logout_user()
            session.clear()
            
            return redirect(url_for('auth.login'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Password change error for {current_user.email}: {e}")
            flash('Terjadi kesalahan saat mengubah password. Silakan coba lagi.', 'error')
    
    return render_template('auth/change_password.html', form=form)

@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
@anonymous_required
def forgot_password():
    """Forgot password - send reset link"""
    form = ForgotPasswordForm()
    
    if form.validate_on_submit():
        try:
            user = User.query.filter_by(email=form.email.data.lower().strip()).first()
            
            if user:
                # Generate reset token
                token_service = TokenService(current_app.config['SECRET_KEY'])
                token = token_service.generate_reset_token(user.email)
                
                # Create reset URL
                reset_url = url_for('auth.reset_password', token=token, _external=True)
                
                # Send email (mock implementation)
                email_service = EmailService()
                email_sent = email_service.send_password_reset_email(
                    user.email, 
                    user.name, 
                    reset_url
                )
                
                if email_sent:
                    # Log password reset request
                    logger.info(f"Password reset requested for: {user.email}")
                    
                    flash('Link reset password telah dikirim ke email Anda. Silakan cek inbox dan spam folder.', 'info')
                else:
                    flash('Gagal mengirim email reset. Silakan coba lagi nanti.', 'error')
            else:
                # Don't reveal if email exists or not for security
                flash('Jika email terdaftar, link reset password akan dikirim.', 'info')
            
            return redirect(url_for('auth.login'))
            
        except Exception as e:
            logger.error(f"Forgot password error: {e}")
            flash('Terjadi kesalahan. Silakan coba lagi nanti.', 'error')
    
    return render_template('auth/forgot_password.html', form=form)

@auth_bp.route('/reset-password/<token>', methods=['GET', 'POST'])
@anonymous_required
def reset_password(token):
    """Reset password with token"""
    form = ResetPasswordForm()
    
    # Verify token
    token_service = TokenService(current_app.config['SECRET_KEY'])
    email = token_service.verify_reset_token(token)
    
    if not email:
        flash('Link reset password tidak valid atau sudah kadaluarsa.', 'error')
        return redirect(url_for('auth.forgot_password'))
    
    user = User.query.filter_by(email=email).first()
    if not user:
        flash('User tidak ditemukan.', 'error')
        return redirect(url_for('auth.forgot_password'))
    
    if form.validate_on_submit():
        try:
            # Update password
            user.set_password(form.password.data)
            user.updated_at = datetime.utcnow()
            db.session.commit()
            
            # Log password reset
            logger.info(f"Password reset completed for: {user.email}")
            
            flash('Password berhasil direset. Silakan login dengan password baru.', 'success')
            return redirect(url_for('auth.login'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Password reset error for {user.email}: {e}")
            flash('Terjadi kesalahan saat mereset password. Silakan coba lagi.', 'error')
    
    return render_template('auth/reset_password.html', form=form, token=token)

@auth_bp.route('/profile')
@login_required
def profile():
    """User profile page"""
    return render_template('auth/profile.html', user=current_user)
