from flask import Blueprint, render_template, session, redirect, url_for, flash, request
from functools import wraps
from services.checkout_service import CheckoutService
from models.transaction_checkout import Transaction
from models.user import User
import json
from services.address_service import AddressService

checkout_routes = Blueprint('checkout_routes', __name__)

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Silakan login terlebih dahulu.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def buyer_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_role' not in session or session['user_role'] != 'buyer':
            flash('Akses ditolak. Halaman ini hanya untuk pembeli.', 'error')
            return redirect(url_for('home'))
        return f(*args, **kwargs)
    return decorated_function

@checkout_routes.route('/checkout', methods=['GET', 'POST'])
@login_required
@buyer_required
def checkout():
    """Checkout page with order confirmation"""
    
    # Get cart from session
    cart_items = session.get('cart', [])
    
    if not cart_items:
        flash('Keranjang belanja kosong. Silakan tambahkan produk terlebih dahulu.', 'error')
        return redirect(url_for('product_search.products'))
    
    # Get cart summary
    cart_summary = CheckoutService.get_cart_summary(cart_items)
    
    # Check if there are unavailable items
    if cart_summary['has_unavailable_items']:
        flash('Beberapa item di keranjang tidak tersedia. Silakan periksa kembali keranjang Anda.', 'error')
        return redirect(url_for('view_cart'))
    
    if request.method == 'POST':
        # Process checkout
        form_data = {
            'customer_name': request.form.get('customer_name', '').strip(),
            'customer_phone': request.form.get('customer_phone', '').strip(),
            'shipping_address': request.form.get('shipping_address', '').strip(),
            'notes': request.form.get('notes', '').strip()
        }
        
        # Process the checkout
        success, transaction_id, error_message = CheckoutService.process_checkout(
            form_data, cart_items, session['user_id']
        )
        
        if success:
            # Clear cart
            session.pop('cart', None)
            session.modified = True
            
            flash('Pesanan berhasil dibuat! Terima kasih atas pembelian Anda.', 'success')
            return redirect(url_for('checkout_routes.checkout_success', transaction_id=transaction_id))
        else:
            flash(f'Checkout gagal: {error_message}', 'error')
            return render_template('checkout.html', 
                                 cart_summary=cart_summary,
                                 form_data=form_data)
    
    # GET request - show checkout form
    # Get user addresses
    address_data = AddressService.get_address_for_checkout(session['user_id'])

    # Pre-fill form with default address if available
    if address_data['default_address']:
        default_addr = address_data['default_address']
        form_data = {
            'customer_name': default_addr.recipient_name,
            'customer_phone': default_addr.phone,
            'shipping_address': default_addr.full_address,
            'notes': '',
            'selected_address_id': default_addr.id
        }
    else:
        # Get user information for pre-filling form
        user = User.query.get(session['user_id'])
        form_data = {
            'customer_name': user.fullname if user else '',
            'customer_phone': user.phone if hasattr(user, 'phone') and user.phone else '',
            'shipping_address': '',
            'notes': '',
            'selected_address_id': None
        }

    return render_template('checkout.html', 
                         cart_summary=cart_summary,
                         form_data=form_data,
                         address_data=address_data)

@checkout_routes.route('/checkout/success/<int:transaction_id>')
@login_required
def checkout_success(transaction_id):
    """Checkout success page"""
    
    transaction = Transaction.query.get_or_404(transaction_id)
    
    # Verify that this transaction belongs to the current user
    if transaction.buyer_id != session['user_id']:
        flash('Anda tidak memiliki akses untuk melihat transaksi ini.', 'error')
        return redirect(url_for('home'))
    
    return render_template('checkout_success.html', transaction=transaction)

@checkout_routes.route('/cart')
@login_required
@buyer_required
def view_cart():
    """View shopping cart"""
    cart_items = session.get('cart', [])
    
    if not cart_items:
        return render_template('cart_empty.html')
    
    cart_summary = CheckoutService.get_cart_summary(cart_items)
    
    return render_template('cart_view.html', cart_summary=cart_summary)

@checkout_routes.route('/cart/add', methods=['POST'])
@login_required
@buyer_required
def add_to_cart():
    """Add product to cart"""
    data = request.get_json()
    product_id = data.get('product_id')
    quantity = data.get('quantity', 1)
    
    try:
        quantity = int(quantity)
        if quantity <= 0:
            return {'success': False, 'message': 'Jumlah harus lebih dari 0'}, 400
    except (ValueError, TypeError):
        return {'success': False, 'message': 'Jumlah tidak valid'}, 400
    
    from models.product_search import Product
    product = Product.query.get(product_id)
    
    if not product:
        return {'success': False, 'message': 'Produk tidak ditemukan'}, 404
    
    if not product.is_active:
        return {'success': False, 'message': 'Produk tidak tersedia'}, 400
    
    if product.stock < quantity:
        return {'success': False, 'message': f'Stok tidak mencukupi. Tersedia: {product.stock}'}, 400
    
    # Get current cart
    cart = session.get('cart', [])
    
    # Check if product already in cart
    existing_item = None
    for item in cart:
        if item['id'] == product_id:
            existing_item = item
            break
    
    if existing_item:
        new_quantity = existing_item['quantity'] + quantity
        if product.stock < new_quantity:
            return {'success': False, 'message': f'Stok tidak mencukupi. Tersedia: {product.stock}, total diminta: {new_quantity}'}, 400
        existing_item['quantity'] = new_quantity
    else:
        cart.append({
            'id': product_id,
            'name': product.name,
            'price': product.price,
            'quantity': quantity,
            'image_url': product.image_url
        })
    
    session['cart'] = cart
    session.modified = True
    
    # Calculate cart totals
    cart_count = sum(item['quantity'] for item in cart)
    cart_total = sum(item['price'] * item['quantity'] for item in cart)
    
    return {
        'success': True,
        'message': f'{product.name} berhasil ditambahkan ke keranjang',
        'cart_count': cart_count,
        'cart_total': cart_total
    }

@checkout_routes.route('/cart/update', methods=['POST'])
@login_required
@buyer_required
def update_cart():
    """Update cart item quantity"""
    data = request.get_json()
    product_id = data.get('product_id')
    quantity = data.get('quantity', 0)
    
    try:
        quantity = int(quantity)
        if quantity < 0:
            return {'success': False, 'message': 'Jumlah tidak boleh negatif'}, 400
    except (ValueError, TypeError):
        return {'success': False, 'message': 'Jumlah tidak valid'}, 400
    
    cart = session.get('cart', [])
    
    # Find and update item
    for i, item in enumerate(cart):
        if item['id'] == product_id:
            if quantity == 0:
                # Remove item from cart
                cart.pop(i)
            else:
                # Validate stock
                from models.product_search import Product
                product = Product.query.get(product_id)
                if not product or product.stock < quantity:
                    available_stock = product.stock if product else 0
                    return {'success': False, 'message': f'Stok tidak mencukupi. Tersedia: {available_stock}'}, 400
                
                # Update quantity
                item['quantity'] = quantity
            break
    
    session['cart'] = cart
    session.modified = True
    
    # Calculate new totals
    cart_count = sum(item['quantity'] for item in cart)
    cart_total = sum(item['price'] * item['quantity'] for item in cart)
    
    return {
        'success': True,
        'cart_count': cart_count,
        'cart_total': cart_total
    }

@checkout_routes.route('/cart/remove/<int:product_id>', methods=['POST'])
@login_required
@buyer_required
def remove_from_cart(product_id):
    """Remove product from cart"""
    cart = session.get('cart', [])
    
    # Remove item from cart
    cart = [item for item in cart if item['id'] != product_id]
    
    session['cart'] = cart
    session.modified = True
    
    flash('Produk berhasil dihapus dari keranjang.', 'success')
    return redirect(url_for('checkout_routes.view_cart'))
