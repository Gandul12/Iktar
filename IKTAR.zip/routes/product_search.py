from flask import Blueprint, render_template, request, jsonify, url_for
from models.product_search import Product
from services.search_service import SearchService
from math import ceil

product_search = Blueprint('product_search', __name__)

@product_search.route('/products')
def products():
    """Main products page with search and filter functionality"""
    
    # Parse search parameters
    params = SearchService.parse_search_params(request.args)
    
    # Clean search query
    if params['search_query']:
        params['search_query'] = SearchService.clean_search_query(params['search_query'])
    
    # Perform search and filtering
    pagination = Product.search_and_filter(
        search_query=params['search_query'],
        category=params['category'],
        price_min=params['price_min'],
        price_max=params['price_max'],
        sort_by=params['sort_by'],
        sort_order=params['sort_order'],
        only_in_stock=params['only_in_stock'],
        page=params['page'],
        per_page=12
    )
    
    # Get filter options
    categories = [
        {'value': 'all', 'label': 'Semua Kategori'},
        {'value': 'hias', 'label': 'Ikan Hias'},
        {'value': 'konsumsi', 'label': 'Ikan Konsumsi'},
        {'value': 'predator', 'label': 'Ikan Predator'},
        {'value': 'bibit', 'label': 'Bibit Ikan'}
    ]
    
    # Get price range for slider
    price_range = Product.get_price_range()
    
    # Generate filter summary
    filter_summary = SearchService.get_filter_summary(params)
    
    # Get popular searches
    popular_searches = SearchService.get_popular_searches()
    
    # Build pagination URLs
    def build_page_url(page_num):
        page_params = params.copy()
        page_params['page'] = page_num
        return SearchService.build_search_url('/products', page_params, ['page']) + f"&page={page_num}"
    
    return render_template('products_search.html',
                         products=pagination.items,
                         pagination=pagination,
                         params=params,
                         categories=categories,
                         price_range=price_range,
                         filter_summary=filter_summary,
                         popular_searches=popular_searches,
                         build_page_url=build_page_url,
                         total_results=pagination.total)

@product_search.route('/api/search-suggestions')
def search_suggestions():
    """API endpoint for search autocomplete"""
    query = request.args.get('q', '').strip()
    
    if len(query) < 2:
        return jsonify([])
    
    suggestions = Product.get_search_suggestions(query, limit=8)
    return jsonify(suggestions)

@product_search.route('/api/filter-counts')
def filter_counts():
    """API endpoint to get product counts for each filter option"""
    search_query = request.args.get('q', '').strip()
    
    # Base query
    base_query = Product.query.filter(Product.is_active == True)
    
    if search_query:
        search_term = f"%{search_query}%"
        base_query = base_query.filter(
            Product.name.ilike(search_term) | 
            Product.description.ilike(search_term)
        )
    
    # Count by category
    category_counts = {}
    categories = ['hias', 'konsumsi', 'predator', 'bibit']
    
    for category in categories:
        count = base_query.filter(Product.category == category).count()
        category_counts[category] = count
    
    # Count in stock vs out of stock
    in_stock_count = base_query.filter(Product.stock > 0).count()
    total_count = base_query.count()
    
    return jsonify({
        'categories': category_counts,
        'in_stock': in_stock_count,
        'total': total_count
    })

@product_search.route('/products/category/<category>')
def products_by_category(category):
    """Quick access to products by category"""
    valid_categories = ['hias', 'konsumsi', 'predator', 'bibit']
    
    if category not in valid_categories:
        return redirect(url_for('product_search.products'))
    
    return redirect(url_for('product_search.products', category=category))

@product_search.route('/search')
def search_redirect():
    """Redirect search queries to main products page"""
    query = request.args.get('q', '').strip()
    
    if query:
        return redirect(url_for('product_search.products', q=query))
    else:
        return redirect(url_for('product_search.products'))
