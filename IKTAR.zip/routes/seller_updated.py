from flask import Blueprint, render_template, session, redirect, url_for, flash, request
from functools import wraps
from models.product import Product
from models.transaction import Transaction
from models.user import User
from database import db
from werkzeug.utils import secure_filename
from werkzeug.datastructures import FileStorage
import os
import uuid
from datetime import datetime
from sqlalchemy import func, distinct

seller = Blueprint('seller', __name__)

# Configuration for file uploads
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Silakan login terlebih dahulu.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def seller_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_role' not in session or session['user_role'] != 'seller':
            flash('Akses ditolak. Halaman ini hanya untuk penjual.', 'error')
            return redirect(url_for('home'))
        return f(*args, **kwargs)
    return decorated_function

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_uploaded_file(file):
    """Save uploaded file and return the filename"""
    if file and allowed_file(file.filename):
        # Generate unique filename
        filename = secure_filename(file.filename)
        name, ext = os.path.splitext(filename)
        unique_filename = f"{name}_{uuid.uuid4().hex[:8]}{ext}"
        
        # Ensure upload directory exists
        os.makedirs(UPLOAD_FOLDER, exist_ok=True)
        
        # Save file
        file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
        file.save(file_path)
        
        return unique_filename
    return None

@seller.route('/seller/edit-product/<int:id>', methods=['GET', 'POST'])
@login_required
@seller_required
def edit_product(id):
    product = Product.query.get_or_404(id)
    
    # Check if this product belongs to the current seller
    if product.seller_id != session['user_id']:
        flash('Anda tidak memiliki akses untuk mengedit produk ini.', 'error')
        return redirect(url_for('seller_products'))
    
    if request.method == 'POST':
        # Get form data
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '').strip()
        category = request.form.get('category', '').strip()
        price = request.form.get('price', '').strip()
        stock = request.form.get('stock', '').strip()
        unit = request.form.get('unit', 'kg').strip()
        is_active = 'is_active' in request.form
        image_file = request.files.get('image')
        
        # Validation
        errors = []
        
        if not name or len(name) < 3:
            errors.append('Nama produk minimal 3 karakter.')
        
        if not description or len(description) < 10:
            errors.append('Deskripsi minimal 10 karakter.')
        
        if not category:
            errors.append('Pilih kategori produk.')
        
        try:
            price_float = float(price)
            if price_float < 1000:
                errors.append('Harga minimal Rp 1.000.')
        except (ValueError, TypeError):
            errors.append('Harga harus berupa angka.')
            price_float = 0
        
        try:
            stock_int = int(stock)
            if stock_int < 0:
                errors.append('Stok tidak boleh negatif.')
        except (ValueError, TypeError):
            errors.append('Stok harus berupa angka.')
            stock_int = 0
        
        # Check if product name already exists for this seller (excluding current product)
        existing_product = Product.query.filter(
            Product.seller_id == session['user_id'],
            Product.name == name,
            Product.id != id
        ).first()
        if existing_product:
            errors.append('Anda sudah memiliki produk dengan nama yang sama.')
        
        # Validate image if uploaded
        image_filename = None
        if image_file and image_file.filename:
            if not allowed_file(image_file.filename):
                errors.append('Format file tidak didukung. Gunakan JPG, PNG, atau JPEG.')
            elif len(image_file.read()) > MAX_FILE_SIZE:
                errors.append('Ukuran file terlalu besar. Maksimal 5MB.')
            else:
                image_file.seek(0)  # Reset file pointer
                image_filename = save_uploaded_file(image_file)
                if not image_filename:
                    errors.append('Gagal menyimpan file gambar.')
        
        if errors:
            for error in errors:
                flash(error, 'error')
            return render_template('edit_product.html', product=product)
        
        # Update product
        old_image = product.image_url
        
        product.name = name
        product.description = description
        product.price = price_float
        product.stock = stock_int
        product.category = category
        product.unit = unit
        product.is_active = is_active
        product.updated_at = datetime.utcnow()
        
        # Update image if new one is uploaded
        if image_filename:
            product.image_url = f'uploads/{image_filename}'
        
        try:
            db.session.commit()
            
            # Remove old image file if new one is uploaded
            if image_filename and old_image:
                try:
                    old_image_path = os.path.join('static', old_image)
                    if os.path.exists(old_image_path):
                        os.remove(old_image_path)
                except:
                    pass  # Continue even if file deletion fails
            
            flash(f'Produk "{name}" berhasil diperbarui!', 'success')
            return redirect(url_for('seller_products'))
            
        except Exception as e:
            db.session.rollback()
            # Remove uploaded file if database save fails
            if image_filename:
                try:
                    os.remove(os.path.join(UPLOAD_FOLDER, image_filename))
                except:
                    pass
            
            flash('Terjadi kesalahan saat memperbarui produk. Silakan coba lagi.', 'error')
            return render_template('edit_product.html', product=product)
    
    # GET request
    return render_template('edit_product.html', product=product)

@seller.route('/seller/delete-product/<int:id>', methods=['GET', 'POST'])
@login_required
@seller_required
def delete_product(id):
    product = Product.query.get_or_404(id)
    
    # Check if this product belongs to the current seller
    if product.seller_id != session['user_id']:
        flash('Anda tidak memiliki akses untuk menghapus produk ini.', 'error')
        return redirect(url_for('seller_products'))
    
    if request.method == 'POST':
        # Check if product has any transactions
        has_transactions = Transaction.query.filter_by(product_id=id).first()
        if has_transactions:
            flash('Produk tidak dapat dihapus karena sudah memiliki riwayat transaksi. Anda dapat menonaktifkan produk ini.', 'error')
            return redirect(url_for('edit_product', id=id))
        
        # Store product name and image for cleanup
        product_name = product.name
        image_url = product.image_url
        
        try:
            # Delete product from database
            db.session.delete(product)
            db.session.commit()
            
            # Delete image file
            if image_url:
                try:
                    image_path = os.path.join('static', image_url)
                    if os.path.exists(image_path):
                        os.remove(image_path)
                except:
                    pass  # Continue even if file deletion fails
            
            flash(f'Produk "{product_name}" berhasil dihapus.', 'success')
            return redirect(url_for('seller_products'))
            
        except Exception as e:
            db.session.rollback()
            flash('Terjadi kesalahan saat menghapus produk. Silakan coba lagi.', 'error')
            return render_template('delete_product.html', product=product)
    
    # GET request - show confirmation page
    return render_template('delete_product.html', product=product)

# Other existing routes...
@seller.route('/seller/products')
@login_required
@seller_required
def seller_products():
    seller_id = session['user_id']
    products = Product.query.filter_by(seller_id=seller_id).order_by(Product.created_at.desc()).all()
    return render_template('seller_products.html', products=products)

@seller.route('/seller/transactions')
@login_required
@seller_required
def seller_transactions():
    seller_id = session['user_id']
    
    # Get all transactions for this seller's products with joins
    transactions = db.session.query(Transaction).join(Product).join(
        User, Transaction.buyer_id == User.id
    ).filter(
        Product.seller_id == seller_id
    ).order_by(Transaction.created_at.desc()).all()
    
    # Calculate statistics
    total_transactions = len(transactions)
    total_revenue = sum(transaction.total_price for transaction in transactions)
    total_items = sum(transaction.quantity for transaction in transactions)
    
    # Count unique customers
    unique_customers = db.session.query(
        func.count(distinct(Transaction.buyer_id))
    ).join(Product).filter(
        Product.seller_id == seller_id
    ).scalar() or 0
    
    stats = {
        'total_transactions': total_transactions,
        'total_revenue': total_revenue,
        'total_items': total_items,
        'unique_customers': unique_customers
    }
    
    return render_template('seller_transactions.html', 
                         transactions=transactions, 
                         stats=stats)

@seller.route('/dashboard/seller')
@login_required
@seller_required
def dashboard_seller():
    seller_id = session['user_id']
    
    # Get seller's products
    products = Product.query.filter_by(seller_id=seller_id).all()
    
    # Calculate statistics
    total_products = len(products)
    total_stock = sum(product.stock for product in products)
    
    # Get transactions for this seller's products
    transactions = db.session.query(Transaction).join(Product).filter(
        Product.seller_id == seller_id
    ).all()
    
    total_transactions = len(transactions)
    total_revenue = sum(transaction.total_price for transaction in transactions)
    
    # Get recent transactions (last 5)
    recent_transactions = db.session.query(
        Transaction.id,
        Transaction.quantity,
        Transaction.total_price,
        Transaction.created_at,
        Product.name.label('product_name'),
        User.fullname.label('buyer_name')
    ).join(Product).join(User, Transaction.buyer_id == User.id).filter(
        Product.seller_id == seller_id
    ).order_by(Transaction.created_at.desc()).limit(5).all()
    
    stats = {
        'total_products': total_products,
        'total_stock': total_stock,
        'total_transactions': total_transactions,
        'total_revenue': total_revenue
    }
    
    return render_template('dashboard_seller.html', 
                         products=products, 
                         recent_transactions=recent_transactions,
                         stats=stats)

@seller.route('/seller/add', methods=['GET', 'POST'])
@login_required
@seller_required
def add_product():
    if request.method == 'POST':
        # Get form data
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '').strip()
        category = request.form.get('category', '').strip()
        price = request.form.get('price', '').strip()
        stock = request.form.get('stock', '').strip()
        unit = request.form.get('unit', 'kg').strip()
        image_file = request.files.get('image')
        
        # Validation
        errors = []
        
        if not name or len(name) < 3:
            errors.append('Nama ikan minimal 3 karakter.')
        
        if not description or len(description) < 10:
            errors.append('Deskripsi minimal 10 karakter.')
        
        if not category:
            errors.append('Pilih kategori ikan.')
        
        try:
            price_float = float(price)
            if price_float < 1000:
                errors.append('Harga minimal Rp 1.000.')
        except (ValueError, TypeError):
            errors.append('Harga harus berupa angka.')
            price_float = 0
        
        try:
            stock_int = int(stock)
            if stock_int < 0:
                errors.append('Stok tidak boleh negatif.')
        except (ValueError, TypeError):
            errors.append('Stok harus berupa angka.')
            stock_int = 0
        
        # Validate image
        if not image_file or image_file.filename == '':
            errors.append('Pilih foto produk.')
        elif not allowed_file(image_file.filename):
            errors.append('Format file tidak didukung. Gunakan JPG, PNG, atau JPEG.')
        elif len(image_file.read()) > MAX_FILE_SIZE:
            errors.append('Ukuran file terlalu besar. Maksimal 5MB.')
            image_file.seek(0)  # Reset file pointer
        
        # Check if product name already exists for this seller
        existing_product = Product.query.filter_by(
            seller_id=session['user_id'], 
            name=name
        ).first()
        if existing_product:
            errors.append('Anda sudah memiliki produk dengan nama yang sama.')
        
        if errors:
            for error in errors:
                flash(error, 'error')
            return render_template('add_product.html')
        
        # Save image file
        image_filename = save_uploaded_file(image_file)
        if not image_filename:
            flash('Gagal menyimpan file gambar.', 'error')
            return render_template('add_product.html')
        
        # Create new product
        new_product = Product(
            name=name,
            description=description,
            price=price_float,
            stock=stock_int,
            category=category,
            image_url=f'uploads/{image_filename}',
            seller_id=session['user_id'],
            unit=unit,
            is_active=True
        )
        
        try:
            db.session.add(new_product)
            db.session.commit()
            
            flash(f'Produk "{name}" berhasil ditambahkan!', 'success')
            return redirect(url_for('seller_products'))
            
        except Exception as e:
            db.session.rollback()
            # Remove uploaded file if database save fails
            try:
                os.remove(os.path.join(UPLOAD_FOLDER, image_filename))
            except:
                pass
            
            flash('Terjadi kesalahan saat menyimpan produk. Silakan coba lagi.', 'error')
            return render_template('add_product.html')
    
    # GET request
    return render_template('add_product.html')
