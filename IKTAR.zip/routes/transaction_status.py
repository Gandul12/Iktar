from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for, flash
from services.transaction_status_service import TransactionStatusService
from models.notification import TransactionStatus
from models.transaction_checkout import Transaction
from functools import wraps

transaction_status_bp = Blueprint('transaction_status', __name__)

def seller_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Silakan login terlebih dahulu', 'error')
            return redirect(url_for('auth.login'))
        
        if session.get('user_role') != 'seller':
            flash('Akses ditolak. Hanya penjual yang dapat mengakses halaman ini.', 'error')
            return redirect(url_for('home'))
        
        return f(*args, **kwargs)
    return decorated_function

@transaction_status_bp.route('/seller/transactions')
@seller_required
def seller_transactions():
    """Display seller transactions with status management"""
    seller_id = session['user_id']
    status_filter = request.args.get('status')
    
    # Convert status filter to enum if provided
    status_enum = None
    if status_filter:
        try:
            status_enum = TransactionStatus(status_filter)
        except ValueError:
            status_enum = None
    
    transactions = TransactionStatusService.get_seller_transactions(seller_id, status_enum)
    
    # Get status counts for filter tabs
    status_counts = {}
    for status in TransactionStatus:
        count = len(TransactionStatusService.get_seller_transactions(seller_id, status))
        status_counts[status.value] = count
    
    return render_template('seller/transactions.html',
                         transactions=transactions,
                         status_counts=status_counts,
                         current_status=status_filter,
                         TransactionStatus=TransactionStatus)

@transaction_status_bp.route('/seller/transaction/<int:transaction_id>')
@seller_required
def transaction_detail(transaction_id):
    """Display transaction detail with status update options"""
    seller_id = session['user_id']
    
    # Verify seller owns this transaction
    transaction = Transaction.query.get_or_404(transaction_id)
    
    # Check if seller owns any product in this transaction
    seller_owns_transaction = any(
        detail.product.seller_id == seller_id 
        for detail in transaction.transaction_details
    )
    
    if not seller_owns_transaction:
        flash('Anda tidak memiliki akses ke transaksi ini', 'error')
        return redirect(url_for('transaction_status.seller_transactions'))
    
    # Get available status transitions
    available_transitions = TransactionStatusService.get_available_status_transitions(transaction.status)
    
    # Get status history
    status_history = TransactionStatusService.get_transaction_history(transaction_id)
    
    return render_template('seller/transaction_detail.html',
                         transaction=transaction,
                         available_transitions=available_transitions,
                         status_history=status_history)

@transaction_status_bp.route('/seller/transaction/<int:transaction_id>/update-status', methods=['POST'])
@seller_required
def update_transaction_status(transaction_id):
    """Update transaction status"""
    seller_id = session['user_id']
    
    # Verify seller owns this transaction
    transaction = Transaction.query.get_or_404(transaction_id)
    seller_owns_transaction = any(
        detail.product.seller_id == seller_id 
        for detail in transaction.transaction_details
    )
    
    if not seller_owns_transaction:
        return jsonify({'success': False, 'message': 'Akses ditolak'}), 403
    
    new_status_value = request.form.get('status')
    notes = request.form.get('notes', '').strip()
    
    if not new_status_value:
        return jsonify({'success': False, 'message': 'Status baru harus dipilih'}), 400
    
    try:
        new_status = TransactionStatus(new_status_value)
    except ValueError:
        return jsonify({'success': False, 'message': 'Status tidak valid'}), 400
    
    success, message = TransactionStatusService.update_transaction_status(
        transaction_id, new_status, seller_id, notes
    )
    
    if success:
        if request.is_json:
            return jsonify({'success': True, 'message': message})
        else:
            flash(message, 'success')
            return redirect(url_for('transaction_status.transaction_detail', transaction_id=transaction_id))
    else:
        if request.is_json:
            return jsonify({'success': False, 'message': message}), 400
        else:
            flash(message, 'error')
            return redirect(url_for('transaction_status.transaction_detail', transaction_id=transaction_id))

@transaction_status_bp.route('/api/transaction/<int:transaction_id>/status-history')
@seller_required
def get_status_history(transaction_id):
    """Get transaction status history"""
    seller_id = session['user_id']
    
    # Verify access
    transaction = Transaction.query.get_or_404(transaction_id)
    seller_owns_transaction = any(
        detail.product.seller_id == seller_id 
        for detail in transaction.transaction_details
    )
    
    if not seller_owns_transaction:
        return jsonify({'error': 'Akses ditolak'}), 403
    
    history = TransactionStatusService.get_transaction_history(transaction_id)
    
    history_data = []
    for update in history:
        history_data.append({
            'old_status': update.old_status.value if update.old_status else None,
            'new_status': update.new_status.value,
            'notes': update.notes,
            'updated_by': update.updater.name,
            'created_at': update.created_at.isoformat()
        })
    
    return jsonify({'history': history_data})
