from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SelectField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Email, Length, EqualTo, ValidationError
from models.user import User, UserRole

class RegistrationForm(FlaskForm):
    name = StringField('Nama Lengkap', validators=[
        DataRequired(message='Nama lengkap wajib diisi'),
        Length(min=2, max=100, message='Nama harus antara 2-100 karakter')
    ])
    
    email = StringField('Email', validators=[
        DataRequired(message='Email wajib diisi'),
        Email(message='Format email tidak valid'),
        Length(max=120, message='Email maksimal 120 karakter')
    ])
    
    password = PasswordField('Password', validators=[
        DataRequired(message='Password wajib diisi'),
        Length(min=6, message='Password minimal 6 karakter')
    ])
    
    confirm_password = PasswordField('Konfirmasi Password', validators=[
        DataRequired(message='Konfirmasi password wajib diisi'),
        EqualTo('password', message='Password tidak cocok')
    ])
    
    role = SelectField('Daftar Sebagai', choices=[
        ('buyer', 'Pembeli - Saya ingin membeli ikan segar'),
        ('seller', 'Penjual - Saya ingin menjual ikan segar')
    ], validators=[DataRequired(message='Pilih role Anda')])
    
    terms = BooleanField('Saya setuju dengan syarat dan ketentuan', validators=[
        DataRequired(message='Anda harus menyetujui syarat dan ketentuan')
    ])
    
    submit = SubmitField('Daftar Sekarang')
    
    def validate_email(self, email):
        """Check if email is already registered"""
        user = User.query.filter_by(email=email.data.lower()).first()
        if user:
            raise ValidationError('Email sudah terdaftar. Silakan gunakan email lain atau login.')

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[
        DataRequired(message='Email wajib diisi'),
        Email(message='Format email tidak valid')
    ])
    
    password = PasswordField('Password', validators=[
        DataRequired(message='Password wajib diisi')
    ])
    
    remember_me = BooleanField('Ingat saya')
    
    submit = SubmitField('Masuk')

class ChangePasswordForm(FlaskForm):
    current_password = PasswordField('Password Saat Ini', validators=[
        DataRequired(message='Password saat ini wajib diisi')
    ], render_kw={'placeholder': 'Masukkan password saat ini'})
    
    new_password = PasswordField('Password Baru', validators=[
        DataRequired(message='Password baru wajib diisi'),
        Length(min=6, max=128, message='Password harus antara 6-128 karakter')
    ], render_kw={'placeholder': 'Masukkan password baru'})
    
    confirm_password = PasswordField('Konfirmasi Password Baru', validators=[
        DataRequired(message='Konfirmasi password wajib diisi'),
        EqualTo('new_password', message='Konfirmasi password tidak cocok')
    ], render_kw={'placeholder': 'Ulangi password baru'})
    
    submit = SubmitField('Ubah Password')
    
    def validate_new_password(self, new_password):
        """Validate new password strength"""
        password = new_password.data
        
        # Check for at least one uppercase letter
        if not any(c.isupper() for c in password):
            raise ValidationError('Password harus mengandung minimal 1 huruf besar.')
        
        # Check for at least one lowercase letter
        if not any(c.islower() for c in password):
            raise ValidationError('Password harus mengandung minimal 1 huruf kecil.')
        
        # Check for at least one digit
        if not any(c.isdigit() for c in password):
            raise ValidationError('Password harus mengandung minimal 1 angka.')

class ForgotPasswordForm(FlaskForm):
    email = StringField('Email', validators=[
        DataRequired(message='Email wajib diisi'),
        Email(message='Format email tidak valid')
    ], render_kw={'placeholder': 'Masukkan email Anda'})
    
    submit = SubmitField('Kirim Link Reset')
    
    def validate_email(self, email):
        """Check if email exists in database"""
        user = User.query.filter_by(email=email.data.lower().strip()).first()
        if not user:
            raise ValidationError('Email tidak ditemukan dalam sistem.')
        if not user.is_active:
            raise ValidationError('Akun dengan email ini telah dinonaktifkan.')

class ResetPasswordForm(FlaskForm):
    password = PasswordField('Password Baru', validators=[
        DataRequired(message='Password baru wajib diisi'),
        Length(min=6, max=128, message='Password harus antara 6-128 karakter')
    ], render_kw={'placeholder': 'Masukkan password baru'})
    
    confirm_password = PasswordField('Konfirmasi Password Baru', validators=[
        DataRequired(message='Konfirmasi password wajib diisi'),
        EqualTo('password', message='Konfirmasi password tidak cocok')
    ], render_kw={'placeholder': 'Ulangi password baru'})
    
    submit = SubmitField('Reset Password')
    
    def validate_password(self, password):
        """Validate password strength"""
        pwd = password.data
        
        # Check for at least one uppercase letter
        if not any(c.isupper() for c in pwd):
            raise ValidationError('Password harus mengandung minimal 1 huruf besar.')
        
        # Check for at least one lowercase letter
        if not any(c.islower() for c in pwd):
            raise ValidationError('Password harus mengandung minimal 1 huruf kecil.')
        
        # Check for at least one digit
        if not any(c.isdigit() for c in pwd):
            raise ValidationError('Password harus mengandung minimal 1 angka.')
