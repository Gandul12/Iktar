#!/bin/bash

echo "🐟 Setting up Iktar - Fish Marketplace"
echo "======================================"

# Create virtual environment
echo "📦 Creating virtual environment..."
python -m venv venv

# Activate virtual environment
echo "🔧 Activating virtual environment..."
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    source venv/Scripts/activate
else
    source venv/bin/activate
fi

# Install dependencies
echo "📥 Installing dependencies..."
pip install -r requirements.txt

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p app/static/uploads
mkdir -p instance

# Initialize database
echo "🗄️ Setting up database..."
python reset_database.py

echo "✅ Setup complete!"
echo ""
echo "🚀 To run the application:"
echo "   1. Activate virtual environment:"
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    echo "      venv\\Scripts\\activate"
else
    echo "      source venv/bin/activate"
fi
echo "   2. Run the application:"
echo "      python run.py"
echo ""
echo "🌐 Application will be available at: http://localhost:5000"
echo ""
echo "👤 Test accounts:"
echo "   Admin: admin@iktar.com / admin123"
echo "   Seller: budi@seller.com / seller123"
echo "   Buyer: sari@buyer.com / buyer123"
