from app import create_app, db
from app.models.models import User, Product, UserRole
from werkzeug.security import generate_password_hash

def reset_database():
    """Reset database and create sample data"""
    app = create_app()
    
    with app.app_context():
        # Drop all tables
        db.drop_all()
        
        # Create all tables
        db.create_all()
        
        # Create sample users
        admin = User(
            name='Admin Iktar',
            email='admin@iktar.com',
            role=UserRole.ADMIN,
            is_active=True,
            email_verified=True
        )
        admin.set_password('admin123')
        
        seller1 = User(
            name='Pak Budi Penjual Ikan',
            email='budi@seller.com',
            role=UserRole.SELLER,
            phone='081234567890',
            address='Jl. Pasar Ikan No. 123, Jakarta',
            is_active=True,
            email_verified=True
        )
        seller1.set_password('seller123')
        
        buyer1 = User(
            name='Ibu Sari Pembeli',
            email='sari@buyer.com',
            role=UserRole.BUYER,
            phone='081987654321',
            address='Jl. Rumah No. 456, Jakarta',
            is_active=True,
            email_verified=True
        )
        buyer1.set_password('buyer123')
        
        db.session.add_all([admin, seller1, buyer1])
        db.session.commit()
        
        # Create sample products
        products = [
            Product(
                name='Ikan Lele Segar',
                description='Ikan lele segar langsung dari kolam, cocok untuk digoreng atau dibakar. Ukuran sedang, daging tebal dan gurih.',
                price=25000,
                stock=50,
                category='konsumsi',
                seller_id=seller1.id,
                is_active=True
            ),
            Product(
                name='Ikan Nila Merah',
                description='Ikan nila merah segar dengan kualitas premium. Daging putih, tidak amis, cocok untuk berbagai masakan.',
                price=30000,
                stock=30,
                category='konsumsi',
                seller_id=seller1.id,
                is_active=True
            ),
            Product(
                name='Ikan Cupang Halfmoon',
                description='Ikan cupang halfmoon dengan warna indah dan ekor yang sempurna. Cocok untuk aquarium hias.',
                price=75000,
                stock=10,
                category='hias',
                seller_id=seller1.id,
                is_active=True
            ),
            Product(
                name='Ikan Arwana Silver',
                description='Ikan arwana silver berkualitas tinggi, ukuran 15cm. Sangat cocok untuk aquarium besar.',
                price=500000,
                stock=5,
                category='hias',
                seller_id=seller1.id,
                is_active=True
            ),
            Product(
                name='Bibit Ikan Gurame',
                description='Bibit ikan gurame unggul siap tebar. Ukuran 3-5cm, survival rate tinggi.',
                price=2000,
                stock=1000,
                category='bibit',
                seller_id=seller1.id,
                is_active=True
            ),
            Product(
                name='Ikan Gabus Segar',
                description='Ikan gabus segar kaya protein, cocok untuk ibu hamil dan penyembuhan luka.',
                price=45000,
                stock=20,
                category='konsumsi',
                seller_id=seller1.id,
                is_active=True
            )
        ]
        
        db.session.add_all(products)
        db.session.commit()
        
        print("Database berhasil direset!")
        print("Sample accounts:")
        print("Admin: admin@iktar.com / admin123")
        print("Seller: budi@seller.com / seller123")
        print("Buyer: sari@buyer.com / buyer123")

if __name__ == '__main__':
    reset_database()
