export interface Product {
  id: number
  name: string
  description: string
  price: number
  stock: number
  category: string
  image_url: string
  images: string[]
  seller_id: number
  seller_name: string
  seller_avatar: string
  average_rating: number
  total_reviews: number
  stock_status: "in_stock" | "low_stock" | "out_of_stock"
  created_at: string
  specifications?: Record<string, string>
  tags: string[]
}

export interface Review {
  id: number
  product_id: number
  user_id: number
  user_name: string
  user_avatar: string
  rating: number
  comment: string
  created_at: string
  helpful_count: number
}

export interface CartItem {
  id: number
  product_id: number
  product: Product
  quantity: number
  subtotal: number
}

export interface Order {
  id: number
  user_id: number
  items: CartItem[]
  total: number
  status: "pending" | "processing" | "shipped" | "delivered" | "cancelled"
  shipping_address: string
  payment_method: string
  created_at: string
  updated_at: string
  tracking_number?: string
}

export interface Notification {
  id: number
  user_id: number
  title: string
  message: string
  type: "info" | "success" | "warning" | "error"
  read: boolean
  created_at: string
}

// Mock Products Data
export const MOCK_PRODUCTS: Product[] = [
  {
    id: 1,
    name: "Ikan Guppy Premium Rainbow",
    description:
      "Ikan guppy berkualitas tinggi dengan warna rainbow yang indah. Cocok untuk aquarium hias dan mudah dipelihara. Sudah melalui proses karantina dan siap untuk dipelihara.",
    price: 15000,
    stock: 50,
    category: "hias",
    image_url: "/placeholder.svg?height=400&width=400",
    images: [
      "/placeholder.svg?height=400&width=400",
      "/placeholder.svg?height=400&width=400&text=Guppy+2",
      "/placeholder.svg?height=400&width=400&text=Guppy+3",
    ],
    seller_id: 2,
    seller_name: "Aqua Paradise",
    seller_avatar: "/placeholder.svg?height=40&width=40",
    average_rating: 4.8,
    total_reviews: 24,
    stock_status: "in_stock",
    created_at: "2024-06-20T10:00:00Z",
    specifications: {
      Ukuran: "3-4 cm",
      "Jenis Kelamin": "Campuran",
      Asal: "Lokal Breeding",
      "pH Air": "6.5-7.5",
      Suhu: "24-28°C",
    },
    tags: ["guppy", "ikan hias", "rainbow", "mudah dipelihara"],
  },
  {
    id: 2,
    name: "Ikan Lele Segar Organik",
    description:
      "Ikan lele segar hasil budidaya organik tanpa bahan kimia berbahaya. Daging tebal dan gurih, cocok untuk berbagai masakan tradisional Indonesia.",
    price: 25000,
    stock: 30,
    category: "konsumsi",
    image_url: "/placeholder.svg?height=400&width=400&text=Lele",
    images: [
      "/placeholder.svg?height=400&width=400&text=Lele",
      "/placeholder.svg?height=400&width=400&text=Lele+Fresh",
    ],
    seller_id: 3,
    seller_name: "Fresh Fish Market",
    seller_avatar: "/placeholder.svg?height=40&width=40",
    average_rating: 4.6,
    total_reviews: 18,
    stock_status: "in_stock",
    created_at: "2024-06-19T14:30:00Z",
    specifications: {
      Berat: "500-700 gram/ekor",
      Kondisi: "Hidup/Segar",
      Budidaya: "Organik",
      Asal: "Jawa Barat",
    },
    tags: ["lele", "ikan konsumsi", "organik", "segar"],
  },
  {
    id: 3,
    name: "Ikan Arowana Silver Juvenile",
    description:
      "Ikan arowana silver muda berkualitas super dengan bentuk tubuh sempurna. Ikan predator yang eksotis dan bernilai tinggi untuk kolektor.",
    price: 350000,
    stock: 5,
    category: "predator",
    image_url: "/placeholder.svg?height=400&width=400&text=Arowana",
    images: [
      "/placeholder.svg?height=400&width=400&text=Arowana",
      "/placeholder.svg?height=400&width=400&text=Arowana+Side",
    ],
    seller_id: 4,
    seller_name: "Dragon Fish Gallery",
    seller_avatar: "/placeholder.svg?height=40&width=40",
    average_rating: 4.9,
    total_reviews: 12,
    stock_status: "low_stock",
    created_at: "2024-06-18T09:15:00Z",
    specifications: {
      Ukuran: "15-20 cm",
      Umur: "6-8 bulan",
      Jenis: "Silver Arowana",
      Sertifikat: "CITES",
    },
    tags: ["arowana", "predator", "eksotis", "kolektor"],
  },
  {
    id: 4,
    name: "Bibit Ikan Nila GIFT",
    description:
      "Bibit ikan nila GIFT (Genetically Improved Farmed Tilapia) unggul untuk budidaya. Pertumbuhan cepat dan tahan penyakit.",
    price: 5000,
    stock: 100,
    category: "bibit",
    image_url: "/placeholder.svg?height=400&width=400&text=Nila+GIFT",
    images: ["/placeholder.svg?height=400&width=400&text=Nila+GIFT"],
    seller_id: 5,
    seller_name: "Bibit Unggul Farm",
    seller_avatar: "/placeholder.svg?height=40&width=40",
    average_rating: 4.7,
    total_reviews: 35,
    stock_status: "in_stock",
    created_at: "2024-06-17T16:45:00Z",
    specifications: {
      Ukuran: "3-5 cm",
      Umur: "1-2 bulan",
      Strain: "GIFT",
      "Survival Rate": "95%",
    },
    tags: ["nila", "bibit", "GIFT", "budidaya"],
  },
  {
    id: 5,
    name: "Ikan Cupang Halfmoon Blue",
    description:
      "Ikan cupang halfmoon dengan warna biru metalik yang memukau. Ekor lebar sempurna dan gerakan yang elegan.",
    price: 45000,
    stock: 0,
    category: "hias",
    image_url: "/placeholder.svg?height=400&width=400&text=Cupang+Blue",
    images: [
      "/placeholder.svg?height=400&width=400&text=Cupang+Blue",
      "/placeholder.svg?height=400&width=400&text=Cupang+Tail",
    ],
    seller_id: 6,
    seller_name: "Betta Paradise",
    seller_avatar: "/placeholder.svg?height=40&width=40",
    average_rating: 4.8,
    total_reviews: 28,
    stock_status: "out_of_stock",
    created_at: "2024-06-16T11:20:00Z",
    specifications: {
      Jenis: "Halfmoon",
      Warna: "Blue Metallic",
      "Jenis Kelamin": "Jantan",
      Umur: "4-6 bulan",
    },
    tags: ["cupang", "halfmoon", "biru", "ikan hias"],
  },
  {
    id: 6,
    name: "Ikan Koi Kohaku Grade A",
    description:
      "Ikan koi kohaku grade A dengan pola putih merah yang sempurna. Cocok untuk kolam hias dan investasi jangka panjang.",
    price: 750000,
    stock: 8,
    category: "hias",
    image_url: "/placeholder.svg?height=400&width=400&text=Koi+Kohaku",
    images: [
      "/placeholder.svg?height=400&width=400&text=Koi+Kohaku",
      "/placeholder.svg?height=400&width=400&text=Koi+Pattern",
    ],
    seller_id: 7,
    seller_name: "Koi Garden Indonesia",
    seller_avatar: "/placeholder.svg?height=40&width=40",
    average_rating: 4.9,
    total_reviews: 15,
    stock_status: "in_stock",
    created_at: "2024-06-15T13:10:00Z",
    specifications: {
      Ukuran: "25-30 cm",
      Grade: "A",
      Variety: "Kohaku",
      Umur: "1-2 tahun",
    },
    tags: ["koi", "kohaku", "grade A", "investasi"],
  },
]

// Mock Reviews Data
export const MOCK_REVIEWS: Review[] = [
  {
    id: 1,
    product_id: 1,
    user_id: 3,
    user_name: "Budi Santoso",
    user_avatar: "/placeholder.svg?height=40&width=40",
    rating: 5,
    comment:
      "Ikan guppynya bagus banget! Warnanya cerah dan sehat. Packing juga aman, tidak ada yang mati. Recommended seller!",
    created_at: "2024-06-22T10:30:00Z",
    helpful_count: 8,
  },
  {
    id: 2,
    product_id: 1,
    user_id: 4,
    user_name: "Sari Dewi",
    user_avatar: "/placeholder.svg?height=40&width=40",
    rating: 4,
    comment:
      "Kualitas ikan sesuai deskripsi. Pengiriman cepat dan aman. Hanya saja ada 1 ekor yang agak pucat warnanya.",
    created_at: "2024-06-21T15:45:00Z",
    helpful_count: 5,
  },
  {
    id: 3,
    product_id: 2,
    user_id: 5,
    user_name: "Ahmad Rahman",
    user_avatar: "/placeholder.svg?height=40&width=40",
    rating: 5,
    comment: "Lelenya segar banget! Dagingnya tebal dan gurih. Cocok untuk pecel lele. Pasti order lagi!",
    created_at: "2024-06-20T09:15:00Z",
    helpful_count: 12,
  },
]

// Utility Functions
export const formatPrice = (price: number): string => {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(price)
}

export const getStockBadge = (status: string) => {
  switch (status) {
    case "in_stock":
      return { variant: "secondary" as const, text: "Tersedia", className: "bg-green-100 text-green-800" }
    case "low_stock":
      return { variant: "secondary" as const, text: "Stok Terbatas", className: "bg-yellow-100 text-yellow-800" }
    case "out_of_stock":
      return { variant: "destructive" as const, text: "Habis", className: "bg-red-100 text-red-800" }
    default:
      return { variant: "secondary" as const, text: "Tersedia", className: "bg-green-100 text-green-800" }
  }
}

export const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString("id-ID", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })
}

export const formatDateTime = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString("id-ID", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

// Cart Management
export class CartService {
  private static instance: CartService
  private listeners: Array<() => void> = []

  static getInstance(): CartService {
    if (!CartService.instance) {
      CartService.instance = new CartService()
    }
    return CartService.instance
  }

  private notifyListeners() {
    this.listeners.forEach((listener) => listener())
  }

  subscribe(listener: () => void) {
    this.listeners.push(listener)
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener)
    }
  }

  getCart(): CartItem[] {
    if (typeof window === "undefined") return []
    try {
      const cart = localStorage.getItem("iktar_cart")
      return cart ? JSON.parse(cart) : []
    } catch {
      return []
    }
  }

  addToCart(product: Product, quantity = 1): void {
    const cart = this.getCart()
    const existingItem = cart.find((item) => item.product_id === product.id)

    if (existingItem) {
      existingItem.quantity += quantity
      existingItem.subtotal = existingItem.quantity * product.price
    } else {
      const newItem: CartItem = {
        id: Date.now(),
        product_id: product.id,
        product,
        quantity,
        subtotal: quantity * product.price,
      }
      cart.push(newItem)
    }

    localStorage.setItem("iktar_cart", JSON.stringify(cart))
    this.notifyListeners()
  }

  updateQuantity(productId: number, quantity: number): void {
    const cart = this.getCart()
    const item = cart.find((item) => item.product_id === productId)

    if (item && quantity > 0) {
      item.quantity = quantity
      item.subtotal = quantity * item.product.price
      localStorage.setItem("iktar_cart", JSON.stringify(cart))
      this.notifyListeners()
    }
  }

  removeFromCart(productId: number): void {
    const cart = this.getCart().filter((item) => item.product_id !== productId)
    localStorage.setItem("iktar_cart", JSON.stringify(cart))
    this.notifyListeners()
  }

  clearCart(): void {
    localStorage.removeItem("iktar_cart")
    this.notifyListeners()
  }

  getCartTotal(): number {
    return this.getCart().reduce((total, item) => total + item.subtotal, 0)
  }

  getCartCount(): number {
    return this.getCart().reduce((total, item) => total + item.quantity, 0)
  }
}

export const cartService = CartService.getInstance()
