"use client"

import { useEffect, useState, useCallback, useRef } from "react"

export interface User {
  id: number
  name: string
  email: string
  role: "buyer" | "seller" | "admin"
  phone?: string
  avatar?: string
  created_at: string
  last_activity?: string
  session_token?: string // Added for better security
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null
}

// Improved demo accounts with hashed passwords (in real app, use bcrypt)
const hashPassword = (password: string): string => {
  // Simple hash for demo - use proper hashing in production
  return btoa(password + "salt_iktar_2024")
}

export const DEMO_ACCOUNTS = {
  "admin@iktar.com": {
    id: 1,
    name: "Admin IkTar",
    email: "admin@iktar.com",
    role: "admin" as const,
    phone: "081234567890",
    password_hash: hashPassword("admin123"),
    avatar: "/placeholder.svg?height=40&width=40",
    created_at: "2024-01-01T00:00:00Z",
  },
  "seller@iktar.com": {
    id: 2,
    name: "Penjual Demo",
    email: "seller@iktar.com",
    role: "seller" as const,
    phone: "081234567891",
    password_hash: hashPassword("seller123"),
    avatar: "/placeholder.svg?height=40&width=40",
    created_at: "2024-01-01T00:00:00Z",
  },
  "buyer@iktar.com": {
    id: 3,
    name: "Pembeli Demo",
    email: "buyer@iktar.com",
    role: "buyer" as const,
    phone: "081234567892",
    password_hash: hashPassword("buyer123"),
    avatar: "/placeholder.svg?height=40&width=40",
    created_at: "2024-01-01T00:00:00Z",
  },
}

// Session configuration
const SESSION_CONFIG = {
  DURATION: 24 * 60 * 60 * 1000, // 24 hours
  REFRESH_INTERVAL: 15 * 60 * 1000, // 15 minutes
  ACTIVITY_TIMEOUT: 30 * 60 * 1000, // 30 minutes of inactivity
}

export class AuthService {
  private static instance: AuthService
  private currentUser: User | null = null
  private listeners: Array<(user: User | null) => void> = []
  private sessionTimer: NodeJS.Timeout | null = null
  private activityTimer: NodeJS.Timeout | null = null

  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService()
    }
    return AuthService.instance
  }

  constructor() {
    if (typeof window !== "undefined") {
      this.loadUserFromStorage()
      this.setupActivityTracking()
    }
  }

  private generateSessionToken(): string {
    return btoa(Date.now() + Math.random().toString()).replace(/[^a-zA-Z0-9]/g, "")
  }

  private isSessionValid(user: User): boolean {
    if (!user.last_activity) return false

    const lastActivity = new Date(user.last_activity).getTime()
    const now = Date.now()
    const sessionAge = now - lastActivity

    return sessionAge < SESSION_CONFIG.DURATION
  }

  private loadUserFromStorage() {
    try {
      const userData = localStorage.getItem("iktar_user")
      if (userData) {
        const user = JSON.parse(userData)

        // Validate session
        if (this.isSessionValid(user)) {
          this.currentUser = user
          this.startSessionTimer()
          this.notifyListeners()
        } else {
          // Session expired, clear storage
          this.logout()
        }
      }
    } catch (error) {
      console.error("Error loading user from storage:", error)
      localStorage.removeItem("iktar_user")
    }
  }

  private saveUserToStorage(user: User) {
    try {
      const userWithSession = {
        ...user,
        session_token: this.generateSessionToken(),
        last_activity: new Date().toISOString(),
      }

      localStorage.setItem("iktar_user", JSON.stringify(userWithSession))
      this.currentUser = userWithSession
      this.startSessionTimer()
      this.notifyListeners()
    } catch (error) {
      console.error("Error saving user to storage:", error)
      throw new Error("Failed to save session")
    }
  }

  private startSessionTimer() {
    // Clear existing timer
    if (this.sessionTimer) {
      clearInterval(this.sessionTimer)
    }

    // Set up session refresh timer
    this.sessionTimer = setInterval(() => {
      if (this.currentUser && this.isSessionValid(this.currentUser)) {
        this.refreshSession()
      } else {
        this.logout()
      }
    }, SESSION_CONFIG.REFRESH_INTERVAL)
  }

  private setupActivityTracking() {
    const resetActivityTimer = () => {
      if (this.activityTimer) {
        clearTimeout(this.activityTimer)
      }

      if (this.currentUser) {
        this.activityTimer = setTimeout(() => {
          // Auto logout after inactivity
          this.logout()
        }, SESSION_CONFIG.ACTIVITY_TIMEOUT)
      }
    }

    // Track user activity with debouncing
    const activityEvents = ["mousedown", "keypress", "scroll", "touchstart"]
    let activityDebounce: NodeJS.Timeout

    const handleActivity = () => {
      if (activityDebounce) clearTimeout(activityDebounce)

      activityDebounce = setTimeout(() => {
        if (this.currentUser) {
          this.refreshSession()
          resetActivityTimer()
        }
      }, 1000) // Debounce activity tracking
    }

    activityEvents.forEach((event) => {
      document.addEventListener(event, handleActivity, { passive: true })
    })

    // Initial activity timer
    resetActivityTimer()
  }

  private notifyListeners() {
    this.listeners.forEach((listener) => {
      try {
        listener(this.currentUser)
      } catch (error) {
        console.error("Error in auth listener:", error)
      }
    })
  }

  subscribe(listener: (user: User | null) => void) {
    this.listeners.push(listener)
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener)
    }
  }

  async login(email: string, password: string): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const account = DEMO_ACCOUNTS[email as keyof typeof DEMO_ACCOUNTS]
      const passwordHash = hashPassword(password)

      if (!account || account.password_hash !== passwordHash) {
        return { success: false, error: "Email atau password salah!" }
      }

      const { password_hash: _, ...user } = account
      this.saveUserToStorage(user)

      return { success: true, user: this.currentUser! }
    } catch (error) {
      console.error("Login error:", error)
      return { success: false, error: "Terjadi kesalahan saat login" }
    }
  }

  async register(userData: {
    name: string
    email: string
    password: string
    role: "buyer" | "seller"
    phone: string
  }): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      if (DEMO_ACCOUNTS[userData.email as keyof typeof DEMO_ACCOUNTS]) {
        return { success: false, error: "Email sudah terdaftar!" }
      }

      const user: User = {
        id: Date.now(),
        name: userData.name,
        email: userData.email,
        role: userData.role,
        phone: userData.phone,
        avatar: "/placeholder.svg?height=40&width=40",
        created_at: new Date().toISOString(),
      }

      this.saveUserToStorage(user)
      return { success: true, user: this.currentUser! }
    } catch (error) {
      console.error("Registration error:", error)
      return { success: false, error: "Terjadi kesalahan saat registrasi" }
    }
  }

  logout() {
    // Clear timers
    if (this.sessionTimer) {
      clearInterval(this.sessionTimer)
      this.sessionTimer = null
    }
    if (this.activityTimer) {
      clearTimeout(this.activityTimer)
      this.activityTimer = null
    }

    // Clear user data
    this.currentUser = null

    if (typeof window !== "undefined") {
      localStorage.removeItem("iktar_user")
      localStorage.removeItem("iktar_cart")
      localStorage.removeItem("iktar_wishlist")
    }

    this.notifyListeners()
  }

  getCurrentUser(): User | null {
    return this.currentUser
  }

  isAuthenticated(): boolean {
    return this.currentUser !== null && this.isSessionValid(this.currentUser)
  }

  hasRole(role: string): boolean {
    return this.currentUser?.role === role
  }

  refreshSession(): boolean {
    if (this.currentUser && this.isSessionValid(this.currentUser)) {
      const updatedUser = {
        ...this.currentUser,
        last_activity: new Date().toISOString(),
      }

      try {
        localStorage.setItem("iktar_user", JSON.stringify(updatedUser))
        this.currentUser = updatedUser
        return true
      } catch (error) {
        console.error("Session refresh error:", error)
        return false
      }
    }
    return false
  }
}

export const authService = AuthService.getInstance()

// Improved useAuth hook with error handling
export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const mountedRef = useRef(true)

  useEffect(() => {
    const loadUser = async () => {
      try {
        setError(null)
        const userData = localStorage.getItem("iktar_user")

        if (userData) {
          const parsedUser = JSON.parse(userData)

          // Validate session
          if (authService.isAuthenticated()) {
            setUser(parsedUser)
          } else {
            // Session expired
            authService.logout()
            setError("Sesi Anda telah berakhir. Silakan login kembali.")
          }
        }
      } catch (error) {
        console.error("Error loading user:", error)
        setError("Terjadi kesalahan saat memuat data pengguna")
        authService.logout()
      } finally {
        if (mountedRef.current) {
          setIsLoading(false)
        }
      }
    }

    loadUser()

    const unsubscribe = authService.subscribe((newUser) => {
      if (mountedRef.current) {
        setUser(newUser)
        if (!newUser) {
          setError(null) // Clear error on logout
        }
      }
    })

    return () => {
      mountedRef.current = false
      unsubscribe()
    }
  }, [])

  const login = useCallback(async (email: string, password: string) => {
    setError(null)
    const result = await authService.login(email, password)
    if (!result.success) {
      setError(result.error || "Login gagal")
    }
    return result
  }, [])

  const register = useCallback(async (userData: any) => {
    setError(null)
    const result = await authService.register(userData)
    if (!result.success) {
      setError(result.error || "Registrasi gagal")
    }
    return result
  }, [])

  const logout = useCallback(() => {
    setError(null)
    authService.logout()
  }, [])

  return {
    user,
    isAuthenticated: user !== null && authService.isAuthenticated(),
    isLoading,
    error,
    login,
    register,
    logout,
    refreshSession: authService.refreshSession.bind(authService),
    clearError: () => setError(null),
  }
}
