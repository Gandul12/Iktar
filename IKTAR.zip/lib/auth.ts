"use client"

import { useEffect, useState, useCallback } from "react"

export interface User {
  id: number
  name: string
  email: string
  role: "buyer" | "seller" | "admin"
  phone?: string
  avatar?: string
  created_at: string
  last_activity?: string
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null
}

// Demo accounts with simple password check
export const DEMO_ACCOUNTS = {
  "admin@iktar.com": {
    id: 1,
    name: "Admin IkTar",
    email: "admin@iktar.com",
    role: "admin" as const,
    phone: "081234567890",
    password: "admin123",
    avatar: "/placeholder.svg?height=40&width=40",
    created_at: "2024-01-01T00:00:00Z",
  },
  "seller@iktar.com": {
    id: 2,
    name: "Penjual Demo",
    email: "seller@iktar.com",
    role: "seller" as const,
    phone: "081234567891",
    password: "seller123",
    avatar: "/placeholder.svg?height=40&width=40",
    created_at: "2024-01-01T00:00:00Z",
  },
  "buyer@iktar.com": {
    id: 3,
    name: "Pembeli Demo",
    email: "buyer@iktar.com",
    role: "buyer" as const,
    phone: "081234567892",
    password: "buyer123",
    avatar: "/placeholder.svg?height=40&width=40",
    created_at: "2024-01-01T00:00:00Z",
  },
}

// Simplified session management
const SESSION_DURATION = 24 * 60 * 60 * 1000 // 24 hours

export class AuthService {
  private static instance: AuthService
  private currentUser: User | null = null
  private listeners: Array<(user: User | null) => void> = []

  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService()
    }
    return AuthService.instance
  }

  constructor() {
    if (typeof window !== "undefined") {
      this.loadUserFromStorage()
    }
  }

  private loadUserFromStorage() {
    try {
      const userData = localStorage.getItem("iktar_user")
      if (userData) {
        const user = JSON.parse(userData)

        // Simple session validation - just check if user data exists
        if (user && user.id && user.email && user.role) {
          this.currentUser = user
          this.notifyListeners()
        } else {
          localStorage.removeItem("iktar_user")
        }
      }
    } catch (error) {
      console.error("Error loading user from storage:", error)
      localStorage.removeItem("iktar_user")
    }
  }

  private saveUserToStorage(user: User) {
    try {
      const userWithTimestamp = {
        ...user,
        last_activity: new Date().toISOString(),
      }

      localStorage.setItem("iktar_user", JSON.stringify(userWithTimestamp))
      this.currentUser = userWithTimestamp
      this.notifyListeners()
    } catch (error) {
      console.error("Error saving user to storage:", error)
      throw new Error("Failed to save session")
    }
  }

  private notifyListeners() {
    this.listeners.forEach((listener) => {
      try {
        listener(this.currentUser)
      } catch (error) {
        console.error("Error in auth listener:", error)
      }
    })
  }

  subscribe(listener: (user: User | null) => void) {
    this.listeners.push(listener)
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener)
    }
  }

  async login(email: string, password: string): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const account = DEMO_ACCOUNTS[email as keyof typeof DEMO_ACCOUNTS]

      if (!account || account.password !== password) {
        return { success: false, error: "Email atau password salah!" }
      }

      const { password: _, ...user } = account
      this.saveUserToStorage(user)

      return { success: true, user: this.currentUser! }
    } catch (error) {
      console.error("Login error:", error)
      return { success: false, error: "Terjadi kesalahan saat login" }
    }
  }

  async register(userData: {
    name: string
    email: string
    password: string
    role: "buyer" | "seller"
    phone: string
  }): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      if (DEMO_ACCOUNTS[userData.email as keyof typeof DEMO_ACCOUNTS]) {
        return { success: false, error: "Email sudah terdaftar!" }
      }

      const user: User = {
        id: Date.now(),
        name: userData.name,
        email: userData.email,
        role: userData.role,
        phone: userData.phone,
        avatar: "/placeholder.svg?height=40&width=40",
        created_at: new Date().toISOString(),
      }

      this.saveUserToStorage(user)
      return { success: true, user: this.currentUser! }
    } catch (error) {
      console.error("Registration error:", error)
      return { success: false, error: "Terjadi kesalahan saat registrasi" }
    }
  }

  logout() {
    this.currentUser = null

    if (typeof window !== "undefined") {
      localStorage.removeItem("iktar_user")
      localStorage.removeItem("iktar_cart")
      localStorage.removeItem("iktar_wishlist")
    }

    this.notifyListeners()
  }

  getCurrentUser(): User | null {
    return this.currentUser
  }

  isAuthenticated(): boolean {
    return this.currentUser !== null
  }

  hasRole(role: string): boolean {
    return this.currentUser?.role === role
  }

  refreshSession(): boolean {
    if (this.currentUser) {
      const updatedUser = {
        ...this.currentUser,
        last_activity: new Date().toISOString(),
      }

      try {
        localStorage.setItem("iktar_user", JSON.stringify(updatedUser))
        this.currentUser = updatedUser
        return true
      } catch (error) {
        console.error("Session refresh error:", error)
        return false
      }
    }
    return false
  }
}

export const authService = AuthService.getInstance()

// Simplified useAuth hook
export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Load user immediately
    const currentUser = authService.getCurrentUser()
    setUser(currentUser)
    setIsLoading(false)

    // Subscribe to auth changes
    const unsubscribe = authService.subscribe((newUser) => {
      setUser(newUser)
    })

    return unsubscribe
  }, [])

  const login = useCallback(async (email: string, password: string) => {
    setError(null)
    const result = await authService.login(email, password)
    if (!result.success) {
      setError(result.error || "Login gagal")
    }
    return result
  }, [])

  const register = useCallback(async (userData: any) => {
    setError(null)
    const result = await authService.register(userData)
    if (!result.success) {
      setError(result.error || "Registrasi gagal")
    }
    return result
  }, [])

  const logout = useCallback(() => {
    setError(null)
    authService.logout()
  }, [])

  return {
    user,
    isAuthenticated: user !== null,
    isLoading,
    error,
    login,
    register,
    logout,
    refreshSession: authService.refreshSession.bind(authService),
    clearError: () => setError(null),
  }
}
