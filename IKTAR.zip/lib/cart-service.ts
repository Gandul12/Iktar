"use client"

import { useEffect } from "react"

import { useState } from "react"

import type { Product } from "./data"

export interface CartItem extends Product {
  quantity: number
  added_at: string
}

export interface CartState {
  items: CartItem[]
  total: number
  count: number
}

class CartService {
  private static instance: CartService
  private listeners: Array<(cart: CartState) => void> = []

  static getInstance(): CartService {
    if (!CartService.instance) {
      CartService.instance = new CartService()
    }
    return CartService.instance
  }

  private notifyListeners() {
    const cart = this.getCart()
    this.listeners.forEach((listener) => {
      try {
        listener(cart)
      } catch (error) {
        console.error("Error in cart listener:", error)
      }
    })
  }

  subscribe(listener: (cart: CartState) => void) {
    this.listeners.push(listener)
    // Immediately call with current state
    listener(this.getCart())

    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener)
    }
  }

  getCart(): CartState {
    try {
      const cartData = localStorage.getItem("iktar_cart")
      const items: CartItem[] = cartData ? JSON.parse(cartData) : []

      const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0)
      const count = items.reduce((sum, item) => sum + item.quantity, 0)

      return { items, total, count }
    } catch (error) {
      console.error("Error getting cart:", error)
      return { items: [], total: 0, count: 0 }
    }
  }

  addToCart(product: Product, quantity = 1): boolean {
    try {
      const cart = this.getCart()
      const existingItemIndex = cart.items.findIndex((item) => item.id === product.id)

      if (existingItemIndex >= 0) {
        cart.items[existingItemIndex].quantity += quantity
      } else {
        const cartItem: CartItem = {
          ...product,
          quantity,
          added_at: new Date().toISOString(),
        }
        cart.items.push(cartItem)
      }

      localStorage.setItem("iktar_cart", JSON.stringify(cart.items))
      this.notifyListeners()
      return true
    } catch (error) {
      console.error("Error adding to cart:", error)
      return false
    }
  }

  removeFromCart(productId: number): boolean {
    try {
      const cart = this.getCart()
      cart.items = cart.items.filter((item) => item.id !== productId)

      localStorage.setItem("iktar_cart", JSON.stringify(cart.items))
      this.notifyListeners()
      return true
    } catch (error) {
      console.error("Error removing from cart:", error)
      return false
    }
  }

  updateQuantity(productId: number, quantity: number): boolean {
    try {
      if (quantity <= 0) {
        return this.removeFromCart(productId)
      }

      const cart = this.getCart()
      const itemIndex = cart.items.findIndex((item) => item.id === productId)

      if (itemIndex >= 0) {
        cart.items[itemIndex].quantity = quantity
        localStorage.setItem("iktar_cart", JSON.stringify(cart.items))
        this.notifyListeners()
        return true
      }

      return false
    } catch (error) {
      console.error("Error updating cart quantity:", error)
      return false
    }
  }

  clearCart(): boolean {
    try {
      localStorage.removeItem("iktar_cart")
      this.notifyListeners()
      return true
    } catch (error) {
      console.error("Error clearing cart:", error)
      return false
    }
  }
}

export const cartService = CartService.getInstance()

// React hook for cart
export function useCart() {
  const [cart, setCart] = useState<CartState>({ items: [], total: 0, count: 0 })
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = cartService.subscribe((newCart) => {
      setCart(newCart)
      setIsLoading(false)
    })

    return unsubscribe
  }, [])

  return {
    cart,
    isLoading,
    addToCart: cartService.addToCart.bind(cartService),
    removeFromCart: cartService.removeFromCart.bind(cartService),
    updateQuantity: cartService.updateQuantity.bind(cartService),
    clearCart: cartService.clearCart.bind(cartService),
  }
}
