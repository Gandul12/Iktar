from flask import Flask, render_template, request, redirect, url_for, session
import os
from functools import wraps
from datetime import datetime

# Import blueprint baru
from routes.notifications import notifications_bp
from routes.transaction_status import transaction_status_bp

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Configure upload folder
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

# Function to check if a file has an allowed extension
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Database setup (using a simple dictionary for now)
products = {}
users = {}
transactions = []

# Mock user data for demonstration
users['buyer'] = {'password': 'password', 'role': 'buyer'}
users['seller'] = {'password': 'password', 'role': 'seller'}

# Authentication decorator
def login_required(role=None):
    def wrapper(fn):
        @wraps(fn)
        def decorated_view(*args, **kwargs):
            if 'username' not in session:
                return redirect(url_for('login'))
            if role is not None and session.get('user_role') != role:
                return render_template('error.html', message="Unauthorized access.")
            return fn(*args, **kwargs)
        return decorated_view
    return wrapper

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = users.get(username)
        if user and user['password'] == password:
            session['username'] = username
            session['user_role'] = user['role']
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error="Invalid credentials")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('user_role', None)
    return redirect(url_for('index'))

@app.route('/products')
def product_list():
    return render_template('product_list.html', products=products)

@app.route('/products/add', methods=['GET', 'POST'])
@login_required(role='seller')
def add_product():
    if request.method == 'POST':
        name = request.form['name']
        price = float(request.form['price'])
        description = request.form['description']
        image = request.files['image']

        if image and allowed_file(image.filename):
            filename = image.filename
            image.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        else:
            image_path = None

        product_id = len(products) + 1
        products[product_id] = {
            'id': product_id,
            'name': name,
            'price': price,
            'description': description,
            'image_path': image_path
        }
        return redirect(url_for('product_list'))
    return render_template('add_product.html')

@app.route('/products/<int:product_id>')
def product_detail(product_id):
    product = products.get(product_id)
    if product:
        return render_template('product_detail.html', product=product)
    else:
        return render_template('error.html', message="Product not found.")

@app.route('/checkout/<int:product_id>')
@login_required(role='buyer')
def checkout(product_id):
    product = products.get(product_id)
    if product:
        return render_template('checkout.html', product=product)
    else:
        return render_template('error.html', message="Product not found.")

@app.route('/purchase/<int:product_id>', methods=['POST'])
@login_required(role='buyer')
def purchase(product_id):
    product = products.get(product_id)
    if product:
        # Simulate a purchase
        transaction_id = len(transactions) + 1
        transactions.append({
            'id': transaction_id,
            'product_id': product_id,
            'buyer': session['username'],
            'timestamp': datetime.now()
        })
        return render_template('purchase_confirmation.html', product=product, transaction_id=transaction_id)
    else:
        return render_template('error.html', message="Product not found.")

@app.route('/transactions')
@login_required()
def transaction_history():
    user_transactions = [t for t in transactions if t['buyer'] == session['username']]
    return render_template('transaction_history.html', transactions=user_transactions)

# Register blueprint
app.register_blueprint(notifications_bp)
app.register_blueprint(transaction_status_bp)

# Tambahkan context processor untuk notification count:
@app.context_processor
def inject_notification_count():
    if 'user_id' in session and session.get('user_role') == 'buyer':
        from services.notification_service import NotificationService
        unread_count = NotificationService.get_unread_count(session['user_id'])
        return {'unread_notification_count': unread_count}
    return {'unread_notification_count': 0}

if __name__ == '__main__':
    app.run(debug=True)
