#!/usr/bin/env python3
"""
IkTar - Platform Jual Beli Ikan Air Tawar
Complete Flask Application
"""

import os
import logging
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, FloatField, IntegerField, SelectField, PasswordField, SubmitField, BooleanField
from wtforms.validators import DataRequired, Email, Length, NumberRange, EqualTo, ValidationError
import enum

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'iktar-secret-key-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///iktar.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['WTF_CSRF_ENABLED'] = True

# Initialize extensions
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Silakan login untuk mengakses halaman ini.'

# ==================== MODELS ====================

class UserRole(enum.Enum):
    BUYER = 'buyer'
    SELLER = 'seller'
    ADMIN = 'admin'

class TransactionStatus(enum.Enum):
    PENDING = 'pending'
    CONFIRMED = 'confirmed'
    PROCESSING = 'processing'
    SHIPPED = 'shipped'
    DELIVERED = 'delivered'
    CANCELLED = 'cancelled'

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum(UserRole), nullable=False, default=UserRole.BUYER)
    is_active = db.Column(db.Boolean, default=True)
    
    # Session tracking
    last_login = db.Column(db.DateTime)
    last_activity = db.Column(db.DateTime)
    login_count = db.Column(db.Integer, default=0)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __init__(self, name, email, role=UserRole.BUYER):
        self.name = name
        self.email = email.lower().strip()
        self.role = role
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def is_buyer(self):
        return self.role == UserRole.BUYER
    
    def is_seller(self):
        return self.role == UserRole.SELLER
    
    def is_admin(self):
        return self.role == UserRole.ADMIN
    
    def get_role_display(self):
        role_map = {
            UserRole.BUYER: 'Pembeli',
            UserRole.SELLER: 'Penjual',
            UserRole.ADMIN: 'Administrator'
        }
        return role_map.get(self.role, self.role.value)
    
    def record_login(self):
        self.last_login = datetime.utcnow()
        self.last_activity = datetime.utcnow()
        self.login_count += 1
        try:
            db.session.commit()
        except:
            db.session.rollback()

class Product(db.Model):
    __tablename__ = 'products'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, index=True)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False, index=True)
    stock = db.Column(db.Integer, nullable=False, default=0)
    category = db.Column(db.String(50), nullable=False, index=True)
    image_url = db.Column(db.String(200))
    is_active = db.Column(db.Boolean, default=True, index=True)
    seller_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Statistics
    view_count = db.Column(db.Integer, default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    seller = db.relationship('User', backref='products')
    
    @property
    def category_display(self):
        category_map = {
            'hias': 'Ikan Hias',
            'konsumsi': 'Ikan Konsumsi',
            'predator': 'Ikan Predator',
            'bibit': 'Bibit Ikan'
        }
        return category_map.get(self.category, self.category.title())
    
    @property
    def is_in_stock(self):
        return self.stock > 0 and self.is_active

class Transaction(db.Model):
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    seller_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    status = db.Column(db.Enum(TransactionStatus), default=TransactionStatus.PENDING)
    
    # Customer Information
    customer_name = db.Column(db.String(100), nullable=False)
    customer_phone = db.Column(db.String(20), nullable=False)
    shipping_address = db.Column(db.Text, nullable=False)
    notes = db.Column(db.Text)
    
    # Tracking
    tracking_number = db.Column(db.String(50), unique=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    buyer = db.relationship('User', foreign_keys=[buyer_id], backref='buyer_transactions')
    seller = db.relationship('User', foreign_keys=[seller_id], backref='seller_transactions')

# ==================== FORMS ====================

class RegistrationForm(FlaskForm):
    name = StringField('Nama Lengkap', validators=[
        DataRequired(message='Nama lengkap harus diisi'),
        Length(min=2, max=100, message='Nama harus antara 2-100 karakter')
    ])
    
    email = StringField('Email', validators=[
        DataRequired(message='Email harus diisi'),
        Email(message='Format email tidak valid')
    ])
    
    password = PasswordField('Password', validators=[
        DataRequired(message='Password harus diisi'),
        Length(min=6, message='Password minimal 6 karakter')
    ])
    
    confirm_password = PasswordField('Konfirmasi Password', validators=[
        DataRequired(message='Konfirmasi password harus diisi'),
        EqualTo('password', message='Password tidak cocok')
    ])
    
    role = SelectField('Daftar Sebagai', choices=[
        ('buyer', 'Pembeli - Saya ingin membeli ikan segar'),
        ('seller', 'Penjual - Saya ingin menjual ikan segar')
    ], validators=[DataRequired(message='Pilih peran Anda')])
    
    submit = SubmitField('Daftar Sekarang')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data.lower()).first()
        if user:
            raise ValidationError('Email sudah terdaftar. Silakan gunakan email lain.')

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[
        DataRequired(message='Email harus diisi'),
        Email(message='Format email tidak valid')
    ])
    
    password = PasswordField('Password', validators=[
        DataRequired(message='Password harus diisi')
    ])
    
    remember_me = BooleanField('Ingat Saya')
    submit = SubmitField('Masuk')

class ProductForm(FlaskForm):
    name = StringField('Nama Produk', validators=[
        DataRequired(message='Nama produk harus diisi'),
        Length(min=3, max=100, message='Nama produk harus antara 3-100 karakter')
    ])
    
    description = TextAreaField('Deskripsi', validators=[
        DataRequired(message='Deskripsi harus diisi'),
        Length(min=10, message='Deskripsi minimal 10 karakter')
    ])
    
    price = FloatField('Harga (Rp)', validators=[
        DataRequired(message='Harga harus diisi'),
        NumberRange(min=1000, message='Harga minimal Rp 1.000')
    ])
    
    stock = IntegerField('Stok', validators=[
        DataRequired(message='Stok harus diisi'),
        NumberRange(min=0, message='Stok tidak boleh negatif')
    ])
    
    category = SelectField('Kategori', choices=[
        ('hias', 'Ikan Hias'),
        ('konsumsi', 'Ikan Konsumsi'),
        ('predator', 'Ikan Predator'),
        ('bibit', 'Bibit Ikan')
    ], validators=[DataRequired(message='Kategori harus dipilih')])
    
    submit = SubmitField('Simpan Produk')

# ==================== LOGIN MANAGER ====================

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ==================== ROUTES ====================

@app.route('/')
def index():
    products = Product.query.filter_by(is_active=True).limit(6).all()
    return render_template('index.html', products=products)

@app.route('/products')
def products():
    page = request.args.get('page', 1, type=int)
    category = request.args.get('category', '')
    search = request.args.get('search', '')
    
    query = Product.query.filter_by(is_active=True)
    
    if category:
        query = query.filter_by(category=category)
    
    if search:
        query = query.filter(Product.name.contains(search))
    
    products = query.paginate(
        page=page, per_page=12, error_out=False
    )
    
    return render_template('products.html', products=products, category=category, search=search)

@app.route('/product/<int:id>')
def product_detail(id):
    product = Product.query.get_or_404(id)
    product.view_count += 1
    db.session.commit()
    return render_template('product_detail.html', product=product)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    form = RegistrationForm()
    
    if form.validate_on_submit():
        try:
            role = UserRole.SELLER if form.role.data == 'seller' else UserRole.BUYER
            
            user = User(
                name=form.name.data.strip(),
                email=form.email.data.lower().strip(),
                role=role
            )
            user.set_password(form.password.data)
            
            db.session.add(user)
            db.session.commit()
            
            login_user(user, remember=True)
            user.record_login()
            
            flash(f'Selamat datang, {user.name}! Akun Anda berhasil dibuat.', 'success')
            
            if user.is_admin():
                return redirect(url_for('admin_dashboard'))
            elif user.is_seller():
                return redirect(url_for('seller_dashboard'))
            else:
                return redirect(url_for('buyer_dashboard'))
                
        except Exception as e:
            db.session.rollback()
            logger.error(f"Registration error: {e}")
            flash('Terjadi kesalahan saat membuat akun. Silakan coba lagi.', 'error')
    
    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    form = LoginForm()
    
    if form.validate_on_submit():
        try:
            email = form.email.data.lower().strip()
            password = form.password.data
            
            user = User.query.filter_by(email=email).first()
            
            if user and user.check_password(password) and user.is_active:
                login_user(user, remember=form.remember_me.data)
                user.record_login()
                
                flash(f'Selamat datang kembali, {user.name}!', 'success')
                
                if user.is_admin():
                    return redirect(url_for('admin_dashboard'))
                elif user.is_seller():
                    return redirect(url_for('seller_dashboard'))
                else:
                    return redirect(url_for('buyer_dashboard'))
            else:
                flash('Email atau password salah!', 'error')
                
        except Exception as e:
            flash(f'Terjadi kesalahan: {str(e)}', 'error')
    
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    user_name = current_user.name
    logout_user()
    
    # Clear all session data
    session.clear()
    
    flash(f'Sampai jumpa, {user_name}! Anda telah berhasil logout.', 'info')
    return redirect(url_for('index'))

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if not current_user.is_admin():
        flash('Akses ditolak. Anda bukan administrator.', 'error')
        return redirect(url_for('index'))
    
    stats = {
        'total_users': User.query.count(),
        'total_products': Product.query.count(),
        'total_transactions': Transaction.query.count(),
        'active_products': Product.query.filter_by(is_active=True).count()
    }
    
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    recent_products = Product.query.order_by(Product.created_at.desc()).limit(5).all()
    
    return render_template('admin_dashboard.html', stats=stats, recent_users=recent_users, recent_products=recent_products)

@app.route('/seller/dashboard')
@login_required
def seller_dashboard():
    if not current_user.is_seller():
        flash('Akses ditolak. Anda bukan penjual.', 'error')
        return redirect(url_for('index'))
    
    products = Product.query.filter_by(seller_id=current_user.id).all()
    transactions = Transaction.query.filter_by(seller_id=current_user.id).order_by(Transaction.created_at.desc()).limit(10).all()
    
    stats = {
        'total_products': len(products),
        'active_products': len([p for p in products if p.is_active]),
        'total_transactions': len(transactions),
        'total_revenue': sum(t.total_price for t in transactions)
    }
    
    return render_template('seller_dashboard.html', products=products, transactions=transactions, stats=stats)

@app.route('/buyer/dashboard')
@login_required
def buyer_dashboard():
    if not current_user.is_buyer():
        flash('Akses ditolak. Anda bukan pembeli.', 'error')
        return redirect(url_for('index'))
    
    transactions = Transaction.query.filter_by(buyer_id=current_user.id).order_by(Transaction.created_at.desc()).limit(10).all()
    
    return render_template('buyer_dashboard.html', transactions=transactions)

@app.route('/seller/add-product', methods=['GET', 'POST'])
@login_required
def add_product():
    if not current_user.is_seller():
        flash('Akses ditolak. Anda bukan penjual.', 'error')
        return redirect(url_for('index'))
    
    form = ProductForm()
    
    if form.validate_on_submit():
        try:
            product = Product(
                name=form.name.data,
                description=form.description.data,
                price=form.price.data,
                stock=form.stock.data,
                category=form.category.data,
                seller_id=current_user.id
            )
            
            db.session.add(product)
            db.session.commit()
            
            flash('Produk berhasil ditambahkan!', 'success')
            return redirect(url_for('seller_dashboard'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Add product error: {e}")
            flash('Terjadi kesalahan saat menambahkan produk.', 'error')
    
    return render_template('add_product.html', form=form)

@app.route('/seller/edit-product/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_product(id):
    if not current_user.is_seller():
        flash('Akses ditolak. Anda bukan penjual.', 'error')
        return redirect(url_for('index'))
    
    product = Product.query.get_or_404(id)
    
    if product.seller_id != current_user.id:
        flash('Anda tidak memiliki akses untuk mengedit produk ini.', 'error')
        return redirect(url_for('seller_dashboard'))
    
    form = ProductForm(obj=product)
    
    if form.validate_on_submit():
        try:
            form.populate_obj(product)
            product.updated_at = datetime.utcnow()
            
            db.session.commit()
            
            flash('Produk berhasil diperbarui!', 'success')
            return redirect(url_for('seller_dashboard'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Edit product error: {e}")
            flash('Terjadi kesalahan saat memperbarui produk.', 'error')
    
    return render_template('edit_product.html', form=form, product=product)

@app.route('/seller/delete-product/<int:id>', methods=['POST'])
@login_required
def delete_product(id):
    if not current_user.is_seller():
        flash('Akses ditolak. Anda bukan penjual.', 'error')
        return redirect(url_for('index'))
    
    product = Product.query.get_or_404(id)
    
    if product.seller_id != current_user.id:
        flash('Anda tidak memiliki akses untuk menghapus produk ini.', 'error')
        return redirect(url_for('seller_dashboard'))
    
    try:
        db.session.delete(product)
        db.session.commit()
        flash('Produk berhasil dihapus!', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Delete product error: {e}")
        flash('Terjadi kesalahan saat menghapus produk.', 'error')
    
    return redirect(url_for('seller_dashboard'))

# ==================== INITIALIZE DATABASE ====================

def create_sample_data():
    """Create sample data for development"""
    try:
        # Create admin user
        if not User.query.filter_by(email='admin@iktar.com').first():
            admin = User(
                name='Administrator',
                email='admin@iktar.com',
                role=UserRole.ADMIN
            )
            admin.set_password('admin123')
            db.session.add(admin)
        
        # Create sample seller
        if not User.query.filter_by(email='seller@iktar.com').first():
            seller = User(
                name='Penjual Ikan',
                email='seller@iktar.com',
                role=UserRole.SELLER
            )
            seller.set_password('seller123')
            db.session.add(seller)
            db.session.commit()
            
            # Create sample products
            products = [
                {
                    'name': 'Ikan Nila Segar',
                    'description': 'Ikan nila segar hasil budidaya lokal, kualitas terbaik untuk konsumsi keluarga.',
                    'price': 25000,
                    'stock': 50,
                    'category': 'konsumsi',
                    'seller_id': seller.id
                },
                {
                    'name': 'Ikan Cupang Hias',
                    'description': 'Ikan cupang hias dengan warna indah, cocok untuk aquarium rumah.',
                    'price': 15000,
                    'stock': 30,
                    'category': 'hias',
                    'seller_id': seller.id
                },
                {
                    'name': 'Ikan Lele Jumbo',
                    'description': 'Ikan lele jumbo segar, daging tebal dan gurih.',
                    'price': 20000,
                    'stock': 40,
                    'category': 'konsumsi',
                    'seller_id': seller.id
                }
            ]
            
            for product_data in products:
                product = Product(**product_data)
                db.session.add(product)
        
        # Create sample buyer
        if not User.query.filter_by(email='buyer@iktar.com').first():
            buyer = User(
                name='Pembeli Ikan',
                email='buyer@iktar.com',
                role=UserRole.BUYER
            )
            buyer.set_password('buyer123')
            db.session.add(buyer)
        
        db.session.commit()
        print("✅ Sample data created successfully!")
        
    except Exception as e:
        print(f"⚠️ Error creating sample data: {e}")
        db.session.rollback()

# ==================== MAIN ====================

if __name__ == '__main__':
    with app.app_context():
        # Create tables
        db.create_all()
        
        # Create sample data
        create_sample_data()
    
    print("🐟 IkTar Application Starting...")
    print("📍 URL: http://localhost:5000")
    print("👑 Admin: admin@iktar.com / admin123")
    print("🏪 Seller: seller@iktar.com / seller123")
    print("🛒 Buyer: buyer@iktar.com / buyer123")
    print("=" * 50)
    
    app.run(debug=True, host='0.0.0.0', port=5000)
