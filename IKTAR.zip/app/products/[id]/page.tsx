"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Navbar } from "@/components/layout/navbar"
import { useAuth } from "@/lib/auth"
import {
  ShoppingCart,
  Heart,
  Share2,
  Star,
  MapPin,
  Calendar,
  Package,
  Edit,
  Trash2,
  BarChart3,
  Settings,
  Shield,
  AlertTriangle,
} from "lucide-react"
import { MOCK_PRODUCTS, formatPrice, getStockBadge, type Product } from "@/lib/data"

export default function ProductDetailPage() {
  const params = useParams()
  const { user, isAuthenticated } = useAuth()
  const [product, setProduct] = useState<Product | null>(null)
  const [loading, setLoading] = useState(true)
  const [isInCart, setIsInCart] = useState(false)
  const [isInWishlist, setIsInWishlist] = useState(false)

  useEffect(() => {
    const productId = Number.parseInt(params.id as string)
    const foundProduct = MOCK_PRODUCTS.find((p) => p.id === productId)

    setTimeout(() => {
      setProduct(foundProduct || null)
      setLoading(false)
    }, 500)

    // Check if product is in cart or wishlist
    if (foundProduct) {
      const cart = JSON.parse(localStorage.getItem("iktar_cart") || "[]")
      const wishlist = JSON.parse(localStorage.getItem("iktar_wishlist") || "[]")

      setIsInCart(cart.some((item: any) => item.id === foundProduct.id))
      setIsInWishlist(wishlist.some((item: any) => item.id === foundProduct.id))
    }
  }, [params.id])

  const handleAddToCart = () => {
    if (!product) return

    const cart = JSON.parse(localStorage.getItem("iktar_cart") || "[]")
    const existingItem = cart.find((item: any) => item.id === product.id)

    if (existingItem) {
      existingItem.quantity += 1
    } else {
      cart.push({ ...product, quantity: 1 })
    }

    localStorage.setItem("iktar_cart", JSON.stringify(cart))
    setIsInCart(true)
  }

  const handleAddToWishlist = () => {
    if (!product) return

    const wishlist = JSON.parse(localStorage.getItem("iktar_wishlist") || "[]")

    if (!isInWishlist) {
      wishlist.push(product)
      localStorage.setItem("iktar_wishlist", JSON.stringify(wishlist))
      setIsInWishlist(true)
    }
  }

  // Role-based action buttons
  const renderActionButtons = () => {
    if (!isAuthenticated) {
      return (
        <div className="space-y-3">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-blue-800 text-sm mb-3">
              <Shield className="inline w-4 h-4 mr-1" />
              Silakan login untuk melakukan pembelian
            </p>
            <div className="flex gap-2">
              <Button asChild className="flex-1">
                <Link href="/auth/login">Login</Link>
              </Button>
              <Button asChild variant="outline" className="flex-1">
                <Link href="/auth/register">Daftar</Link>
              </Button>
            </div>
          </div>
        </div>
      )
    }

    // Admin Actions
    if (user?.role === "admin") {
      return (
        <div className="space-y-3">
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <p className="text-purple-800 text-sm mb-3 flex items-center">
              <Shield className="w-4 h-4 mr-1" />
              Panel Admin - Kelola Produk
            </p>
            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" size="sm" className="text-blue-600 border-blue-200">
                <Edit className="w-4 h-4 mr-1" />
                Edit Produk
              </Button>
              <Button variant="outline" size="sm" className="text-red-600 border-red-200">
                <Trash2 className="w-4 h-4 mr-1" />
                Hapus
              </Button>
              <Button variant="outline" size="sm" className="text-green-600 border-green-200">
                <BarChart3 className="w-4 h-4 mr-1" />
                Statistik
              </Button>
              <Button variant="outline" size="sm" className="text-gray-600 border-gray-200">
                <Settings className="w-4 h-4 mr-1" />
                Kelola
              </Button>
            </div>
          </div>

          {/* Admin can still see buyer actions for testing */}
          <details className="bg-gray-50 border rounded-lg p-4">
            <summary className="text-sm text-gray-600 cursor-pointer">Preview Mode Pembeli (untuk testing)</summary>
            <div className="mt-3 space-y-2">
              {product?.stock_status === "in_stock" ? (
                <>
                  <Button onClick={handleAddToCart} className="w-full" disabled={isInCart}>
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    {isInCart ? "Sudah di Keranjang" : "Tambah ke Keranjang"}
                  </Button>
                  <Button variant="outline" className="w-full">
                    Beli Sekarang
                  </Button>
                </>
              ) : (
                <Button disabled className="w-full">
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Stok Habis
                </Button>
              )}
            </div>
          </details>
        </div>
      )
    }

    // Seller Actions
    if (user?.role === "seller") {
      const isOwnProduct = product?.seller_id === user.id

      if (isOwnProduct) {
        return (
          <div className="space-y-3">
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <p className="text-green-800 text-sm mb-3">
                <Package className="inline w-4 h-4 mr-1" />
                Ini adalah produk Anda
              </p>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm" className="text-blue-600 border-blue-200">
                  <Edit className="w-4 h-4 mr-1" />
                  Edit Produk
                </Button>
                <Button variant="outline" size="sm" className="text-gray-600 border-gray-200">
                  <BarChart3 className="w-4 h-4 mr-1" />
                  Lihat Statistik
                </Button>
              </div>
            </div>
          </div>
        )
      } else {
        return (
          <div className="space-y-3">
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
              <p className="text-orange-800 text-sm">
                <AlertTriangle className="inline w-4 h-4 mr-1" />
                Sebagai penjual, Anda tidak dapat membeli produk. Login sebagai pembeli untuk berbelanja.
              </p>
            </div>
          </div>
        )
      }
    }

    // Buyer Actions (default)
    if (user?.role === "buyer") {
      return (
        <div className="space-y-3">
          {product?.stock_status === "in_stock" ? (
            <>
              <Button onClick={handleAddToCart} className="w-full" disabled={isInCart}>
                <ShoppingCart className="w-4 h-4 mr-2" />
                {isInCart ? "Sudah di Keranjang" : "Tambah ke Keranjang"}
              </Button>
              <Button variant="outline" className="w-full">
                Beli Sekarang
              </Button>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={handleAddToWishlist}
                  disabled={isInWishlist}
                >
                  <Heart className={`w-4 h-4 mr-1 ${isInWishlist ? "fill-red-500 text-red-500" : ""}`} />
                  {isInWishlist ? "Di Wishlist" : "Wishlist"}
                </Button>
                <Button variant="outline" size="sm" className="flex-1">
                  <Share2 className="w-4 h-4 mr-1" />
                  Bagikan
                </Button>
              </div>
            </>
          ) : (
            <Button disabled className="w-full">
              <AlertTriangle className="w-4 h-4 mr-2" />
              Stok Habis
            </Button>
          )}
        </div>
      )
    }

    return null
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="h-96 bg-gray-200 rounded-lg"></div>
              <div className="space-y-4">
                <div className="h-8 bg-gray-200 rounded"></div>
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-6 bg-gray-200 rounded w-1/2"></div>
                <div className="h-20 bg-gray-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Produk Tidak Ditemukan</h1>
            <p className="text-gray-600 mb-6">Produk yang Anda cari tidak tersedia.</p>
            <Button asChild>
              <Link href="/products">Kembali ke Produk</Link>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  const stockBadge = getStockBadge(product.stock_status)

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center space-x-2 text-sm text-gray-600 mb-6">
          <Link href="/" className="hover:text-blue-600">
            Home
          </Link>
          <span>/</span>
          <Link href="/products" className="hover:text-blue-600">
            Produk
          </Link>
          <span>/</span>
          <span className="text-gray-900">{product.name}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Product Image */}
          <div className="space-y-4">
            <div className="relative">
              <img
                src={product.image_url || "/placeholder.svg?height=400&width=400"}
                alt={product.name}
                className="w-full h-96 object-cover rounded-lg"
              />
              <Badge variant={stockBadge.variant} className={`absolute top-4 right-4 ${stockBadge.className}`}>
                {stockBadge.text}
              </Badge>
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="font-medium">{product.average_rating}</span>
                  <span className="text-gray-500">({product.total_reviews} ulasan)</span>
                </div>
                <Badge variant="outline">{product.category}</Badge>
              </div>
              <p className="text-4xl font-bold text-blue-600 mb-4">{formatPrice(product.price)}</p>
            </div>

            <Separator />

            {/* Product Description */}
            <div>
              <h3 className="font-semibold mb-2">Deskripsi Produk</h3>
              <p className="text-gray-600 leading-relaxed">{product.description}</p>
            </div>

            <Separator />

            {/* Seller Info */}
            <div>
              <h3 className="font-semibold mb-3">Informasi Penjual</h3>
              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="font-semibold text-blue-600">{product.seller_name.charAt(0).toUpperCase()}</span>
                </div>
                <div className="flex-1">
                  <p className="font-medium">{product.seller_name}</p>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {product.location}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      Bergabung 2023
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Action Buttons - Role-based rendering */}
            {renderActionButtons()}
          </div>
        </div>

        {/* Additional Product Info */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Spesifikasi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Kategori:</span>
                <span className="font-medium">{product.category}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Stok:</span>
                <span className="font-medium">{stockBadge.text}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Lokasi:</span>
                <span className="font-medium">{product.location}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Rating:</span>
                <span className="font-medium">{product.average_rating}/5</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Pengiriman & Garansi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Pengiriman:</span>
                <span className="font-medium">Gratis ongkir</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Estimasi:</span>
                <span className="font-medium">1-3 hari</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Garansi:</span>
                <span className="font-medium">7 hari</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Retur:</span>
                <span className="font-medium">Bisa retur</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
