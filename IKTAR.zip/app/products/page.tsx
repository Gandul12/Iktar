"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, ShoppingCart } from "lucide-react"
import { Navbar } from "@/components/layout/navbar"

interface Product {
  id: number
  name: string
  description: string
  price: number
  stock: number
  category: string
  image_url: string
  seller_name: string
  stock_status: string
}

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    fetchProducts()
  }, [])

  const fetchProducts = async () => {
    try {
      const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? ""
      const response = await fetch(`${API_BASE}/api/products`)
      const data = await response.json()

      if (data.products) {
        setProducts(data.products)
      }
    } catch (error) {
      console.warn("Products API not available, using fallback data")
      // Fallback data
      const mockProducts = Array.from({ length: 12 }).map((_, i) => ({
        id: i + 1,
        name: `Ikan Demo #${i + 1}`,
        description: "Deskripsi ikan demo untuk tujuan preview.",
        price: 12000 + i * 1500,
        stock: 20 - i,
        category: ["hias", "konsumsi", "predator", "bibit"][i % 4],
        image_url: "/placeholder.svg?height=192&width=360",
        seller_name: "Penjual Demo",
        stock_status: i % 3 === 0 ? "low_stock" : "in_stock",
      }))
      setProducts(mockProducts)
    } finally {
      setLoading(false)
    }
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(price)
  }

  const getStockBadgeVariant = (status: string) => {
    switch (status) {
      case "in_stock":
        return "default"
      case "low_stock":
        return "secondary"
      case "out_of_stock":
        return "destructive"
      default:
        return "default"
    }
  }

  const getStockText = (status: string) => {
    switch (status) {
      case "in_stock":
        return "Tersedia"
      case "low_stock":
        return "Stok Terbatas"
      case "out_of_stock":
        return "Habis"
      default:
        return "Tersedia"
    }
  }

  const filteredProducts = products.filter((product) => product.name.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50">
      {/* Navigation Header */}
      <Navbar />

      {/* Header */}
      <section className="py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Semua Produk</h1>
          <p className="text-xl text-gray-600 mb-8">Temukan ikan berkualitas dari penjual terpercaya</p>

          {/* Search Bar */}
          <div className="max-w-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                type="text"
                placeholder="Cari produk..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="pb-16 px-6">
        <div className="max-w-7xl mx-auto">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(12)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <div className="h-48 bg-gray-200 rounded-t-lg"></div>
                  <CardContent className="p-4">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded mb-4"></div>
                    <div className="h-6 bg-gray-200 rounded"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <Card key={product.id} className="group hover:shadow-lg transition-shadow duration-300">
                  <div className="relative overflow-hidden rounded-t-lg">
                    <img
                      src={product.image_url || "/placeholder.svg"}
                      alt={product.name}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <Badge variant={getStockBadgeVariant(product.stock_status)} className="absolute top-2 right-2">
                      {getStockText(product.stock_status)}
                    </Badge>
                  </div>

                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg line-clamp-1">{product.name}</CardTitle>
                    <CardDescription className="line-clamp-2">{product.description}</CardDescription>
                  </CardHeader>

                  <CardContent className="pb-2">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-2xl font-bold text-blue-600">{formatPrice(product.price)}</span>
                      <Badge variant="outline">{product.category}</Badge>
                    </div>
                    <p className="text-sm text-gray-500">Penjual: {product.seller_name}</p>
                  </CardContent>

                  <CardFooter className="pt-2">
                    <div className="flex gap-2 w-full">
                      <Button asChild variant="outline" size="sm" className="flex-1">
                        <Link href={`/products/${product.id}`}>Detail</Link>
                      </Button>
                      <Button size="sm" className="flex-1" disabled={product.stock_status === "out_of_stock"}>
                        <ShoppingCart className="mr-2 h-4 w-4" />
                        {product.stock_status === "out_of_stock" ? "Habis" : "Beli"}
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}

          {!loading && filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">Tidak ada produk yang ditemukan</p>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
