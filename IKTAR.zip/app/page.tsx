"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Navbar } from "@/components/layout/navbar"
import { useAuth } from "@/lib/auth"
import {
  Search,
  ShoppingCart,
  Fish,
  TrendingUp,
  Users,
  Package,
  Star,
  ArrowRight,
  CheckCircle,
  Shield,
  Truck,
  HeadphonesIcon,
  Settings,
} from "lucide-react"
import { MOCK_PRODUCTS, formatPrice, getStockBadge, type Product } from "@/lib/data"

export default function HomePage() {
  const { user, isAuthenticated, isLoading } = useAuth()
  const [products, setProducts] = useState<Product[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [loading, setLoading] = useState(true)
  const [mounted, setMounted] = useState(false)

  // Ensure component is mounted on client-side
  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    // Simulate loading
    setTimeout(() => {
      setProducts(MOCK_PRODUCTS.slice(0, 8))
      setLoading(false)
    }, 1000)
  }, [])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      window.location.href = `/products?search=${encodeURIComponent(searchQuery)}`
    }
  }

  const stats = {
    totalProducts: 150,
    totalSellers: 25,
    totalBuyers: 500,
    categories: 4,
  }

  // Don't render auth-dependent content until mounted
  if (!mounted || isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden gradient-bg">
        <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:50px_50px]" />
        <div className="relative container mx-auto px-4 py-20 lg:py-32">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center justify-center p-2 bg-blue-100 rounded-full mb-6 animate-fade-in">
              <Fish className="h-8 w-8 text-blue-600" />
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold font-display mb-6 animate-fade-in">
              Selamat Datang di <span className="text-gradient">IkTar</span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto animate-fade-in">
              Platform marketplace terpercaya untuk jual beli ikan air tawar berkualitas tinggi. Temukan ikan hias,
              konsumsi, predator, dan bibit terbaik dari penjual terpercaya.
            </p>

            {/* Search Bar */}
            <form onSubmit={handleSearch} className="max-w-2xl mx-auto mb-8 animate-fade-in">
              <div className="relative glass-effect rounded-2xl p-2">
                <div className="flex items-center">
                  <Search className="absolute left-6 h-5 w-5 text-gray-400" />
                  <Input
                    type="text"
                    placeholder="Cari ikan yang Anda inginkan..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-14 pr-4 py-4 text-lg border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
                  />
                  <Button type="submit" size="lg" className="btn-primary mr-2">
                    Cari
                  </Button>
                </div>
              </div>
            </form>

            {/* CTA Buttons - Only show if not authenticated */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in">
              <Button size="lg" asChild className="btn-primary">
                <Link href="/products">
                  <Package className="mr-2 h-5 w-5" />
                  Jelajahi Produk
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              {!isAuthenticated && (
                <Button size="lg" variant="outline" asChild className="btn-secondary">
                  <Link href="/auth/register">
                    <Users className="mr-2 h-5 w-5" />
                    Bergabung Sekarang
                  </Link>
                </Button>
              )}
            </div>

            {/* Welcome message for authenticated users - only render on client */}
            {mounted && isAuthenticated && user && (
              <div className="mt-8 p-6 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Selamat datang kembali, {user.name}! 👋</h3>
                <p className="text-gray-600 mb-4">
                  {user.role === "admin" && "Kelola platform IkTar dengan dashboard admin Anda."}
                  {user.role === "seller" && "Kelola toko dan produk Anda dengan mudah."}
                  {user.role === "buyer" && "Temukan ikan berkualitas terbaik untuk kebutuhan Anda."}
                </p>
                <Button asChild variant="outline" className="bg-white/20 border-white/30 hover:bg-white/30">
                  <Link href={`/dashboard/${user.role}`}>
                    Ke Dashboard
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">Mengapa Memilih IkTar?</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Platform terpercaya dengan berbagai keunggulan untuk pengalaman jual beli terbaik
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: Shield,
                title: "Terpercaya",
                description: "Penjual terverifikasi dan produk berkualitas terjamin",
              },
              {
                icon: Truck,
                title: "Pengiriman Cepat",
                description: "Sistem pengiriman yang cepat dan aman ke seluruh Indonesia",
              },
              {
                icon: HeadphonesIcon,
                title: "Dukungan 24/7",
                description: "Tim customer service siap membantu Anda kapan saja",
              },
              {
                icon: CheckCircle,
                title: "Garansi Kualitas",
                description: "Jaminan kualitas produk atau uang kembali",
              },
            ].map((feature, index) => (
              <Card key={index} className="text-center border-0 shadow-lg card-hover">
                <CardContent className="pt-8">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                    <feature.icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 gradient-bg">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: Package, label: "Produk Tersedia", value: `${stats.totalProducts}+`, color: "text-green-600" },
              { icon: Users, label: "Penjual Terpercaya", value: `${stats.totalSellers}+`, color: "text-blue-600" },
              { icon: TrendingUp, label: "Pembeli Aktif", value: `${stats.totalBuyers}+`, color: "text-purple-600" },
              { icon: Fish, label: "Kategori Ikan", value: stats.categories, color: "text-orange-600" },
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div
                  className={`inline-flex items-center justify-center w-16 h-16 rounded-full mb-4 ${stat.color.replace("text-", "bg-").replace("-600", "-100")}`}
                >
                  <stat.icon className={`h-8 w-8 ${stat.color}`} />
                </div>
                <h3 className="text-3xl font-bold font-display mb-2">{stat.value}</h3>
                <p className="text-gray-600">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">Produk Terbaru</h2>
            <p className="text-xl text-gray-600">Temukan ikan-ikan berkualitas terbaik dari penjual terpercaya</p>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <div className="h-48 bg-gray-200 rounded-t-lg"></div>
                  <CardContent className="p-4">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded mb-4"></div>
                    <div className="h-6 bg-gray-200 rounded"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {products.map((product) => {
                const stockBadge = getStockBadge(product.stock_status)

                return (
                  <Card key={product.id} className="group card-hover border-0 shadow-lg overflow-hidden">
                    <div className="relative overflow-hidden">
                      <img
                        src={product.image_url || "/placeholder.svg"}
                        alt={product.name}
                        className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <Badge variant={stockBadge.variant} className={`absolute top-3 right-3 ${stockBadge.className}`}>
                        {stockBadge.text}
                      </Badge>
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
                    </div>

                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg line-clamp-1 group-hover:text-blue-600 transition-colors">
                        {product.name}
                      </CardTitle>
                      <CardDescription className="line-clamp-2">{product.description}</CardDescription>
                    </CardHeader>

                    <CardContent className="pb-2">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-2xl font-bold text-blue-600">{formatPrice(product.price)}</span>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium">{product.average_rating}</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className="text-xs">
                          {product.category}
                        </Badge>
                        <p className="text-sm text-gray-500">{product.seller_name}</p>
                      </div>
                    </CardContent>

                    <CardFooter className="pt-2">
                      <div className="flex gap-2 w-full">
                        <Button asChild variant="outline" size="sm" className="flex-1">
                          <Link href={`/products/${product.id}`}>Detail</Link>
                        </Button>

                        {/* Role-based action button */}
                        {mounted && isAuthenticated && user ? (
                          // Admin - Show manage button
                          user.role === "admin" ? (
                            <Button size="sm" variant="outline" className="flex-1 text-purple-600 border-purple-200">
                              <Settings className="mr-2 h-4 w-4" />
                              Kelola
                            </Button>
                          ) : // Seller - Show different action based on ownership
                          user.role === "seller" ? (
                            <Button size="sm" variant="outline" className="flex-1 text-green-600 border-green-200">
                              <Package className="mr-2 h-4 w-4" />
                              {product.seller_id === user.id ? "Edit" : "Lihat"}
                            </Button>
                          ) : (
                            // Buyer - Show buy button
                            <Button size="sm" className="flex-1" disabled={product.stock_status === "out_of_stock"}>
                              <ShoppingCart className="mr-2 h-4 w-4" />
                              {product.stock_status === "out_of_stock" ? "Habis" : "Beli"}
                            </Button>
                          )
                        ) : (
                          // Not authenticated - Show buy button that redirects to login
                          <Button
                            asChild
                            size="sm"
                            className="flex-1"
                            disabled={product.stock_status === "out_of_stock"}
                          >
                            <Link href="/auth/login">
                              <ShoppingCart className="mr-2 h-4 w-4" />
                              {product.stock_status === "out_of_stock" ? "Habis" : "Beli"}
                            </Link>
                          </Button>
                        )}
                      </div>
                    </CardFooter>
                  </Card>
                )
              })}
            </div>
          )}

          <div className="text-center mt-12">
            <Button asChild size="lg" variant="outline" className="btn-secondary">
              <Link href="/products">
                Lihat Semua Produk
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 gradient-bg">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">Kategori Ikan</h2>
            <p className="text-xl text-gray-600">Pilih kategori sesuai kebutuhan Anda</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: "Ikan Hias", category: "hias", icon: "🐠", description: "Ikan cantik untuk aquarium", count: 45 },
              {
                name: "Ikan Konsumsi",
                category: "konsumsi",
                icon: "🐟",
                description: "Ikan segar untuk masakan",
                count: 32,
              },
              {
                name: "Ikan Predator",
                category: "predator",
                icon: "🦈",
                description: "Ikan predator eksotis",
                count: 18,
              },
              { name: "Bibit Ikan", category: "bibit", icon: "🥚", description: "Bibit untuk budidaya", count: 25 },
            ].map((cat) => (
              <Link key={cat.category} href={`/products?category=${cat.category}`}>
                <Card className="group card-hover border-0 shadow-lg glass-effect cursor-pointer">
                  <CardContent className="p-8 text-center">
                    <div className="text-5xl mb-4 group-hover:scale-110 transition-transform duration-300">
                      {cat.icon}
                    </div>
                    <h3 className="text-xl font-semibold mb-2 group-hover:text-blue-600 transition-colors">
                      {cat.name}
                    </h3>
                    <p className="text-gray-600 mb-3">{cat.description}</p>
                    <Badge variant="secondary" className="text-xs">
                      {cat.count} produk
                    </Badge>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section - Only show if not authenticated and mounted */}
      {mounted && !isAuthenticated && (
        <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">Siap Memulai Bisnis Ikan Anda?</h2>
            <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
              Bergabunglah dengan ribuan penjual dan pembeli di platform IkTar. Mulai jual beli ikan dengan mudah dan
              aman.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100">
                <Link href="/auth/register?role=seller">
                  <Package className="mr-2 h-5 w-5" />
                  Jadi Penjual
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-blue-600"
              >
                <Link href="/auth/register?role=buyer">
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  Jadi Pembeli
                </Link>
              </Button>
            </div>
          </div>
        </section>
      )}

      {/* Alternative CTA Section for authenticated users */}
      {mounted && isAuthenticated && user && (
        <section className="py-20 bg-gradient-to-r from-green-600 to-green-700 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">
              {user.role === "admin" && "Kelola Platform IkTar"}
              {user.role === "seller" && "Tingkatkan Penjualan Anda"}
              {user.role === "buyer" && "Temukan Ikan Terbaik"}
            </h2>
            <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
              {user.role === "admin" && "Monitor aktivitas platform dan kelola semua aspek bisnis IkTar."}
              {user.role === "seller" && "Tambah produk baru, kelola pesanan, dan tingkatkan penjualan Anda."}
              {user.role === "buyer" && "Jelajahi ribuan produk ikan berkualitas dari penjual terpercaya."}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" variant="secondary" className="bg-white text-green-600 hover:bg-gray-100">
                <Link href={`/dashboard/${user.role}`}>
                  <Package className="mr-2 h-5 w-5" />
                  Ke Dashboard
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-green-600"
              >
                <Link href="/products">
                  <Search className="mr-2 h-5 w-5" />
                  Jelajahi Produk
                </Link>
              </Button>
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Fish className="h-8 w-8 text-blue-400" />
                <span className="text-2xl font-bold font-display">IkTar</span>
              </div>
              <p className="text-gray-400 mb-4">
                Platform marketplace terpercaya untuk jual beli ikan air tawar berkualitas tinggi.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Produk</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/products?category=hias" className="hover:text-white transition-colors">
                    Ikan Hias
                  </Link>
                </li>
                <li>
                  <Link href="/products?category=konsumsi" className="hover:text-white transition-colors">
                    Ikan Konsumsi
                  </Link>
                </li>
                <li>
                  <Link href="/products?category=predator" className="hover:text-white transition-colors">
                    Ikan Predator
                  </Link>
                </li>
                <li>
                  <Link href="/products?category=bibit" className="hover:text-white transition-colors">
                    Bibit Ikan
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Perusahaan</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-white transition-colors">
                    Tentang Kami
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white transition-colors">
                    Kontak
                  </Link>
                </li>
                <li>
                  <Link href="/help" className="hover:text-white transition-colors">
                    Bantuan
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-white transition-colors">
                    Syarat & Ketentuan
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Akun</h3>
              <ul className="space-y-2 text-gray-400">
                {!isAuthenticated ? (
                  <>
                    <li>
                      <Link href="/auth/login" className="hover:text-white transition-colors">
                        Masuk
                      </Link>
                    </li>
                    <li>
                      <Link href="/auth/register" className="hover:text-white transition-colors">
                        Daftar
                      </Link>
                    </li>
                    <li>
                      <Link href="/auth/register?role=seller" className="hover:text-white transition-colors">
                        Jadi Penjual
                      </Link>
                    </li>
                  </>
                ) : (
                  <>
                    <li>
                      <Link href={`/dashboard/${user?.role}`} className="hover:text-white transition-colors">
                        Dashboard
                      </Link>
                    </li>
                    <li>
                      <Link href="/profile" className="hover:text-white transition-colors">
                        Profil
                      </Link>
                    </li>
                    <li>
                      <Link href="/settings" className="hover:text-white transition-colors">
                        Pengaturan
                      </Link>
                    </li>
                  </>
                )}
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 IkTar. Semua hak dilindungi.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
