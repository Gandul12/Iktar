// Main JavaScript for Iktar
const bootstrap = window.bootstrap // Declare the bootstrap variable

document.addEventListener("DOMContentLoaded", () => {
  // Initialize tooltips
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  var tooltipList = tooltipTriggerList.map((tooltipTriggerEl) => new bootstrap.Tooltip(tooltipTriggerEl))

  // Initialize popovers
  var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
  var popoverList = popoverTriggerList.map((popoverTriggerEl) => new bootstrap.Popover(popoverTriggerEl))

  // Auto-hide alerts after 5 seconds
  const alerts = document.querySelectorAll(".alert")
  alerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.opacity = "0"
      setTimeout(() => {
        alert.remove()
      }, 300)
    }, 5000)
  })

  // Confirm delete actions
  var deleteButtons = document.querySelectorAll(".btn-delete")
  deleteButtons.forEach((button) => {
    button.addEventListener("click", (e) => {
      if (!confirm("Apakah Anda yakin ingin menghapus item ini?")) {
        e.preventDefault()
      }
    })
  })

  // Format currency inputs
  var currencyInputs = document.querySelectorAll(".currency-input")
  currencyInputs.forEach((input) => {
    input.addEventListener("input", (e) => {
      var value = e.target.value.replace(/[^\d]/g, "")
      var formatted = new Intl.NumberFormat("id-ID").format(value)
      e.target.value = formatted
    })
  })

  // Search suggestions
  var searchInput = document.getElementById("search-input")
  if (searchInput) {
    var suggestionsContainer = document.getElementById("search-suggestions")
    var debounceTimer

    searchInput.addEventListener("input", (e) => {
      clearTimeout(debounceTimer)
      var query = e.target.value.trim()

      if (query.length < 2) {
        suggestionsContainer.innerHTML = ""
        suggestionsContainer.style.display = "none"
        return
      }

      debounceTimer = setTimeout(() => {
        fetch("/api/search-suggestions?q=" + encodeURIComponent(query))
          .then((response) => response.json())
          .then((data) => {
            suggestionsContainer.innerHTML = ""

            if (data.length > 0) {
              data.forEach((item) => {
                var div = document.createElement("div")
                div.className = "suggestion-item p-2 border-bottom"
                div.innerHTML =
                  "<strong>" + item.name + '</strong> <small class="text-muted">(' + item.category + ")</small>"
                div.addEventListener("click", () => {
                  searchInput.value = item.name
                  suggestionsContainer.style.display = "none"
                  // Trigger search
                  searchInput.form.submit()
                })
                suggestionsContainer.appendChild(div)
              })
              suggestionsContainer.style.display = "block"
            } else {
              suggestionsContainer.style.display = "none"
            }
          })
          .catch((error) => {
            console.error("Error fetching suggestions:", error)
            suggestionsContainer.style.display = "none"
          })
      }, 300)
    })

    // Hide suggestions when clicking outside
    document.addEventListener("click", (e) => {
      if (!searchInput.contains(e.target) && !suggestionsContainer.contains(e.target)) {
        suggestionsContainer.style.display = "none"
      }
    })
  }

  // Quantity input controls
  var quantityControls = document.querySelectorAll(".quantity-control")
  quantityControls.forEach((control) => {
    var minusBtn = control.querySelector(".quantity-minus")
    var plusBtn = control.querySelector(".quantity-plus")
    var input = control.querySelector(".quantity-input")

    if (minusBtn && plusBtn && input) {
      minusBtn.addEventListener("click", () => {
        var currentValue = Number.parseInt(input.value) || 1
        var minValue = Number.parseInt(input.getAttribute("min")) || 1
        if (currentValue > minValue) {
          input.value = currentValue - 1
          input.dispatchEvent(new Event("change"))
        }
      })

      plusBtn.addEventListener("click", () => {
        var currentValue = Number.parseInt(input.value) || 1
        var maxValue = Number.parseInt(input.getAttribute("max")) || 999
        if (currentValue < maxValue) {
          input.value = currentValue + 1
          input.dispatchEvent(new Event("change"))
        }
      })
    }
  })

  // Image preview for file uploads
  var imageInputs = document.querySelectorAll('input[type="file"][accept*="image"]')
  imageInputs.forEach((input) => {
    input.addEventListener("change", (e) => {
      var file = e.target.files[0]
      var previewContainer = document.getElementById(input.id + "-preview")

      if (file && previewContainer) {
        var reader = new FileReader()
        reader.onload = (e) => {
          previewContainer.innerHTML =
            '<img src="' + e.target.result + '" class="img-thumbnail" style="max-width: 200px; max-height: 200px;">'
        }
        reader.readAsDataURL(file)
      }
    })
  })

  // Smooth scrolling for anchor links
  var anchorLinks = document.querySelectorAll('a[href^="#"]')
  anchorLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      var targetId = this.getAttribute("href").substring(1)
      var targetElement = document.getElementById(targetId)

      if (targetElement) {
        e.preventDefault()
        targetElement.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    })
  })

  // Loading states for forms
  var forms = document.querySelectorAll("form")
  forms.forEach((form) => {
    form.addEventListener("submit", (e) => {
      var submitBtn = form.querySelector('button[type="submit"], input[type="submit"]')
      if (submitBtn && !submitBtn.disabled) {
        submitBtn.disabled = true
        var originalText = submitBtn.textContent || submitBtn.value

        if (submitBtn.tagName === "BUTTON") {
          submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Memproses...'
        } else {
          submitBtn.value = "Memproses..."
        }

        // Re-enable after 10 seconds as fallback
        setTimeout(() => {
          submitBtn.disabled = false
          if (submitBtn.tagName === "BUTTON") {
            submitBtn.textContent = originalText
          } else {
            submitBtn.value = originalText
          }
        }, 10000)
      }
    })
  })
})

// Utility functions
function formatCurrency(amount) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(amount)
}

function showToast(message, type = "info") {
  // Create toast element
  var toastContainer = document.getElementById("toast-container")
  if (!toastContainer) {
    toastContainer = document.createElement("div")
    toastContainer.id = "toast-container"
    toastContainer.className = "toast-container position-fixed top-0 end-0 p-3"
    toastContainer.style.zIndex = "9999"
    document.body.appendChild(toastContainer)
  }

  var toastElement = document.createElement("div")
  toastElement.className = "toast align-items-center text-white bg-" + type + " border-0"
  toastElement.setAttribute("role", "alert")
  toastElement.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `

  toastContainer.appendChild(toastElement)

  var toast = new bootstrap.Toast(toastElement)
  toast.show()

  // Remove element after it's hidden
  toastElement.addEventListener("hidden.bs.toast", () => {
    toastElement.remove()
  })
}

// AJAX helper function
function makeRequest(url, options = {}) {
  const defaultOptions = {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
    },
  }

  const finalOptions = { ...defaultOptions, ...options }

  return fetch(url, finalOptions)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok")
      }
      return response.json()
    })
    .catch((error) => {
      console.error("Request failed:", error)
      showToast("Terjadi kesalahan. Silakan coba lagi.", "danger")
      throw error
    })
}
