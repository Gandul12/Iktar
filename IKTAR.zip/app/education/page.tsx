"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Play, Clock, User, Search, Filter, Heart, Share2, Eye, ThumbsUp } from "lucide-react"

interface Article {
  id: string
  title: string
  excerpt: string
  content: string
  category: string
  author: string
  publishedAt: string
  readTime: number
  views: number
  likes: number
  image: string
  tags: string[]
}

interface Video {
  id: string
  title: string
  description: string
  category: string
  duration: string
  views: number
  likes: number
  thumbnail: string
  author: string
  publishedAt: string
}

export default function EducationPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")

  const articles: Article[] = [
    {
      id: "1",
      title: "Cara Memilih Ikan Segar untuk Konsumsi",
      excerpt:
        "Panduan lengkap memilih ikan segar dengan ciri-ciri yang mudah dikenali untuk memastikan kualitas terbaik.",
      content: "Ikan segar adalah kunci utama masakan yang lezat...",
      category: "Tips Membeli",
      author: "Dr. Sari Ikan",
      publishedAt: "2024-01-15",
      readTime: 5,
      views: 1250,
      likes: 89,
      image: "/placeholder.svg?height=200&width=400",
      tags: ["ikan segar", "tips membeli", "kualitas"],
    },
    {
      id: "2",
      title: "Budidaya Ikan Lele di Kolam Terpal",
      excerpt: "Teknik budidaya ikan lele modern menggunakan kolam terpal yang efisien dan menguntungkan.",
      content: "Budidaya ikan lele dengan kolam terpal semakin populer...",
      category: "Budidaya",
      author: "Pak Budi Tani",
      publishedAt: "2024-01-12",
      readTime: 8,
      views: 2100,
      likes: 156,
      image: "/placeholder.svg?height=200&width=400",
      tags: ["budidaya", "lele", "kolam terpal"],
    },
    {
      id: "3",
      title: "Perawatan Ikan Hias Arwana untuk Pemula",
      excerpt: "Tips merawat ikan arwana agar tetap sehat, aktif, dan memiliki warna yang indah.",
      content: "Ikan arwana membutuhkan perawatan khusus...",
      category: "Perawatan",
      author: "Aquarist Pro",
      publishedAt: "2024-01-10",
      readTime: 6,
      views: 890,
      likes: 67,
      image: "/placeholder.svg?height=200&width=400",
      tags: ["arwana", "ikan hias", "perawatan"],
    },
    {
      id: "4",
      title: "Mengenal Jenis-Jenis Ikan Predator Air Tawar",
      excerpt: "Panduan lengkap mengenal karakteristik dan cara merawat berbagai jenis ikan predator air tawar.",
      content: "Ikan predator air tawar memiliki daya tarik tersendiri...",
      category: "Pengetahuan",
      author: "Fish Expert",
      publishedAt: "2024-01-08",
      readTime: 10,
      views: 1680,
      likes: 124,
      image: "/placeholder.svg?height=200&width=400",
      tags: ["predator", "air tawar", "jenis ikan"],
    },
  ]

  const videos: Video[] = [
    {
      id: "1",
      title: "Cara Budidaya Ikan Nila di Kolam Beton",
      description: "Tutorial lengkap budidaya ikan nila dari persiapan kolam hingga panen.",
      category: "Budidaya",
      duration: "15:30",
      views: 45000,
      likes: 1200,
      thumbnail: "/placeholder.svg?height=200&width=350",
      author: "Channel Perikanan",
      publishedAt: "2024-01-14",
    },
    {
      id: "2",
      title: "Setting Aquarium Ikan Hias yang Benar",
      description: "Panduan step-by-step setting aquarium untuk ikan hias agar tetap sehat.",
      category: "Perawatan",
      duration: "12:45",
      views: 32000,
      likes: 890,
      thumbnail: "/placeholder.svg?height=200&width=350",
      author: "Aquarium Master",
      publishedAt: "2024-01-12",
    },
    {
      id: "3",
      title: "Teknik Pemberian Pakan Ikan yang Efektif",
      description: "Tips dan trik pemberian pakan ikan untuk pertumbuhan optimal.",
      category: "Tips",
      duration: "8:20",
      views: 28000,
      likes: 756,
      thumbnail: "/placeholder.svg?height=200&width=350",
      author: "Fish Care Pro",
      publishedAt: "2024-01-10",
    },
  ]

  const categories = ["all", "Tips Membeli", "Budidaya", "Perawatan", "Pengetahuan", "Tips"]

  const filteredArticles = articles.filter((article) => {
    const matchesSearch =
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.excerpt.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || article.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const filteredVideos = videos.filter((video) => {
    const matchesSearch =
      video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      video.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || video.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">🎓 Pusat Edukasi IkTar</h1>
          <p className="text-xl text-gray-600 mb-6">
            Pelajari segala hal tentang ikan air tawar - dari tips membeli hingga teknik budidaya profesional
          </p>

          {/* Search & Filter */}
          <div className="flex flex-col md:flex-row gap-4 max-w-2xl mx-auto">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Cari artikel atau video..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="pl-10 pr-4 py-2 border rounded-md bg-white min-w-[150px]"
              >
                <option value="all">Semua Kategori</option>
                {categories.slice(1).map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <Tabs defaultValue="articles" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 max-w-md mx-auto">
            <TabsTrigger value="articles">📚 Artikel</TabsTrigger>
            <TabsTrigger value="videos">🎥 Video</TabsTrigger>
            <TabsTrigger value="guides">📖 Panduan</TabsTrigger>
          </TabsList>

          {/* Articles Tab */}
          <TabsContent value="articles" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredArticles.map((article) => (
                <Card key={article.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <div className="aspect-video bg-gray-200 rounded-t-lg overflow-hidden">
                    <img
                      src={article.image || "/placeholder.svg"}
                      alt={article.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="secondary">{article.category}</Badge>
                      <div className="flex items-center text-sm text-gray-500">
                        <Clock className="w-3 h-3 mr-1" />
                        {article.readTime} min
                      </div>
                    </div>
                    <CardTitle className="text-lg line-clamp-2">{article.title}</CardTitle>
                    <CardDescription className="line-clamp-3">{article.excerpt}</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                      <div className="flex items-center">
                        <User className="w-3 h-3 mr-1" />
                        {article.author}
                      </div>
                      <span>{article.publishedAt}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <div className="flex items-center">
                          <Eye className="w-3 h-3 mr-1" />
                          {article.views.toLocaleString()}
                        </div>
                        <div className="flex items-center">
                          <ThumbsUp className="w-3 h-3 mr-1" />
                          {article.likes}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm">
                          <Heart className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1 mt-3">
                      {article.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Videos Tab */}
          <TabsContent value="videos" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredVideos.map((video) => (
                <Card key={video.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <div className="relative aspect-video bg-gray-200 rounded-t-lg overflow-hidden">
                    <img
                      src={video.thumbnail || "/placeholder.svg"}
                      alt={video.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                      <Play className="w-12 h-12 text-white" />
                    </div>
                    <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
                      {video.duration}
                    </div>
                  </div>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="secondary">{video.category}</Badge>
                    </div>
                    <CardTitle className="text-lg line-clamp-2">{video.title}</CardTitle>
                    <CardDescription className="line-clamp-2">{video.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                      <div className="flex items-center">
                        <User className="w-3 h-3 mr-1" />
                        {video.author}
                      </div>
                      <span>{video.publishedAt}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <div className="flex items-center">
                          <Eye className="w-3 h-3 mr-1" />
                          {video.views.toLocaleString()}
                        </div>
                        <div className="flex items-center">
                          <ThumbsUp className="w-3 h-3 mr-1" />
                          {video.likes}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm">
                          <Heart className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Guides Tab */}
          <TabsContent value="guides" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="w-5 h-5 mr-2 text-blue-600" />
                    Panduan Pemula
                  </CardTitle>
                  <CardDescription>Mulai perjalanan Anda di dunia perikanan</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="border-l-4 border-blue-500 pl-4">
                    <h4 className="font-medium">1. Mengenal Jenis Ikan Air Tawar</h4>
                    <p className="text-sm text-gray-600">Pelajari karakteristik berbagai jenis ikan</p>
                  </div>
                  <div className="border-l-4 border-blue-500 pl-4">
                    <h4 className="font-medium">2. Memilih Ikan yang Tepat</h4>
                    <p className="text-sm text-gray-600">Tips memilih ikan sesuai kebutuhan</p>
                  </div>
                  <div className="border-l-4 border-blue-500 pl-4">
                    <h4 className="font-medium">3. Perawatan Dasar</h4>
                    <p className="text-sm text-gray-600">Cara merawat ikan untuk pemula</p>
                  </div>
                  <Button className="w-full mt-4">Mulai Belajar</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="w-5 h-5 mr-2 text-green-600" />
                    Panduan Budidaya
                  </CardTitle>
                  <CardDescription>Teknik budidaya ikan yang menguntungkan</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="border-l-4 border-green-500 pl-4">
                    <h4 className="font-medium">1. Persiapan Kolam</h4>
                    <p className="text-sm text-gray-600">Desain dan konstruksi kolam ideal</p>
                  </div>
                  <div className="border-l-4 border-green-500 pl-4">
                    <h4 className="font-medium">2. Pemilihan Bibit</h4>
                    <p className="text-sm text-gray-600">Kriteria bibit ikan berkualitas</p>
                  </div>
                  <div className="border-l-4 border-green-500 pl-4">
                    <h4 className="font-medium">3. Manajemen Pakan</h4>
                    <p className="text-sm text-gray-600">Strategi pemberian pakan efisien</p>
                  </div>
                  <Button className="w-full mt-4">Mulai Budidaya</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="w-5 h-5 mr-2 text-purple-600" />
                    Panduan Ikan Hias
                  </CardTitle>
                  <CardDescription>Merawat ikan hias dengan benar</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="border-l-4 border-purple-500 pl-4">
                    <h4 className="font-medium">1. Setting Aquarium</h4>
                    <p className="text-sm text-gray-600">Desain aquarium yang indah dan sehat</p>
                  </div>
                  <div className="border-l-4 border-purple-500 pl-4">
                    <h4 className="font-medium">2. Kualitas Air</h4>
                    <p className="text-sm text-gray-600">Menjaga parameter air optimal</p>
                  </div>
                  <div className="border-l-4 border-purple-500 pl-4">
                    <h4 className="font-medium">3. Kombinasi Ikan</h4>
                    <p className="text-sm text-gray-600">Memilih ikan yang cocok dicampur</p>
                  </div>
                  <Button className="w-full mt-4">Pelajari Lebih Lanjut</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="w-5 h-5 mr-2 text-orange-600" />
                    Panduan Bisnis
                  </CardTitle>
                  <CardDescription>Memulai bisnis perikanan yang sukses</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="border-l-4 border-orange-500 pl-4">
                    <h4 className="font-medium">1. Analisis Pasar</h4>
                    <p className="text-sm text-gray-600">Riset permintaan dan kompetitor</p>
                  </div>
                  <div className="border-l-4 border-orange-500 pl-4">
                    <h4 className="font-medium">2. Modal dan Investasi</h4>
                    <p className="text-sm text-gray-600">Perhitungan modal dan ROI</p>
                  </div>
                  <div className="border-l-4 border-orange-500 pl-4">
                    <h4 className="font-medium">3. Strategi Pemasaran</h4>
                    <p className="text-sm text-gray-600">Cara menjual ikan secara efektif</p>
                  </div>
                  <Button className="w-full mt-4">Mulai Bisnis</Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Newsletter Subscription */}
        <Card className="mt-12 bg-gradient-to-r from-blue-50 to-green-50">
          <CardContent className="text-center py-8">
            <h3 className="text-2xl font-bold mb-2">📧 Newsletter Edukasi IkTar</h3>
            <p className="text-gray-600 mb-6">
              Dapatkan tips, panduan, dan update terbaru tentang dunia perikanan langsung di email Anda
            </p>
            <div className="flex flex-col md:flex-row gap-4 max-w-md mx-auto">
              <Input placeholder="Masukkan email Anda..." className="flex-1" />
              <Button>Berlangganan Gratis</Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">Gratis selamanya • Bisa unsubscribe kapan saja • Tanpa spam</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
