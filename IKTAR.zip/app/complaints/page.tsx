"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { MessageSquare, AlertTriangle, Clock, CheckCircle, XCircle, FileText, Camera, Phone } from "lucide-react"

interface Complaint {
  id: string
  orderId: string
  category: string
  title: string
  description: string
  status: "open" | "in_progress" | "resolved" | "closed"
  createdAt: string
  seller: string
  product: string
  images?: string[]
}

export default function ComplaintsPage() {
  const [complaints, setComplaints] = useState<Complaint[]>([
    {
      id: "1",
      orderId: "ORD-2024-001",
      category: "Kualitas Produk",
      title: "Ikan Arwana tidak sesuai ukuran",
      description: "Ikan yang diterima ukurannya lebih kecil dari yang dijanjikan di deskripsi produk.",
      status: "in_progress",
      createdAt: "2024-01-15",
      seller: "Toko Ikan Berkah",
      product: "Ikan Arwana Silver 15cm",
    },
    {
      id: "2",
      orderId: "ORD-2024-002",
      category: "Pengiriman",
      title: "Pengiriman terlambat 3 hari",
      description: "Pesanan seharusnya tiba tanggal 10 Januari, tapi baru tiba tanggal 13 Januari.",
      status: "resolved",
      createdAt: "2024-01-10",
      seller: "Ikan Segar Nusantara",
      product: "Ikan Lele Sangkuriang 1kg",
    },
  ])

  const [showNewComplaintForm, setShowNewComplaintForm] = useState(false)
  const [newComplaint, setNewComplaint] = useState({
    orderId: "",
    category: "",
    title: "",
    description: "",
    images: [] as File[],
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "open":
        return (
          <Badge className="bg-red-100 text-red-800">
            <AlertTriangle className="w-3 h-3 mr-1" />
            Baru
          </Badge>
        )
      case "in_progress":
        return (
          <Badge className="bg-yellow-100 text-yellow-800">
            <Clock className="w-3 h-3 mr-1" />
            Diproses
          </Badge>
        )
      case "resolved":
        return (
          <Badge className="bg-green-100 text-green-800">
            <CheckCircle className="w-3 h-3 mr-1" />
            Selesai
          </Badge>
        )
      case "closed":
        return (
          <Badge className="bg-gray-100 text-gray-800">
            <XCircle className="w-3 h-3 mr-1" />
            Ditutup
          </Badge>
        )
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const handleSubmitComplaint = () => {
    const complaint: Complaint = {
      id: Date.now().toString(),
      orderId: newComplaint.orderId,
      category: newComplaint.category,
      title: newComplaint.title,
      description: newComplaint.description,
      status: "open",
      createdAt: new Date().toISOString().split("T")[0],
      seller: "Unknown Seller",
      product: "Unknown Product",
    }

    setComplaints([complaint, ...complaints])
    setNewComplaint({ orderId: "", category: "", title: "", description: "", images: [] })
    setShowNewComplaintForm(false)
  }

  const complaintCategories = [
    "Kualitas Produk",
    "Pengiriman",
    "Ikan Mati/Sakit",
    "Tidak Sesuai Deskripsi",
    "Kemasan Rusak",
    "Pelayanan Seller",
    "Lainnya",
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Sistem Komplain & Resolusi</h1>
              <p className="text-gray-600">Laporkan masalah pesanan Anda dan dapatkan solusi cepat</p>
            </div>
            <Dialog open={showNewComplaintForm} onOpenChange={setShowNewComplaintForm}>
              <DialogTrigger asChild>
                <Button>
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Buat Komplain
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Buat Komplain Baru</DialogTitle>
                  <DialogDescription>Isi form di bawah untuk melaporkan masalah dengan pesanan Anda</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="orderId">ID Pesanan *</Label>
                    <Input
                      id="orderId"
                      placeholder="ORD-2024-XXX"
                      value={newComplaint.orderId}
                      onChange={(e) => setNewComplaint({ ...newComplaint, orderId: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="category">Kategori Masalah *</Label>
                    <select
                      className="w-full p-2 border rounded-md"
                      value={newComplaint.category}
                      onChange={(e) => setNewComplaint({ ...newComplaint, category: e.target.value })}
                    >
                      <option value="">Pilih kategori...</option>
                      {complaintCategories.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="title">Judul Komplain *</Label>
                    <Input
                      id="title"
                      placeholder="Ringkasan masalah..."
                      value={newComplaint.title}
                      onChange={(e) => setNewComplaint({ ...newComplaint, title: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Deskripsi Detail *</Label>
                    <Textarea
                      id="description"
                      placeholder="Jelaskan masalah secara detail..."
                      rows={4}
                      value={newComplaint.description}
                      onChange={(e) => setNewComplaint({ ...newComplaint, description: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="images">Upload Foto Bukti</Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                      <Camera className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                      <p className="text-sm text-gray-600">Klik untuk upload foto (maksimal 5 foto)</p>
                      <Input
                        id="images"
                        type="file"
                        accept="image/*"
                        multiple
                        className="hidden"
                        onChange={(e) => {
                          const files = Array.from(e.target.files || [])
                          setNewComplaint({ ...newComplaint, images: files })
                        }}
                      />
                      <Button
                        variant="outline"
                        onClick={() => document.getElementById("images")?.click()}
                        type="button"
                      >
                        Pilih Foto
                      </Button>
                    </div>
                    {newComplaint.images.length > 0 && (
                      <p className="text-sm text-green-600">{newComplaint.images.length} foto dipilih</p>
                    )}
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setShowNewComplaintForm(false)}>
                      Batal
                    </Button>
                    <Button
                      onClick={handleSubmitComplaint}
                      disabled={
                        !newComplaint.orderId ||
                        !newComplaint.category ||
                        !newComplaint.title ||
                        !newComplaint.description
                      }
                    >
                      Submit Komplain
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Tabs defaultValue="my-complaints" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="my-complaints">📋 Komplain Saya</TabsTrigger>
            <TabsTrigger value="guidelines">📖 Panduan</TabsTrigger>
            <TabsTrigger value="faq">❓ FAQ</TabsTrigger>
          </TabsList>

          <TabsContent value="my-complaints" className="space-y-4">
            {complaints.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <MessageSquare className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium mb-2">Belum Ada Komplain</h3>
                  <p className="text-gray-600 mb-4">Anda belum pernah membuat komplain</p>
                  <Button onClick={() => setShowNewComplaintForm(true)}>Buat Komplain Pertama</Button>
                </CardContent>
              </Card>
            ) : (
              complaints.map((complaint) => (
                <Card key={complaint.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-lg">{complaint.title}</CardTitle>
                        <CardDescription>
                          Order #{complaint.orderId} • {complaint.seller} • {complaint.createdAt}
                        </CardDescription>
                      </div>
                      {getStatusBadge(complaint.status)}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-gray-600 mb-1">
                          Kategori: <span className="font-medium">{complaint.category}</span>
                        </p>
                        <p className="text-sm text-gray-600">
                          Produk: <span className="font-medium">{complaint.product}</span>
                        </p>
                      </div>

                      <p className="text-gray-800">{complaint.description}</p>

                      <div className="flex items-center space-x-2">
                        <Button variant="outline" size="sm">
                          <MessageSquare className="w-4 h-4 mr-1" />
                          Chat dengan Admin
                        </Button>
                        <Button variant="outline" size="sm">
                          <FileText className="w-4 h-4 mr-1" />
                          Lihat Detail
                        </Button>
                        {complaint.status === "open" && (
                          <Button variant="outline" size="sm">
                            <Phone className="w-4 h-4 mr-1" />
                            Hubungi Seller
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="guidelines" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">🐟 Masalah Kualitas Ikan</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <h4 className="font-medium">Ikan Mati saat Tiba:</h4>
                    <p className="text-sm text-gray-600">
                      Foto ikan, kemasan, dan label pengiriman. Laporkan dalam 2 jam setelah terima.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium">Ikan Sakit/Stress:</h4>
                    <p className="text-sm text-gray-600">
                      Video kondisi ikan, foto kemasan. Berikan waktu aklimatisasi 24 jam.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium">Ukuran Tidak Sesuai:</h4>
                    <p className="text-sm text-gray-600">Foto ikan dengan penggaris/meteran sebagai pembanding.</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">📦 Masalah Pengiriman</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <h4 className="font-medium">Terlambat:</h4>
                    <p className="text-sm text-gray-600">
                      Screenshot resi pengiriman dan estimasi awal. Toleransi 1 hari kerja.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium">Kemasan Rusak:</h4>
                    <p className="text-sm text-gray-600">Foto kemasan dari berbagai sudut sebelum dibuka.</p>
                  </div>
                  <div>
                    <h4 className="font-medium">Barang Hilang:</h4>
                    <p className="text-sm text-gray-600">Laporan dari kurir dan foto kemasan yang diterima.</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">⚖️ Proses Resolusi</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <div className="w-6 h-6 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center text-xs font-bold">
                      1
                    </div>
                    <p className="text-sm">Submit komplain dengan bukti lengkap</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-6 h-6 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center text-xs font-bold">
                      2
                    </div>
                    <p className="text-sm">Admin review dalam 24 jam</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-6 h-6 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center text-xs font-bold">
                      3
                    </div>
                    <p className="text-sm">Mediasi dengan seller (2-3 hari)</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-6 h-6 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center text-xs font-bold">
                      4
                    </div>
                    <p className="text-sm">Solusi: refund, ganti rugi, atau tukar barang</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">💰 Kompensasi</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <h4 className="font-medium">Ikan Mati:</h4>
                    <p className="text-sm text-gray-600">Refund 100% atau ganti ikan baru + ongkir</p>
                  </div>
                  <div>
                    <h4 className="font-medium">Terlambat:</h4>
                    <p className="text-sm text-gray-600">Voucher 10-20% untuk pembelian berikutnya</p>
                  </div>
                  <div>
                    <h4 className="font-medium">Tidak Sesuai:</h4>
                    <p className="text-sm text-gray-600">Refund parsial atau tukar dengan yang sesuai</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="faq" className="space-y-4">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-6">
                  <div>
                    <h3 className="font-medium mb-2">Berapa lama proses resolusi komplain?</h3>
                    <p className="text-sm text-gray-600">
                      Maksimal 7 hari kerja dari komplain diterima. Untuk kasus ikan mati, prioritas 24 jam.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-medium mb-2">Apakah ada biaya untuk membuat komplain?</h3>
                    <p className="text-sm text-gray-600">
                      Tidak ada biaya. Layanan komplain dan resolusi sepenuhnya gratis.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-medium mb-2">Bagaimana jika seller tidak merespon?</h3>
                    <p className="text-sm text-gray-600">
                      Admin akan intervensi langsung dan memberikan solusi sesuai kebijakan platform.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-medium mb-2">Bisakah komplain dibatalkan?</h3>
                    <p className="text-sm text-gray-600">
                      Ya, selama status masih "Baru" atau "Diproses" dan belum ada kesepakatan.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-medium mb-2">Apakah ada sanksi untuk komplain palsu?</h3>
                    <p className="text-sm text-gray-600">
                      Ya, akun bisa dibekukan sementara atau permanen untuk komplain yang terbukti palsu.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Alert className="mt-6 border-blue-200 bg-blue-50">
          <Phone className="h-4 w-4" />
          <AlertDescription>
            <strong>Butuh bantuan cepat?</strong> Hubungi Customer Service kami di WhatsApp:{" "}
            <strong>0812-3456-7890</strong> (24/7)
          </AlertDescription>
        </Alert>
      </div>
    </div>
  )
}
