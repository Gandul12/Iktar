"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, FileText, CheckCircle, Clock, XCircle, Shield, Award, Camera } from "lucide-react"

export default function SellerVerificationPage() {
  const [verificationStatus, setVerificationStatus] = useState<"none" | "pending" | "verified" | "rejected">("none")
  const [uploadedDocs, setUploadedDocs] = useState<{ [key: string]: File | null }>({
    ktp: null,
    certificate: null,
    businessLicense: null,
    photo: null,
  })

  const handleFileUpload = (docType: string, file: File) => {
    setUploadedDocs((prev) => ({ ...prev, [docType]: file }))
  }

  const handleSubmitVerification = () => {
    // Simulate verification submission
    setVerificationStatus("pending")
    // In real app, this would upload files and submit to backend
  }

  const getStatusBadge = () => {
    switch (verificationStatus) {
      case "verified":
        return (
          <Badge className="bg-green-100 text-green-800">
            <CheckCircle className="w-4 h-4 mr-1" />
            Terverifikasi
          </Badge>
        )
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800">
            <Clock className="w-4 h-4 mr-1" />
            Menunggu Review
          </Badge>
        )
      case "rejected":
        return (
          <Badge className="bg-red-100 text-red-800">
            <XCircle className="w-4 h-4 mr-1" />
            Ditolak
          </Badge>
        )
      default:
        return <Badge variant="outline">Belum Diverifikasi</Badge>
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Verifikasi Seller</h1>
              <p className="text-gray-600">Tingkatkan kepercayaan pembeli dengan verifikasi akun Anda</p>
            </div>
            {getStatusBadge()}
          </div>
        </div>

        {verificationStatus === "none" && (
          <Alert className="mb-6 border-blue-200 bg-blue-50">
            <Shield className="h-4 w-4" />
            <AlertDescription>
              <strong>Mengapa perlu verifikasi?</strong> Seller terverifikasi mendapat badge khusus, prioritas pencarian
              lebih tinggi, dan kepercayaan pembeli yang lebih besar.
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="documents" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="documents">📄 Dokumen</TabsTrigger>
            <TabsTrigger value="business">🏪 Info Bisnis</TabsTrigger>
            <TabsTrigger value="benefits">⭐ Keuntungan</TabsTrigger>
          </TabsList>

          <TabsContent value="documents" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Upload Dokumen Verifikasi</CardTitle>
                <CardDescription>Upload dokumen yang diperlukan untuk verifikasi akun seller Anda</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* KTP Upload */}
                <div className="space-y-2">
                  <Label htmlFor="ktp">KTP / Identitas Diri *</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                    <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <div className="space-y-2">
                      <p className="text-sm text-gray-600">
                        {uploadedDocs.ktp ? uploadedDocs.ktp.name : "Klik untuk upload KTP"}
                      </p>
                      <Input
                        id="ktp"
                        type="file"
                        accept="image/*,.pdf"
                        className="hidden"
                        onChange={(e) => e.target.files?.[0] && handleFileUpload("ktp", e.target.files[0])}
                      />
                      <Button variant="outline" onClick={() => document.getElementById("ktp")?.click()}>
                        Pilih File
                      </Button>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500">Format: JPG, PNG, PDF. Maksimal 5MB</p>
                </div>

                {/* Certificate Upload */}
                <div className="space-y-2">
                  <Label htmlFor="certificate">Sertifikat Perikanan / Budidaya</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                    <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <div className="space-y-2">
                      <p className="text-sm text-gray-600">
                        {uploadedDocs.certificate ? uploadedDocs.certificate.name : "Upload sertifikat (opsional)"}
                      </p>
                      <Input
                        id="certificate"
                        type="file"
                        accept="image/*,.pdf"
                        className="hidden"
                        onChange={(e) => e.target.files?.[0] && handleFileUpload("certificate", e.target.files[0])}
                      />
                      <Button variant="outline" onClick={() => document.getElementById("certificate")?.click()}>
                        Pilih File
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Business License */}
                <div className="space-y-2">
                  <Label htmlFor="business">Izin Usaha / SIUP (Opsional)</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                    <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <div className="space-y-2">
                      <p className="text-sm text-gray-600">
                        {uploadedDocs.businessLicense ? uploadedDocs.businessLicense.name : "Upload izin usaha"}
                      </p>
                      <Input
                        id="business"
                        type="file"
                        accept="image/*,.pdf"
                        className="hidden"
                        onChange={(e) => e.target.files?.[0] && handleFileUpload("businessLicense", e.target.files[0])}
                      />
                      <Button variant="outline" onClick={() => document.getElementById("business")?.click()}>
                        Pilih File
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Photo with KTP */}
                <div className="space-y-2">
                  <Label htmlFor="photo">Foto Selfie dengan KTP *</Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                    <Camera className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <div className="space-y-2">
                      <p className="text-sm text-gray-600">
                        {uploadedDocs.photo ? uploadedDocs.photo.name : "Upload foto selfie dengan KTP"}
                      </p>
                      <Input
                        id="photo"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => e.target.files?.[0] && handleFileUpload("photo", e.target.files[0])}
                      />
                      <Button variant="outline" onClick={() => document.getElementById("photo")?.click()}>
                        Pilih File
                      </Button>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500">Pastikan wajah dan KTP terlihat jelas</p>
                </div>

                <Button
                  onClick={handleSubmitVerification}
                  className="w-full"
                  disabled={!uploadedDocs.ktp || !uploadedDocs.photo || verificationStatus === "pending"}
                >
                  {verificationStatus === "pending" ? "Sedang Diproses..." : "Submit Verifikasi"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="business" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Informasi Bisnis</CardTitle>
                <CardDescription>Lengkapi informasi bisnis Anda untuk meningkatkan kredibilitas</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="businessName">Nama Usaha</Label>
                    <Input id="businessName" placeholder="CV. Ikan Segar Nusantara" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="businessType">Jenis Usaha</Label>
                    <select className="w-full p-2 border rounded-md">
                      <option>Budidaya Ikan</option>
                      <option>Distributor</option>
                      <option>Toko Ikan</option>
                      <option>Supplier</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="businessAddress">Alamat Usaha</Label>
                  <Textarea id="businessAddress" placeholder="Jl. Raya Perikanan No. 123, Kota Bandung" rows={3} />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="experience">Pengalaman (Tahun)</Label>
                    <Input id="experience" type="number" placeholder="5" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="capacity">Kapasitas Produksi/Bulan</Label>
                    <Input id="capacity" placeholder="1000 kg" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Deskripsi Usaha</Label>
                  <Textarea
                    id="description"
                    placeholder="Ceritakan tentang usaha Anda, spesialisasi, dan keunggulan..."
                    rows={4}
                  />
                </div>

                <Button className="w-full">Simpan Informasi Bisnis</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="benefits" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Award className="w-5 h-5 mr-2 text-blue-600" />
                    Badge Terverifikasi
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Dapatkan badge "Seller Terverifikasi" yang meningkatkan kepercayaan pembeli hingga 300%
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <CheckCircle className="w-5 h-5 mr-2 text-green-600" />
                    Prioritas Pencarian
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Produk Anda akan muncul lebih tinggi di hasil pencarian dan mendapat label "Terpercaya"
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="w-5 h-5 mr-2 text-purple-600" />
                    Proteksi Seller
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Mendapat perlindungan khusus dari komplain tidak berdasar dan dispute resolution prioritas
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="w-5 h-5 mr-2 text-orange-600" />
                    Fitur Premium
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Akses ke analytics mendalam, bulk upload produk, dan customer support prioritas
                  </p>
                </CardContent>
              </Card>
            </div>

            <Alert className="border-green-200 bg-green-50">
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Gratis!</strong> Verifikasi seller sepenuhnya gratis dan hanya membutuhkan waktu 1-3 hari kerja
                untuk review.
              </AlertDescription>
            </Alert>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
