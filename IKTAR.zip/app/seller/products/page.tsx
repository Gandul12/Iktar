"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/layout/navbar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Search, Filter, Edit, Eye, Trash2, BarChart3, Package, AlertTriangle } from "lucide-react"
import { useAuth } from "@/lib/auth"

export default function SellerProductsPage() {
  const router = useRouter()
  const { user, isAuthenticated } = useAuth()
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    const checkAuth = () => {
      const userData = localStorage.getItem("iktar_user")
      if (!userData) {
        router.push("/auth/login")
        return
      }

      try {
        const user = JSON.parse(userData)
        if (user.role !== "seller") {
          router.push("/")
          return
        }
      } catch (error) {
        router.push("/auth/login")
        return
      }

      setLoading(false)
    }

    setTimeout(checkAuth, 100)
  }, [router])

  // Mock products data for seller
  const products = [
    {
      id: 1,
      name: "Ikan Guppy Premium",
      price: 15000,
      stock: 50,
      sold: 25,
      status: "active",
      image: "/placeholder.svg?height=80&width=80",
      category: "ikan-hias",
      views: 150,
      rating: 4.5,
    },
    {
      id: 2,
      name: "Ikan Lele Segar",
      price: 25000,
      stock: 30,
      sold: 15,
      status: "active",
      image: "/placeholder.svg?height=80&width=80",
      category: "ikan-konsumsi",
      views: 89,
      rating: 4.2,
    },
    {
      id: 3,
      name: "Ikan Cupang Halfmoon",
      price: 35000,
      stock: 0,
      sold: 10,
      status: "out_of_stock",
      image: "/placeholder.svg?height=80&width=80",
      category: "ikan-hias",
      views: 200,
      rating: 4.8,
    },
    {
      id: 4,
      name: "Bibit Ikan Nila",
      price: 2000,
      stock: 500,
      sold: 100,
      status: "active",
      image: "/placeholder.svg?height=80&width=80",
      category: "bibit",
      views: 75,
      rating: 4.0,
    },
  ]

  const getStatusBadge = (status: string, stock: number) => {
    if (stock === 0) {
      return <Badge variant="destructive">Stok Habis</Badge>
    }
    if (stock <= 5) {
      return (
        <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
          Stok Terbatas
        </Badge>
      )
    }
    return (
      <Badge variant="secondary" className="bg-green-100 text-green-800">
        Tersedia
      </Badge>
    )
  }

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.category.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleAddProduct = () => {
    router.push("/seller/products/add")
  }

  const handleEditProduct = (productId: number) => {
    router.push(`/seller/products/edit/${productId}`)
  }

  const handleViewProduct = (productId: number) => {
    router.push(`/products/${productId}`)
  }

  const handleDeleteProduct = (productId: number) => {
    if (confirm("Apakah Anda yakin ingin menghapus produk ini?")) {
      // Handle delete logic here
      alert(`Produk ${productId} berhasil dihapus`)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-64 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Produk Saya</h1>
            <p className="text-gray-600">Kelola semua produk yang Anda jual</p>
          </div>
          <Button onClick={handleAddProduct} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Tambah Produk
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Produk</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{products.length}</div>
              <p className="text-xs text-muted-foreground">Produk aktif</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Terjual</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{products.reduce((sum, p) => sum + p.sold, 0)}</div>
              <p className="text-xs text-muted-foreground">Bulan ini</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Stok Habis</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{products.filter((p) => p.stock === 0).length}</div>
              <p className="text-xs text-muted-foreground">Perlu restock</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Views</CardTitle>
              <Eye className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{products.reduce((sum, p) => sum + p.views, 0)}</div>
              <p className="text-xs text-muted-foreground">Minggu ini</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filter */}
        <div className="flex gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Cari produk..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </div>

        {/* Products Tabs */}
        <Tabs defaultValue="all" className="space-y-6">
          <TabsList>
            <TabsTrigger value="all">Semua ({products.length})</TabsTrigger>
            <TabsTrigger value="active">
              Aktif ({products.filter((p) => p.status === "active" && p.stock > 0).length})
            </TabsTrigger>
            <TabsTrigger value="out_of_stock">Stok Habis ({products.filter((p) => p.stock === 0).length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <Card key={product.id} className="hover:shadow-lg transition-shadow">
                  <div className="relative">
                    <img
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                    {getStatusBadge(product.status, product.stock)}
                  </div>

                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg mb-2 line-clamp-2">{product.name}</h3>

                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Harga:</span>
                        <span className="font-medium">Rp {product.price.toLocaleString("id-ID")}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Stok:</span>
                        <span className="font-medium">{product.stock}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Terjual:</span>
                        <span className="font-medium">{product.sold}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Views:</span>
                        <span className="font-medium">{product.views}</span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={() => handleViewProduct(product.id)}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        Lihat
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={() => handleEditProduct(product.id)}
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteProduct(product.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="active" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts
                .filter((p) => p.status === "active" && p.stock > 0)
                .map((product) => (
                  <Card key={product.id}>
                    <CardContent className="p-6">
                      <p className="text-center text-gray-600">Produk aktif dan tersedia untuk dijual</p>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </TabsContent>

          <TabsContent value="out_of_stock" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts
                .filter((p) => p.stock === 0)
                .map((product) => (
                  <Card key={product.id}>
                    <CardContent className="p-6">
                      <p className="text-center text-gray-600">Produk kehabisan stok, perlu restock</p>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </TabsContent>
        </Tabs>

        {filteredProducts.length === 0 && (
          <Card>
            <CardContent className="text-center py-16">
              <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-900 mb-2">Belum Ada Produk</h3>
              <p className="text-gray-600 mb-6">Mulai jual dengan menambahkan produk pertama Anda</p>
              <Button onClick={handleAddProduct}>
                <Plus className="mr-2 h-4 w-4" />
                Tambah Produk Pertama
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
