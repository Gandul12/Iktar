from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, FloatField, IntegerField, SelectField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, Length, NumberRange, EqualTo, ValidationError
from app.models import User

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class RegisterForm(FlaskForm):
    name = StringField('Nama Lengkap', validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    password2 = PasswordField('Konfirmasi Password', validators=[DataRequired(), EqualTo('password')])
    role = SelectField('Daftar Sebagai', choices=[('buyer', 'Pembeli'), ('seller', 'Penjual')], validators=[DataRequired()])
    submit = SubmitField('Daftar')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data.lower().strip()).first()
        if user:
            raise ValidationError('Email sudah terdaftar.')

class ProductForm(FlaskForm):
    name = StringField('Nama Produk', validators=[DataRequired(), Length(min=2, max=100)])
    description = TextAreaField('Deskripsi', validators=[DataRequired(), Length(min=10)])
    price = FloatField('Harga (Rp)', validators=[DataRequired(), NumberRange(min=0)])
    stock = IntegerField('Stok', validators=[DataRequired(), NumberRange(min=0)])
    category = SelectField('Kategori', choices=[
        ('hias', 'Ikan Hias'),
        ('konsumsi', 'Ikan Konsumsi'),
        ('predator', 'Ikan Predator'),
        ('bibit', 'Bibit Ikan')
    ], validators=[DataRequired()])
    submit = SubmitField('Simpan')
