from functools import wraps
from flask import redirect, url_for, flash, abort
from flask_login import current_user

def anonymous_required(f):
    """Decorator to require anonymous (not logged in) user"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if current_user.is_authenticated:
            # Redirect authenticated users based on their role
            try:
                if hasattr(current_user, 'role'):
                    if current_user.role.name == 'ADMIN':
                        return redirect(url_for('main.index'))
                    elif current_user.role.name == 'SELLER':
                        return redirect(url_for('seller.dashboard'))
                    elif current_user.role.name == 'BUYER':
                        return redirect(url_for('buyer.dashboard'))
                return redirect(url_for('main.index'))
            except:
                return redirect(url_for('main.index'))
        
        return f(*args, **kwargs)
    return decorated_function

def role_required(role):
    """Decorator to require specific user role"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash('Silakan login terlebih dahulu.', 'warning')
                return redirect(url_for('auth.login'))
            
            try:
                if isinstance(role, list):
                    if current_user.role not in role:
                        abort(403)
                else:
                    if current_user.role != role:
                        abort(403)
            except:
                abort(403)
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def seller_required(f):
    """Decorator to require seller role"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Silakan login terlebih dahulu.', 'warning')
            return redirect(url_for('auth.login'))
        
        try:
            if not (hasattr(current_user, 'role') and current_user.role.name == 'SELLER'):
                flash('Akses ditolak. Halaman ini hanya untuk penjual.', 'error')
                abort(403)
        except:
            abort(403)
        
        return f(*args, **kwargs)
    return decorated_function

def buyer_required(f):
    """Decorator to require buyer role"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Silakan login terlebih dahulu.', 'warning')
            return redirect(url_for('auth.login'))
        
        try:
            if not (hasattr(current_user, 'role') and current_user.role.name == 'BUYER'):
                flash('Akses ditolak. Halaman ini hanya untuk pembeli.', 'error')
                abort(403)
        except:
            abort(403)
        
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    """Decorator to require admin role"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Silakan login terlebih dahulu.', 'warning')
            return redirect(url_for('auth.login'))
        
        try:
            if not (hasattr(current_user, 'role') and current_user.role.name == 'ADMIN'):
                flash('Akses ditolak. Halaman ini hanya untuk admin.', 'error')
                abort(403)
        except:
            abort(403)
        
        return f(*args, **kwargs)
    return decorated_function
