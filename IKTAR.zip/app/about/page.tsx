import { Navbar } from "@/components/layout/navbar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Fish, Users, Shield, Truck, Star, Heart } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="flex items-center justify-center w-16 h-16 bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl">
              <Fish className="h-10 w-10 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold mb-4">Tentang IkTar</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Platform jual beli ikan terpercaya yang menghubungkan penjual dan pembeli ikan berkualitas di seluruh
            Indonesia
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="h-6 w-6 text-red-500" />
                Misi Kami
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Menyediakan platform yang mudah, aman, dan terpercaya untuk jual beli ikan berkualitas, mendukung
                peternak ikan lokal, dan memastikan konsumen mendapatkan ikan segar dengan harga terbaik.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-6 w-6 text-yellow-500" />
                Visi Kami
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Menjadi platform jual beli ikan terdepan di Indonesia yang mendukung ekonomi perikanan nasional dan
                memberikan akses mudah ke ikan berkualitas untuk semua kalangan.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Features */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-12">Mengapa Memilih IkTar?</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center">
              <CardHeader>
                <div className="flex justify-center mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Fish className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
                <CardTitle className="text-lg">Ikan Berkualitas</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Semua ikan telah melalui proses seleksi ketat untuk memastikan kualitas terbaik
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="flex justify-center mb-4">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Shield className="h-6 w-6 text-green-600" />
                  </div>
                </div>
                <CardTitle className="text-lg">Transaksi Aman</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Sistem pembayaran yang aman dan terpercaya dengan perlindungan untuk pembeli dan penjual
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="flex justify-center mb-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Truck className="h-6 w-6 text-purple-600" />
                  </div>
                </div>
                <CardTitle className="text-lg">Pengiriman Cepat</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Jaringan pengiriman yang luas dengan kemasan khusus untuk menjaga kesegaran ikan
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="flex justify-center mb-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <Users className="h-6 w-6 text-orange-600" />
                  </div>
                </div>
                <CardTitle className="text-lg">Komunitas Terpercaya</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Bergabung dengan ribuan penjual dan pembeli ikan terpercaya di seluruh Indonesia
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Stats */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">IkTar dalam Angka</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold mb-2">1000+</div>
              <div className="text-blue-100">Penjual Terdaftar</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">5000+</div>
              <div className="text-blue-100">Pembeli Aktif</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">10000+</div>
              <div className="text-blue-100">Transaksi Berhasil</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">50+</div>
              <div className="text-blue-100">Kota Terjangkau</div>
            </div>
          </div>
        </div>

        {/* Contact */}
        <div className="text-center">
          <h2 className="text-3xl font-bold mb-4">Hubungi Kami</h2>
          <p className="text-gray-600 mb-8">Punya pertanyaan atau butuh bantuan? Tim kami siap membantu Anda 24/7</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Card className="p-4">
              <div className="font-semibold">Email</div>
              <div className="text-blue-600">support@iktar.com</div>
            </Card>
            <Card className="p-4">
              <div className="font-semibold">WhatsApp</div>
              <div className="text-green-600">+62 812-3456-7890</div>
            </Card>
            <Card className="p-4">
              <div className="font-semibold">Jam Operasional</div>
              <div className="text-gray-600">24/7</div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
