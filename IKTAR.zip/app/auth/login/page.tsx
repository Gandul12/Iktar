"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Fish, LogIn, Eye, EyeOff, ArrowLeft, Loader2 } from "lucide-react"
import { authService } from "@/lib/auth"
import { useToast } from "@/hooks/use-toast"

export default function LoginPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  })
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    const result = await authService.login(formData.email, formData.password)

    if (result.success && result.user) {
      toast({
        title: "Login berhasil!",
        description: `Selamat datang kembali, ${result.user.name}`,
      })

      // Redirect based on role
      setTimeout(() => {
        switch (result.user!.role) {
          case "admin":
            router.push("/dashboard/admin")
            break
          case "seller":
            router.push("/dashboard/seller")
            break
          case "buyer":
            router.push("/dashboard/buyer")
            break
          default:
            router.push("/")
        }
      }, 1000)
    } else {
      setError(result.error || "Login gagal!")
    }

    setLoading(false)
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (error) setError("")
  }

  const fillDemoAccount = (email: string, password: string) => {
    setFormData({ email, password })
    setError("")
  }

  return (
    <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => router.back()}
            className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Kembali
          </Button>
        </div>

        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center space-x-2 mb-6 group">
            <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl group-hover:scale-105 transition-transform">
              <Fish className="h-7 w-7 text-white" />
            </div>
            <span className="text-3xl font-bold font-display text-gradient">IkTar</span>
          </Link>
          <h1 className="text-3xl font-bold font-display mb-2">Selamat Datang Kembali</h1>
          <p className="text-gray-600">Masuk ke akun IkTar Anda</p>
        </div>

        {/* Login Form */}
        <Card className="shadow-2xl border-0 glass-effect">
          <CardHeader className="text-center pb-2">
            <CardTitle className="flex items-center justify-center gap-2 text-2xl">
              <LogIn className="h-6 w-6 text-blue-600" />
              Masuk ke Akun
            </CardTitle>
            <CardDescription>Masukkan email dan password Anda untuk melanjutkan</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Demo Accounts */}
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm font-medium text-blue-800 mb-3">🧪 Demo Accounts (Klik untuk mengisi):</p>
              <div className="space-y-2">
                {[
                  { role: "👑 Admin", email: "admin@iktar.com", password: "admin123" },
                  { role: "🏪 Seller", email: "seller@iktar.com", password: "seller123" },
                  { role: "🛒 Buyer", email: "buyer@iktar.com", password: "buyer123" },
                ].map((account) => (
                  <button
                    key={account.email}
                    type="button"
                    onClick={() => fillDemoAccount(account.email, account.password)}
                    className="w-full text-left p-2 text-xs text-blue-700 hover:bg-blue-100 rounded transition-colors"
                  >
                    <strong>{account.role}:</strong> {account.email} / {account.password}
                  </button>
                ))}
              </div>
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="form-field space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="nama@email.com"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  className="h-12"
                  required
                />
              </div>

              <div className="form-field space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Masukkan password"
                    value={formData.password}
                    onChange={(e) => handleInputChange("password", e.target.value)}
                    className="h-12 pr-12"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-12 px-3 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <Link
                  href="/auth/forgot-password"
                  className="text-sm text-blue-600 hover:text-blue-800 hover:underline transition-colors"
                >
                  Lupa password?
                </Link>
              </div>

              <Button type="submit" className="w-full h-12 btn-primary" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Memproses...
                  </>
                ) : (
                  <>
                    <LogIn className="mr-2 h-4 w-4" />
                    Masuk
                  </>
                )}
              </Button>
            </form>

            <div className="text-center pt-4 border-t">
              <p className="text-sm text-gray-600">
                Belum punya akun?{" "}
                <Link
                  href="/auth/register"
                  className="text-blue-600 hover:text-blue-800 font-medium hover:underline transition-colors"
                >
                  Daftar di sini
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
