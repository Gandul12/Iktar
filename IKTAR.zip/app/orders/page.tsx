"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/layout/navbar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Package, Clock, CheckCircle, XCircle, Search, Filter, Eye, MessageSquare, Star } from "lucide-react"
import { useAuth } from "@/lib/auth"

export default function OrdersPage() {
  const router = useRouter()
  const { user, isAuthenticated } = useAuth()
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    const checkAuth = () => {
      const userData = localStorage.getItem("iktar_user")
      if (!userData) {
        router.push("/auth/login")
        return
      }

      try {
        const user = JSON.parse(userData)
        if (user.role !== "buyer") {
          router.push("/")
          return
        }
      } catch (error) {
        router.push("/auth/login")
        return
      }

      setLoading(false)
    }

    setTimeout(checkAuth, 100)
  }, [router])

  // Mock orders data
  const orders = [
    {
      id: "ORD-001",
      date: "2024-06-20",
      status: "delivered",
      total: 150000,
      items: [
        {
          name: "Ikan Guppy Premium",
          quantity: 5,
          price: 15000,
          image: "/placeholder.svg?height=60&width=60",
        },
        {
          name: "Ikan Cupang Halfmoon",
          quantity: 2,
          price: 35000,
          image: "/placeholder.svg?height=60&width=60",
        },
      ],
      seller: "Toko Ikan Segar",
      tracking: "JNE123456789",
    },
    {
      id: "ORD-002",
      date: "2024-06-22",
      status: "processing",
      total: 75000,
      items: [
        {
          name: "Ikan Lele Segar",
          quantity: 3,
          price: 25000,
          image: "/placeholder.svg?height=60&width=60",
        },
      ],
      seller: "CV Perikanan Nusantara",
      tracking: null,
    },
    {
      id: "ORD-003",
      date: "2024-06-24",
      status: "pending",
      total: 200000,
      items: [
        {
          name: "Bibit Ikan Nila",
          quantity: 100,
          price: 2000,
          image: "/placeholder.svg?height=60&width=60",
        },
      ],
      seller: "Budidaya Ikan Mandiri",
      tracking: null,
    },
  ]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
            <Clock className="w-3 h-3 mr-1" />
            Menunggu Konfirmasi
          </Badge>
        )
      case "processing":
        return (
          <Badge variant="default">
            <Package className="w-3 h-3 mr-1" />
            Sedang Diproses
          </Badge>
        )
      case "shipped":
        return (
          <Badge variant="secondary" className="bg-blue-100 text-blue-800">
            <Package className="w-3 h-3 mr-1" />
            Dalam Pengiriman
          </Badge>
        )
      case "delivered":
        return (
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            <CheckCircle className="w-3 h-3 mr-1" />
            Selesai
          </Badge>
        )
      case "cancelled":
        return (
          <Badge variant="destructive">
            <XCircle className="w-3 h-3 mr-1" />
            Dibatalkan
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const filteredOrders = orders.filter(
    (order) =>
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.seller.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.items.some((item) => item.name.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-32 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Pesanan Saya</h1>
          <p className="text-gray-600">Kelola dan lacak semua pesanan Anda</p>
        </div>

        {/* Search and Filter */}
        <div className="flex gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Cari pesanan, produk, atau penjual..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </div>

        {/* Orders Tabs */}
        <Tabs defaultValue="all" className="space-y-6">
          <TabsList>
            <TabsTrigger value="all">Semua ({orders.length})</TabsTrigger>
            <TabsTrigger value="pending">Menunggu ({orders.filter((o) => o.status === "pending").length})</TabsTrigger>
            <TabsTrigger value="processing">
              Diproses ({orders.filter((o) => o.status === "processing").length})
            </TabsTrigger>
            <TabsTrigger value="delivered">
              Selesai ({orders.filter((o) => o.status === "delivered").length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            {filteredOrders.map((order) => (
              <Card key={order.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{order.id}</CardTitle>
                      <CardDescription>
                        {new Date(order.date).toLocaleDateString("id-ID", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}{" "}
                        • {order.seller}
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      {getStatusBadge(order.status)}
                      <p className="text-lg font-bold text-blue-600 mt-1">Rp {order.total.toLocaleString("id-ID")}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Order Items */}
                    <div className="space-y-3">
                      {order.items.map((item, index) => (
                        <div key={index} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                          <img
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            className="w-16 h-16 object-cover rounded"
                          />
                          <div className="flex-1">
                            <h4 className="font-medium">{item.name}</h4>
                            <p className="text-sm text-gray-600">
                              {item.quantity} x Rp {item.price.toLocaleString("id-ID")}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">Rp {(item.quantity * item.price).toLocaleString("id-ID")}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Tracking Info */}
                    {order.tracking && (
                      <div className="p-3 bg-blue-50 rounded-lg">
                        <p className="text-sm text-blue-800">
                          <Package className="inline w-4 h-4 mr-1" />
                          Nomor Resi: <span className="font-medium">{order.tracking}</span>
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex gap-2 pt-2">
                      <Button variant="outline" size="sm">
                        <Eye className="mr-2 h-4 w-4" />
                        Detail
                      </Button>

                      {order.status === "delivered" && (
                        <>
                          <Button variant="outline" size="sm">
                            <Star className="mr-2 h-4 w-4" />
                            Beri Rating
                          </Button>
                          <Button variant="outline" size="sm">
                            Beli Lagi
                          </Button>
                        </>
                      )}

                      {order.status === "processing" && (
                        <Button variant="outline" size="sm">
                          <MessageSquare className="mr-2 h-4 w-4" />
                          Hubungi Penjual
                        </Button>
                      )}

                      {order.status === "pending" && (
                        <Button variant="destructive" size="sm">
                          Batalkan
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          {/* Other tab contents would filter the orders accordingly */}
          <TabsContent value="pending" className="space-y-4">
            {filteredOrders
              .filter((order) => order.status === "pending")
              .map((order) => (
                <Card key={order.id}>
                  {/* Same card structure as above */}
                  <CardContent className="p-6">
                    <p className="text-center text-gray-600">Pesanan menunggu konfirmasi dari penjual</p>
                  </CardContent>
                </Card>
              ))}
          </TabsContent>

          <TabsContent value="processing" className="space-y-4">
            {filteredOrders
              .filter((order) => order.status === "processing")
              .map((order) => (
                <Card key={order.id}>
                  <CardContent className="p-6">
                    <p className="text-center text-gray-600">Pesanan sedang diproses oleh penjual</p>
                  </CardContent>
                </Card>
              ))}
          </TabsContent>

          <TabsContent value="delivered" className="space-y-4">
            {filteredOrders
              .filter((order) => order.status === "delivered")
              .map((order) => (
                <Card key={order.id}>
                  <CardContent className="p-6">
                    <p className="text-center text-gray-600">Pesanan telah selesai dan diterima</p>
                  </CardContent>
                </Card>
              ))}
          </TabsContent>
        </Tabs>

        {filteredOrders.length === 0 && (
          <Card>
            <CardContent className="text-center py-16">
              <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-900 mb-2">Belum Ada Pesanan</h3>
              <p className="text-gray-600 mb-6">Mulai berbelanja untuk melihat pesanan Anda di sini</p>
              <Button onClick={() => router.push("/products")}>Mulai Belanja</Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
