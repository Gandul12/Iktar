from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, current_user
from app import db
from app.models import User, UserRole
from app.forms import LoginForm, RegisterForm
from app.decorators import anonymous_required

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
@anonymous_required
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data.lower().strip()).first()
        
        if user and user.check_password(form.password.data):
            login_user(user)
            flash(f'Selamat datang, {user.name}!', 'success')
            
            next_page = request.args.get('next')
            if next_page:
                return redirect(next_page)
            elif user.is_seller():
                return redirect(url_for('seller.dashboard'))
            elif user.is_buyer():
                return redirect(url_for('buyer.dashboard'))
            else:
                return redirect(url_for('main.home'))
        else:
            flash('Email atau password salah.', 'danger')
    
    return render_template('auth/login.html', form=form)

@auth_bp.route('/register', methods=['GET', 'POST'])
@anonymous_required
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        try:
            role = UserRole.SELLER if form.role.data == 'seller' else UserRole.BUYER
            
            user = User(
                name=form.name.data.strip(),
                email=form.email.data.lower().strip(),
                role=role
            )
            user.set_password(form.password.data)
            
            db.session.add(user)
            db.session.commit()
            
            flash('Registrasi berhasil! Silakan login.', 'success')
            return redirect(url_for('auth.login'))
            
        except Exception as e:
            db.session.rollback()
            flash('Terjadi kesalahan saat registrasi.', 'danger')
    
    return render_template('auth/register.html', form=form)

@auth_bp.route('/logout')
def logout():
    logout_user()
    flash('Anda telah logout.', 'info')
    return redirect(url_for('main.home'))
