from flask import Blueprint, render_template, request
from app.models import Product

product_bp = Blueprint('product', __name__)

@product_bp.route('/<int:id>')
def detail(id):
    product = Product.query.get_or_404(id)
    return render_template('product/detail.html', product=product)

@product_bp.route('/search')
def search():
    query = request.args.get('q', '')
    page = request.args.get('page', 1, type=int)
    
    if query:
        products = Product.query.filter(
            Product.name.contains(query),
            Product.is_active == True
        ).paginate(page=page, per_page=12, error_out=False)
    else:
        products = Product.query.filter_by(is_active=True).paginate(
            page=page, per_page=12, error_out=False
        )
    
    return render_template('main/products.html', products=products, search_query=query)
