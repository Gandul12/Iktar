from flask import Blueprint, jsonify, request, session
from flask_login import login_required, current_user
from app.models.models import Product, User, Transaction, db
from app.utils.decorators import buyer_required
import logging

logger = logging.getLogger(__name__)
api_bp = Blueprint('api', __name__)

@api_bp.route('/search-suggestions')
def search_suggestions():
    """API endpoint for search autocomplete"""
    query = request.args.get('q', '').strip()
    
    if len(query) < 2:
        return jsonify([])
    
    try:
        # Search in product names
        products = Product.query.filter(
            Product.name.contains(query),
            Product.is_active == True
        ).limit(8).all()
        
        suggestions = [product.name for product in products]
        return jsonify(suggestions)
    
    except Exception as e:
        logger.error(f"Search suggestions error: {e}")
        return jsonify([])

@api_bp.route('/cart/add', methods=['POST'])
@login_required
@buyer_required
def add_to_cart():
    """Add product to cart"""
    try:
        data = request.get_json()
        product_id = data.get('product_id')
        quantity = data.get('quantity', 1)
        
        # Validate input
        try:
            quantity = int(quantity)
            if quantity <= 0:
                return jsonify({'success': False, 'message': 'Jumlah harus lebih dari 0'})
        except (ValueError, TypeError):
            return jsonify({'success': False, 'message': 'Jumlah tidak valid'})
        
        # Get product
        product = Product.query.get(product_id)
        if not product:
            return jsonify({'success': False, 'message': 'Produk tidak ditemukan'})
        
        if not product.is_active:
            return jsonify({'success': False, 'message': 'Produk tidak tersedia'})
        
        # Check stock
        if not product.can_purchase(quantity):
            return jsonify({
                'success': False, 
                'message': f'Stok tidak mencukupi. Tersedia: {product.stock}'
            })
        
        # Get current cart from session
        cart = session.get('cart', [])
        
        # Check if product already in cart
        existing_item = None
        for item in cart:
            if item['id'] == product_id:
                existing_item = item
                break
        
        if existing_item:
            new_quantity = existing_item['quantity'] + quantity
            if not product.can_purchase(new_quantity):
                return jsonify({
                    'success': False,
                    'message': f'Total jumlah melebihi stok. Tersedia: {product.stock}'
                })
            existing_item['quantity'] = new_quantity
        else:
            cart.append({
                'id': product_id,
                'name': product.name,
                'price': product.price,
                'quantity': quantity,
                'image_url': product.image_url,
                'unit': product.unit
            })
        
        session['cart'] = cart
        session.modified = True
        
        # Calculate cart totals
        cart_count = sum(item['quantity'] for item in cart)
        cart_total = sum(item['price'] * item['quantity'] for item in cart)
        
        return jsonify({
            'success': True,
            'message': f'{product.name} ditambahkan ke keranjang',
            'cart_count': cart_count,
            'cart_total': cart_total
        })
    
    except Exception as e:
        logger.error(f"Add to cart error: {e}")
        return jsonify({'success': False, 'message': 'Terjadi kesalahan'}), 500

@api_bp.route('/cart/update', methods=['POST'])
@login_required
@buyer_required
def update_cart():
    """Update cart item quantity"""
    try:
        data = request.get_json()
        product_id = data.get('product_id')
        quantity = data.get('quantity', 0)
        
        try:
            quantity = int(quantity)
            if quantity < 0:
                return jsonify({'success': False, 'message': 'Jumlah tidak boleh negatif'})
        except (ValueError, TypeError):
            return jsonify({'success': False, 'message': 'Jumlah tidak valid'})
        
        cart = session.get('cart', [])
        
        # Find and update item
        for i, item in enumerate(cart):
            if item['id'] == product_id:
                if quantity == 0:
                    # Remove item from cart
                    cart.pop(i)
                else:
                    # Validate stock
                    product = Product.query.get(product_id)
                    if not product or not product.can_purchase(quantity):
                        available_stock = product.stock if product else 0
                        return jsonify({
                            'success': False,
                            'message': f'Stok tidak mencukupi. Tersedia: {available_stock}'
                        })
                    
                    # Update quantity
                    item['quantity'] = quantity
                break
        
        session['cart'] = cart
        session.modified = True
        
        # Calculate new totals
        cart_count = sum(item['quantity'] for item in cart)
        cart_total = sum(item['price'] * item['quantity'] for item in cart)
        
        return jsonify({
            'success': True,
            'cart_count': cart_count,
            'cart_total': cart_total
        })
    
    except Exception as e:
        logger.error(f"Update cart error: {e}")
        return jsonify({'success': False, 'message': 'Terjadi kesalahan'}), 500

@api_bp.route('/cart/remove', methods=['POST'])
@login_required
@buyer_required
def remove_from_cart():
    """Remove item from cart"""
    try:
        data = request.get_json()
        product_id = data.get('product_id')
        
        cart = session.get('cart', [])
        
        # Remove item
        cart = [item for item in cart if item['id'] != product_id]
        
        session['cart'] = cart
        session.modified = True
        
        # Calculate new totals
        cart_count = sum(item['quantity'] for item in cart)
        cart_total = sum(item['price'] * item['quantity'] for item in cart)
        
        return jsonify({
            'success': True,
            'message': 'Item dihapus dari keranjang',
            'cart_count': cart_count,
            'cart_total': cart_total
        })
    
    except Exception as e:
        logger.error(f"Remove from cart error: {e}")
        return jsonify({'success': False, 'message': 'Terjadi kesalahan'}), 500

@api_bp.route('/cart/clear', methods=['POST'])
@login_required
@buyer_required
def clear_cart():
    """Clear entire cart"""
    try:
        session.pop('cart', None)
        session.modified = True
        
        return jsonify({
            'success': True,
            'message': 'Keranjang dikosongkan',
            'cart_count': 0,
            'cart_total': 0
        })
    
    except Exception as e:
        logger.error(f"Clear cart error: {e}")
        return jsonify({'success': False, 'message': 'Terjadi kesalahan'}), 500

@api_bp.route('/product/<int:product_id>/stock')
def check_product_stock(product_id):
    """Check product stock availability"""
    try:
        product = Product.query.get(product_id)
        
        if not product:
            return jsonify({'error': 'Produk tidak ditemukan'}), 404
        
        return jsonify({
            'product_id': product.id,
            'stock': product.stock,
            'is_in_stock': product.is_in_stock,
            'is_low_stock': product.is_low_stock,
            'stock_status': product.stock_status,
            'min_stock': product.min_stock
        })
    
    except Exception as e:
        logger.error(f"Check stock error: {e}")
        return jsonify({'error': 'Terjadi kesalahan'}), 500

@api_bp.route('/notifications/unread-count')
@login_required
@buyer_required
def get_unread_notifications_count():
    """Get count of unread notifications for current user"""
    try:
        # For now, return 0 as we haven't implemented notifications yet
        # This can be expanded when notification system is implemented
        return jsonify({'count': 0})
    
    except Exception as e:
        logger.error(f"Get notifications count error: {e}")
        return jsonify({'count': 0})
