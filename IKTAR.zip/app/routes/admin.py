from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from app.models.models import User, Product, Transaction, Review, db, UserRole, TransactionStatus
from app.utils.decorators import role_required
from sqlalchemy import func, desc
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)
admin_bp = Blueprint('admin', __name__)

@admin_bp.before_request
def require_admin():
    """Ensure only admin users can access admin routes"""
    if not current_user.is_authenticated or not current_user.is_admin():
        flash('Akses ditolak. Halaman ini hanya untuk administrator.', 'error')
        return redirect(url_for('main.home'))

@admin_bp.route('/dashboard')
@login_required
def dashboard():
    """Admin dashboard with statistics"""
    try:
        # User statistics
        total_users = User.query.count()
        total_buyers = User.query.filter_by(role=UserRole.BUYER).count()
        total_sellers = User.query.filter_by(role=UserRole.SELLER).count()
        active_users = User.query.filter_by(is_active=True).count()
        
        # Product statistics
        total_products = Product.query.count()
        active_products = Product.query.filter_by(is_active=True).count()
        out_of_stock = Product.query.filter_by(stock=0).count()
        low_stock = Product.query.filter(Product.stock <= Product.min_stock, Product.stock > 0).count()
        
        # Transaction statistics
        total_transactions = Transaction.query.count()
        pending_transactions = Transaction.query.filter_by(status=TransactionStatus.PENDING).count()
        completed_transactions = Transaction.query.filter_by(status=TransactionStatus.DELIVERED).count()
        
        # Revenue statistics
        total_revenue = db.session.query(func.sum(Transaction.total_price)).filter_by(status=TransactionStatus.DELIVERED).scalar() or 0
        
        # Recent activities
        recent_users = User.query.order_by(desc(User.created_at)).limit(5).all()
        recent_products = Product.query.order_by(desc(Product.created_at)).limit(5).all()
        recent_transactions = Transaction.query.order_by(desc(Transaction.created_at)).limit(5).all()
        
        # Monthly revenue chart data
        monthly_revenue = []
        for i in range(12):
            month_start = datetime.now().replace(day=1) - timedelta(days=30*i)
            month_end = month_start.replace(day=28) + timedelta(days=4)
            month_end = month_end - timedelta(days=month_end.day)
            
            revenue = db.session.query(func.sum(Transaction.total_price)).filter(
                Transaction.created_at >= month_start,
                Transaction.created_at <= month_end,
                Transaction.status == TransactionStatus.DELIVERED
            ).scalar() or 0
            
            monthly_revenue.append({
                'month': month_start.strftime('%b %Y'),
                'revenue': revenue
            })
        
        monthly_revenue.reverse()
        
        stats = {
            'users': {
                'total': total_users,
                'buyers': total_buyers,
                'sellers': total_sellers,
                'active': active_users
            },
            'products': {
                'total': total_products,
                'active': active_products,
                'out_of_stock': out_of_stock,
                'low_stock': low_stock
            },
            'transactions': {
                'total': total_transactions,
                'pending': pending_transactions,
                'completed': completed_transactions
            },
            'revenue': {
                'total': total_revenue,
                'monthly': monthly_revenue
            }
        }
        
        return render_template('admin/dashboard.html',
                             stats=stats,
                             recent_users=recent_users,
                             recent_products=recent_products,
                             recent_transactions=recent_transactions)
    
    except Exception as e:
        logger.error(f"Admin dashboard error: {e}")
        flash('Terjadi kesalahan saat memuat dashboard.', 'error')
        return redirect(url_for('main.home'))

@admin_bp.route('/users')
@login_required
def users():
    """Manage users"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '', type=str)
    role_filter = request.args.get('role', '', type=str)
    status_filter = request.args.get('status', '', type=str)
    
    query = User.query
    
    # Apply filters
    if search:
        query = query.filter(
            (User.name.contains(search)) | 
            (User.email.contains(search))
        )
    
    if role_filter:
        query = query.filter_by(role=UserRole(role_filter))
    
    if status_filter == 'active':
        query = query.filter_by(is_active=True)
    elif status_filter == 'inactive':
        query = query.filter_by(is_active=False)
    
    users = query.order_by(desc(User.created_at)).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('admin/users.html', 
                         users=users,
                         search=search,
                         role_filter=role_filter,
                         status_filter=status_filter)

@admin_bp.route('/users/<int:user_id>/toggle-status', methods=['POST'])
@login_required
def toggle_user_status(user_id):
    """Toggle user active status"""
    try:
        user = User.query.get_or_404(user_id)
        
        # Prevent admin from deactivating themselves
        if user.id == current_user.id:
            flash('Anda tidak dapat menonaktifkan akun sendiri.', 'error')
            return redirect(url_for('admin.users'))
        
        # Prevent deactivating other admins
        if user.is_admin() and user.id != current_user.id:
            flash('Anda tidak dapat mengubah status administrator lain.', 'error')
            return redirect(url_for('admin.users'))
        
        user.is_active = not user.is_active
        db.session.commit()
        
        status = 'diaktifkan' if user.is_active else 'dinonaktifkan'
        flash(f'User {user.name} berhasil {status}.', 'success')
        
        logger.info(f"Admin {current_user.email} {status} user {user.email}")
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Toggle user status error: {e}")
        flash('Terjadi kesalahan saat mengubah status user.', 'error')
    
    return redirect(url_for('admin.users'))

@admin_bp.route('/users/<int:user_id>/delete', methods=['POST'])
@login_required
def delete_user(user_id):
    """Delete user (soft delete by deactivating)"""
    try:
        user = User.query.get_or_404(user_id)
        
        # Prevent admin from deleting themselves
        if user.id == current_user.id:
            flash('Anda tidak dapat menghapus akun sendiri.', 'error')
            return redirect(url_for('admin.users'))
        
        # Prevent deleting other admins
        if user.is_admin():
            flash('Anda tidak dapat menghapus administrator lain.', 'error')
            return redirect(url_for('admin.users'))
        
        # Check if user has transactions
        if user.transactions:
            # Soft delete - just deactivate
            user.is_active = False
            db.session.commit()
            flash(f'User {user.name} berhasil dinonaktifkan (memiliki riwayat transaksi).', 'warning')
        else:
            # Hard delete if no transactions
            db.session.delete(user)
            db.session.commit()
            flash(f'User {user.name} berhasil dihapus.', 'success')
        
        logger.info(f"Admin {current_user.email} deleted user {user.email}")
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Delete user error: {e}")
        flash('Terjadi kesalahan saat menghapus user.', 'error')
    
    return redirect(url_for('admin.users'))

@admin_bp.route('/products')
@login_required
def products():
    """Manage products"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '', type=str)
    category_filter = request.args.get('category', '', type=str)
    status_filter = request.args.get('status', '', type=str)
    
    query = Product.query
    
    # Apply filters
    if search:
        query = query.filter(
            (Product.name.contains(search)) | 
            (Product.description.contains(search))
        )
    
    if category_filter:
        query = query.filter_by(category=category_filter)
    
    if status_filter == 'active':
        query = query.filter_by(is_active=True)
    elif status_filter == 'inactive':
        query = query.filter_by(is_active=False)
    elif status_filter == 'out_of_stock':
        query = query.filter_by(stock=0)
    elif status_filter == 'low_stock':
        query = query.filter(Product.stock <= Product.min_stock, Product.stock > 0)
    
    products = query.order_by(desc(Product.created_at)).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('admin/products.html',
                         products=products,
                         search=search,
                         category_filter=category_filter,
                         status_filter=status_filter)

@admin_bp.route('/products/<int:product_id>/toggle-status', methods=['POST'])
@login_required
def toggle_product_status(product_id):
    """Toggle product active status"""
    try:
        product = Product.query.get_or_404(product_id)
        product.is_active = not product.is_active
        db.session.commit()
        
        status = 'diaktifkan' if product.is_active else 'dinonaktifkan'
        flash(f'Produk {product.name} berhasil {status}.', 'success')
        
        logger.info(f"Admin {current_user.email} {status} product {product.name}")
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Toggle product status error: {e}")
        flash('Terjadi kesalahan saat mengubah status produk.', 'error')
    
    return redirect(url_for('admin.products'))

@admin_bp.route('/reviews')
@login_required
def reviews():
    """Manage reviews"""
    page = request.args.get('page', 1, type=int)
    status_filter = request.args.get('status', '', type=str)
    
    query = Review.query
    
    if status_filter == 'approved':
        query = query.filter_by(is_approved=True)
    elif status_filter == 'pending':
        query = query.filter_by(is_approved=False)
    
    reviews = query.order_by(desc(Review.created_at)).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('admin/reviews.html',
                         reviews=reviews,
                         status_filter=status_filter)

@admin_bp.route('/reviews/<int:review_id>/toggle-approval', methods=['POST'])
@login_required
def toggle_review_approval(review_id):
    """Toggle review approval status"""
    try:
        review = Review.query.get_or_404(review_id)
        review.is_approved = not review.is_approved
        db.session.commit()
        
        # Update product rating
        review.product.update_rating()
        
        status = 'disetujui' if review.is_approved else 'ditolak'
        flash(f'Review berhasil {status}.', 'success')
        
        logger.info(f"Admin {current_user.email} {status} review {review.id}")
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Toggle review approval error: {e}")
        flash('Terjadi kesalahan saat mengubah status review.', 'error')
    
    return redirect(url_for('admin.reviews'))

@admin_bp.route('/transactions')
@login_required
def transactions():
    """View all transactions"""
    page = request.args.get('page', 1, type=int)
    status_filter = request.args.get('status', '', type=str)
    
    query = Transaction.query
    
    if status_filter:
        query = query.filter_by(status=TransactionStatus(status_filter))
    
    transactions = query.order_by(desc(Transaction.created_at)).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('admin/transactions.html',
                         transactions=transactions,
                         status_filter=status_filter)

@admin_bp.route('/api/stats')
@login_required
def api_stats():
    """API endpoint for dashboard statistics"""
    try:
        # Quick stats for AJAX updates
        stats = {
            'users_count': User.query.count(),
            'products_count': Product.query.count(),
            'transactions_count': Transaction.query.count(),
            'revenue_total': db.session.query(func.sum(Transaction.total_price)).filter_by(status=TransactionStatus.DELIVERED).scalar() or 0
        }
        
        return jsonify(stats)
    
    except Exception as e:
        logger.error(f"API stats error: {e}")
        return jsonify({'error': 'Failed to fetch stats'}), 500
