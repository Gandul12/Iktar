from flask import Blueprint, render_template, request
from app.models import Product

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def home():
    products = Product.query.filter_by(is_active=True).limit(8).all()
    return render_template('main/home.html', products=products)

@main_bp.route('/products')
def products():
    page = request.args.get('page', 1, type=int)
    products = Product.query.filter_by(is_active=True).paginate(
        page=page, per_page=12, error_out=False
    )
    return render_template('main/products.html', products=products)

@main_bp.route('/about')
def about():
    return render_template('main/about.html')

@main_bp.route('/contact')
def contact():
    return render_template('main/contact.html')
