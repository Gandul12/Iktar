from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app.models.models import Product, CartItem, Transaction, TransactionItem, Address, TransactionStatus
from app.forms.forms import AddressForm
from app.utils.decorators import buyer_required
from app import db
from datetime import datetime
from decimal import Decimal

buyer_bp = Blueprint('buyer', __name__)

@buyer_bp.route('/dashboard')
@login_required
@buyer_required
def dashboard():
    """Buyer dashboard"""
    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    cart_total = sum(item.get_total_price() for item in cart_items)
    
    return render_template('buyer/dashboard.html', 
                         cart_items=cart_items,
                         cart_total=cart_total)

@buyer_bp.route('/cart')
@login_required
@buyer_required
def cart():
    """Shopping cart"""
    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    cart_total = sum(item.get_total_price() for item in cart_items)
    
    return render_template('buyer/cart.html', 
                         cart_items=cart_items,
                         cart_total=cart_total)

@buyer_bp.route('/add-to-cart/<int:product_id>', methods=['POST'])
@login_required
@buyer_required
def add_to_cart(product_id):
    """Add product to cart"""
    product = Product.query.get_or_404(product_id)
    
    if not product.is_active or not product.is_in_stock():
        flash('Produk tidak tersedia.', 'danger')
        return redirect(url_for('product.detail', id=product_id))
    
    # Check if item already in cart
    cart_item = CartItem.query.filter_by(
        user_id=current_user.id, 
        product_id=product_id
    ).first()
    
    try:
        if cart_item:
            cart_item.quantity += 1
        else:
            cart_item = CartItem(
                user_id=current_user.id,
                product_id=product_id,
                quantity=1
            )
            db.session.add(cart_item)
        
        db.session.commit()
        flash('Produk ditambahkan ke keranjang!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash('Terjadi kesalahan saat menambah ke keranjang.', 'danger')
        print(f"Add to cart error: {e}")
    
    return redirect(url_for('product.detail', id=product_id))

@buyer_bp.route('/update-cart/<int:item_id>', methods=['POST'])
@login_required
@buyer_required
def update_cart(item_id):
    """Update cart item quantity"""
    cart_item = CartItem.query.filter_by(
        id=item_id,
        user_id=current_user.id
    ).first_or_404()
    
    quantity = int(request.form.get('quantity', 1))
    
    if quantity <= 0:
        db.session.delete(cart_item)
    else:
        if quantity > cart_item.product.stock:
            flash('Stok tidak mencukupi.', 'error')
            return redirect(url_for('buyer.cart'))
        
        cart_item.quantity = quantity
    
    try:
        db.session.commit()
        flash('Keranjang berhasil diperbarui.', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Terjadi kesalahan. Silakan coba lagi.', 'error')
    
    return redirect(url_for('buyer.cart'))

@buyer_bp.route('/remove-from-cart/<int:item_id>', methods=['POST'])
@login_required
@buyer_required
def remove_from_cart(item_id):
    cart_item = CartItem.query.filter_by(
        id=item_id, 
        user_id=current_user.id
    ).first_or_404()
    
    try:
        db.session.delete(cart_item)
        db.session.commit()
        flash('Item dihapus dari keranjang.', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Terjadi kesalahan saat menghapus item.', 'danger')
        print(f"Remove from cart error: {e}")
    
    return redirect(url_for('buyer.cart'))

@buyer_bp.route('/checkout')
@login_required
@buyer_required
def checkout():
    """Checkout page"""
    cart_items = CartItem.query.filter_by(user_id=current_user.id)\
        .join(Product).filter(Product.is_active == True).all()
    
    if not cart_items:
        flash('Keranjang Anda kosong.', 'warning')
        return redirect(url_for('buyer.cart'))
    
    # Check stock availability
    for item in cart_items:
        if not item.product.is_in_stock(item.quantity):
            flash(f'Stok {item.product.name} tidak mencukupi.', 'error')
            return redirect(url_for('buyer.cart'))
    
    addresses = Address.query.filter_by(user_id=current_user.id).all()
    total_amount = sum(item.total_price for item in cart_items)
    
    return render_template('buyer/checkout.html',
                         cart_items=cart_items,
                         addresses=addresses,
                         total_amount=total_amount)

@buyer_bp.route('/process-checkout', methods=['POST'])
@login_required
@buyer_required
def process_checkout():
    """Process checkout"""
    cart_items = CartItem.query.filter_by(user_id=current_user.id)\
        .join(Product).filter(Product.is_active == True).all()
    
    if not cart_items:
        flash('Keranjang Anda kosong.', 'error')
        return redirect(url_for('buyer.cart'))
    
    address_id = request.form.get('address_id', type=int)
    notes = request.form.get('notes', '').strip()
    
    if not address_id:
        flash('Pilih alamat pengiriman.', 'error')
        return redirect(url_for('buyer.checkout'))
    
    address = Address.query.filter_by(id=address_id, user_id=current_user.id).first()
    if not address:
        flash('Alamat tidak valid.', 'error')
        return redirect(url_for('buyer.checkout'))
    
    try:
        # Group items by seller
        sellers_items = {}
        for item in cart_items:
            seller_id = item.product.seller_id
            if seller_id not in sellers_items:
                sellers_items[seller_id] = []
            sellers_items[seller_id].append(item)
        
        # Create separate transactions for each seller
        transactions = []
        for seller_id, items in sellers_items.items():
            total_amount = sum(item.total_price for item in items)
            
            transaction = Transaction(
                buyer_id=current_user.id,
                seller_id=seller_id,
                total_amount=Decimal(str(total_amount)),
                shipping_address_id=address_id,
                notes=notes
            )
            transaction.generate_transaction_code()
            db.session.add(transaction)
            db.session.flush()  # Get transaction ID
            
            # Add transaction items and reduce stock
            for item in items:
                if not item.product.reduce_stock(item.quantity):
                    raise Exception(f'Stok {item.product.name} tidak mencukupi')
                
                transaction_item = TransactionItem(
                    transaction_id=transaction.id,
                    product_id=item.product_id,
                    quantity=item.quantity,
                    price=item.product.price
                )
                db.session.add(transaction_item)
            
            transactions.append(transaction)
        
        # Clear cart
        for item in cart_items:
            db.session.delete(item)
        
        db.session.commit()
        
        flash('Pesanan berhasil dibuat! Silakan lakukan pembayaran.', 'success')
        return redirect(url_for('buyer.transactions'))
        
    except Exception as e:
        db.session.rollback()
        flash(f'Terjadi kesalahan: {str(e)}', 'error')
        return redirect(url_for('buyer.checkout'))

@buyer_bp.route('/transactions')
@login_required
@buyer_required
def transactions():
    """Transaction history"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '')
    
    query = Transaction.query.filter_by(buyer_id=current_user.id)
    
    if status:
        try:
            status_enum = TransactionStatus(status)
            query = query.filter_by(status=status_enum)
        except ValueError:
            pass
    
    transactions = query.order_by(Transaction.created_at.desc())\
        .paginate(page=page, per_page=10, error_out=False)
    
    return render_template('buyer/transactions.html', transactions=transactions, current_status=status)

@buyer_bp.route('/transaction/<int:id>')
@login_required
@buyer_required
def transaction_detail(id):
    """Transaction detail"""
    transaction = Transaction.query.filter_by(id=id, buyer_id=current_user.id).first_or_404()
    return render_template('buyer/transaction_detail.html', transaction=transaction)

@buyer_bp.route('/addresses')
@login_required
@buyer_required
def addresses():
    """Address management"""
    addresses = Address.query.filter_by(user_id=current_user.id).all()
    return render_template('buyer/addresses.html', addresses=addresses)

@buyer_bp.route('/add-address', methods=['GET', 'POST'])
@login_required
@buyer_required
def add_address():
    """Add new address"""
    form = AddressForm()
    
    if form.validate_on_submit():
        try:
            # If this is set as default, unset other defaults
            if form.is_default.data:
                Address.query.filter_by(user_id=current_user.id, is_default=True)\
                    .update({'is_default': False})
            
            address = Address(
                user_id=current_user.id,
                recipient_name=form.recipient_name.data,
                phone=form.phone.data,
                address_line=form.address_line.data,
                city=form.city.data,
                postal_code=form.postal_code.data,
                is_default=form.is_default.data
            )
            
            db.session.add(address)
            db.session.commit()
            
            flash('Alamat berhasil ditambahkan.', 'success')
            return redirect(url_for('buyer.addresses'))
            
        except Exception as e:
            db.session.rollback()
            flash('Terjadi kesalahan. Silakan coba lagi.', 'error')
    
    return render_template('buyer/address_form.html', form=form, title='Tambah Alamat')

@buyer_bp.route('/edit-address/<int:id>', methods=['GET', 'POST'])
@login_required
@buyer_required
def edit_address(id):
    """Edit address"""
    address = Address.query.filter_by(id=id, user_id=current_user.id).first_or_404()
    form = AddressForm(obj=address)
    
    if form.validate_on_submit():
        try:
            if form.is_default.data and not address.is_default:
                Address.query.filter_by(user_id=current_user.id, is_default=True)\
                    .update({'is_default': False})
            
            form.populate_obj(address)
            db.session.commit()
            
            flash('Alamat berhasil diperbarui.', 'success')
            return redirect(url_for('buyer.addresses'))
            
        except Exception as e:
            db.session.rollback()
            flash('Terjadi kesalahan saat memperbarui alamat.', 'error')
    
    return render_template('buyer/edit_address.html', form=form, address=address)

@buyer_bp.route('/delete-address/<int:id>', methods=['POST'])
@login_required
@buyer_required
def delete_address(id):
    """Delete address"""
    address = Address.query.filter_by(id=id, user_id=current_user.id).first_or_404()
    
    if address.is_default:
        flash('Alamat default tidak dapat dihapus.', 'error')
        return redirect(url_for('buyer.addresses'))
    
    try:
        db.session.delete(address)
        db.session.commit()
        flash('Alamat berhasil dihapus.', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Terjadi kesalahan saat menghapus alamat.', 'error')
    
    return redirect(url_for('buyer.addresses'))

@buyer_bp.route('/orders')
@login_required
@buyer_required
def orders():
    """Order history"""
    return render_template('buyer/orders.html')
