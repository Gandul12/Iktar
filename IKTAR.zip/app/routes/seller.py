from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import current_user
from app import db
from app.models import Product
from app.forms import ProductForm
from app.decorators import seller_required

seller_bp = Blueprint('seller', __name__)

@seller_bp.route('/dashboard')
@seller_required
def dashboard():
    products = Product.query.filter_by(seller_id=current_user.id).all()
    return render_template('seller/dashboard.html', products=products)

@seller_bp.route('/products')
@seller_required
def products():
    page = request.args.get('page', 1, type=int)
    products = Product.query.filter_by(seller_id=current_user.id).paginate(
        page=page, per_page=10, error_out=False
    )
    return render_template('seller/products.html', products=products)

@seller_bp.route('/add-product', methods=['GET', 'POST'])
@seller_required
def add_product():
    form = ProductForm()
    if form.validate_on_submit():
        try:
            product = Product(
                name=form.name.data,
                description=form.description.data,
                price=form.price.data,
                stock=form.stock.data,
                category=form.category.data,
                seller_id=current_user.id
            )
            
            db.session.add(product)
            db.session.commit()
            
            flash('Produk berhasil ditambahkan!', 'success')
            return redirect(url_for('seller.products'))
            
        except Exception as e:
            db.session.rollback()
            flash('Terjadi kesalahan saat menambahkan produk.', 'danger')
    
    return render_template('seller/product_form.html', form=form, title='Tambah Produk')

@seller_bp.route('/edit-product/<int:id>', methods=['GET', 'POST'])
@seller_required
def edit_product(id):
    product = Product.query.filter_by(id=id, seller_id=current_user.id).first_or_404()
    form = ProductForm(obj=product)
    
    if form.validate_on_submit():
        try:
            form.populate_obj(product)
            db.session.commit()
            
            flash('Produk berhasil diperbarui!', 'success')
            return redirect(url_for('seller.products'))
            
        except Exception as e:
            db.session.rollback()
            flash('Terjadi kesalahan saat memperbarui produk.', 'danger')
    
    return render_template('seller/product_form.html', form=form, title='Edit Produk')

@seller_bp.route('/delete-product/<int:id>')
@seller_required
def delete_product(id):
    product = Product.query.filter_by(id=id, seller_id=current_user.id).first_or_404()
    
    try:
        db.session.delete(product)
        db.session.commit()
        flash('Produk berhasil dihapus!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Terjadi kesalahan saat menghapus produk.', 'danger')
    
    return redirect(url_for('seller.products'))
