"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Navbar } from "@/components/layout/navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft, ShoppingCart, Minus, Plus, Trash2, CreditCard, Truck, MapPin, Clock } from "lucide-react"
import { useAuth } from "@/lib/auth"
import { cartService, formatPrice, type CartItem } from "@/lib/data"

export default function CartPage() {
  const router = useRouter()
  const { user, isAuthenticated } = useAuth()
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [loading, setLoading] = useState(true)
  const [checkoutLoading, setCheckoutLoading] = useState(false)
  const [shippingAddress, setShippingAddress] = useState("")
  const [paymentMethod, setPaymentMethod] = useState("bank_transfer")
  const [notes, setNotes] = useState("")

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth/login")
      return
    }

    // Load cart items
    const items = cartService.getCart()
    setCartItems(items)
    setLoading(false)

    // Subscribe to cart changes
    const unsubscribe = cartService.subscribe(() => {
      setCartItems(cartService.getCart())
    })

    return unsubscribe
  }, [isAuthenticated, router])

  const updateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity < 1) return
    cartService.updateQuantity(productId, newQuantity)
  }

  const removeItem = (productId: number) => {
    cartService.removeFromCart(productId)
  }

  const handleCheckout = async () => {
    if (!shippingAddress.trim()) {
      alert("Mohon isi alamat pengiriman")
      return
    }

    if (cartItems.length === 0) {
      alert("Keranjang kosong")
      return
    }

    setCheckoutLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Create order
      const order = {
        id: Date.now(),
        user_id: user?.id,
        items: cartItems,
        total: cartService.getCartTotal(),
        status: "pending",
        shipping_address: shippingAddress,
        payment_method: paymentMethod,
        notes,
        created_at: new Date().toISOString(),
      }

      // Clear cart
      cartService.clearCart()

      alert("Pesanan berhasil dibuat! Silakan lakukan pembayaran.")
      router.push("/dashboard/buyer")
    } catch (error) {
      alert("Terjadi kesalahan saat checkout")
    } finally {
      setCheckoutLoading(false)
    }
  }

  const subtotal = cartService.getCartTotal()
  const shippingCost = subtotal > 100000 ? 0 : 15000
  const total = subtotal + shippingCost

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-32 bg-gray-200 rounded"></div>
                ))}
              </div>
              <div className="h-64 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" onClick={() => router.back()}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Kembali
          </Button>
          <div>
            <h1 className="text-3xl font-bold">Keranjang Belanja</h1>
            <p className="text-gray-600">{cartItems.length} item dalam keranjang</p>
          </div>
        </div>

        {cartItems.length === 0 ? (
          <Card>
            <CardContent className="text-center py-16">
              <ShoppingCart className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-900 mb-2">Keranjang Kosong</h3>
              <p className="text-gray-600 mb-6">Belum ada produk dalam keranjang Anda</p>
              <Button asChild>
                <Link href="/products">Mulai Belanja</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Item Pesanan</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex items-center gap-4 p-4 border rounded-lg">
                      <div className="flex-shrink-0">
                        <img
                          src={item.product.image_url || "/placeholder.svg"}
                          alt={item.product.name}
                          className="w-20 h-20 object-cover rounded"
                        />
                      </div>

                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-lg line-clamp-1">{item.product.name}</h3>
                        <p className="text-sm text-gray-600">Penjual: {item.product.seller_name}</p>
                        <p className="text-lg font-bold text-blue-600 mt-1">{formatPrice(item.product.price)}</p>
                      </div>

                      <div className="flex items-center gap-3">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateQuantity(item.product_id, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>

                        <Input
                          type="number"
                          value={item.quantity}
                          onChange={(e) => updateQuantity(item.product_id, Number.parseInt(e.target.value) || 1)}
                          className="w-16 text-center"
                          min="1"
                          max={item.product.stock}
                        />

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateQuantity(item.product_id, item.quantity + 1)}
                          disabled={item.quantity >= item.product.stock}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="text-right">
                        <p className="font-bold text-lg">{formatPrice(item.subtotal)}</p>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeItem(item.product_id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Shipping Address */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5" />
                    Alamat Pengiriman
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="address">Alamat Lengkap *</Label>
                      <Textarea
                        id="address"
                        placeholder="Masukkan alamat lengkap termasuk kode pos"
                        value={shippingAddress}
                        onChange={(e) => setShippingAddress(e.target.value)}
                        rows={3}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="notes">Catatan (Opsional)</Label>
                      <Textarea
                        id="notes"
                        placeholder="Catatan untuk penjual atau kurir"
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        rows={2}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Method */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Metode Pembayaran
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                    <div className="flex items-center space-x-2 p-3 border rounded-lg">
                      <RadioGroupItem value="bank_transfer" id="bank_transfer" />
                      <Label htmlFor="bank_transfer" className="flex-1 cursor-pointer">
                        <div>
                          <p className="font-medium">Transfer Bank</p>
                          <p className="text-sm text-gray-600">BCA, BNI, BRI, Mandiri</p>
                        </div>
                      </Label>
                    </div>

                    <div className="flex items-center space-x-2 p-3 border rounded-lg">
                      <RadioGroupItem value="e_wallet" id="e_wallet" />
                      <Label htmlFor="e_wallet" className="flex-1 cursor-pointer">
                        <div>
                          <p className="font-medium">E-Wallet</p>
                          <p className="text-sm text-gray-600">GoPay, OVO, DANA, ShopeePay</p>
                        </div>
                      </Label>
                    </div>

                    <div className="flex items-center space-x-2 p-3 border rounded-lg">
                      <RadioGroupItem value="cod" id="cod" />
                      <Label htmlFor="cod" className="flex-1 cursor-pointer">
                        <div>
                          <p className="font-medium">Bayar di Tempat (COD)</p>
                          <p className="text-sm text-gray-600">Bayar saat barang diterima</p>
                        </div>
                      </Label>
                    </div>
                  </RadioGroup>
                </CardContent>
              </Card>
            </div>

            {/* Order Summary */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Ringkasan Pesanan</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal ({cartItems.length} item)</span>
                      <span>{formatPrice(subtotal)}</span>
                    </div>

                    <div className="flex justify-between">
                      <span className="flex items-center gap-1">
                        <Truck className="h-4 w-4" />
                        Ongkos Kirim
                      </span>
                      <span className={shippingCost === 0 ? "text-green-600" : ""}>
                        {shippingCost === 0 ? "Gratis" : formatPrice(shippingCost)}
                      </span>
                    </div>

                    {shippingCost === 0 && (
                      <p className="text-xs text-green-600">🎉 Gratis ongkir untuk pembelian di atas Rp 100.000</p>
                    )}
                  </div>

                  <Separator />

                  <div className="flex justify-between text-lg font-bold">
                    <span>Total</span>
                    <span className="text-blue-600">{formatPrice(total)}</span>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="h-4 w-4" />
                      <span>Estimasi pengiriman: 1-3 hari kerja</span>
                    </div>

                    <Button
                      onClick={handleCheckout}
                      disabled={checkoutLoading || !shippingAddress.trim()}
                      className="w-full"
                      size="lg"
                    >
                      {checkoutLoading ? (
                        "Memproses..."
                      ) : (
                        <>
                          <CreditCard className="mr-2 h-5 w-5" />
                          Checkout Sekarang
                        </>
                      )}
                    </Button>

                    <p className="text-xs text-gray-600 text-center">
                      Dengan melanjutkan, Anda menyetujui{" "}
                      <Link href="/terms" className="text-blue-600 hover:underline">
                        syarat dan ketentuan
                      </Link>{" "}
                      kami
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Security Info */}
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <div className="flex justify-center mb-2">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <span className="text-green-600 text-sm">🔒</span>
                      </div>
                    </div>
                    <p className="text-sm font-medium">Transaksi Aman</p>
                    <p className="text-xs text-gray-600">Data Anda dilindungi dengan enkripsi SSL</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
