from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, FloatField, IntegerField, SelectField, PasswordField, SubmitField, BooleanField
from wtforms.validators import DataRequired, Email, Length, NumberRange, EqualTo, ValidationError
from app.models.models import User, UserRole

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Ingat Saya')
    submit = SubmitField('Masuk')

class RegistrationForm(FlaskForm):
    name = StringField('Nama Lengkap', validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    password2 = PasswordField('Konfirmasi Password', 
                             validators=[DataRequired(), EqualTo('password', message='Password tidak cocok')])
    role = SelectField('Daftar Sebagai', 
                      choices=[('buyer', 'Pembeli'), ('seller', 'Penjual')],
                      validators=[DataRequired()])
    submit = SubmitField('Daftar')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data.lower()).first()
        if user:
            raise ValidationError('Email sudah terdaftar. Silakan gunakan email lain.')

class ChangePasswordForm(FlaskForm):
    current_password = PasswordField('Password Saat Ini', validators=[DataRequired()])
    new_password = PasswordField('Password Baru', validators=[DataRequired(), Length(min=6)])
    new_password2 = PasswordField('Konfirmasi Password Baru', 
                                 validators=[DataRequired(), EqualTo('new_password')])
    submit = SubmitField('Ubah Password')

class ProductForm(FlaskForm):
    name = StringField('Nama Produk', validators=[DataRequired(), Length(min=2, max=100)])
    description = TextAreaField('Deskripsi', validators=[DataRequired(), Length(min=10)])
    price = FloatField('Harga (Rp)', validators=[DataRequired(), NumberRange(min=0)])
    stock = IntegerField('Stok', validators=[DataRequired(), NumberRange(min=0)])
    category = SelectField('Kategori', 
                          choices=[('hias', 'Ikan Hias'), ('konsumsi', 'Ikan Konsumsi'), 
                                  ('bibit', 'Bibit Ikan'), ('predator', 'Ikan Predator')],
                          validators=[DataRequired()])
    submit = SubmitField('Simpan')

class AddressForm(FlaskForm):
    recipient_name = StringField('Nama Penerima', validators=[
        DataRequired(message='Nama penerima harus diisi'),
        Length(min=2, max=100, message='Nama penerima harus antara 2-100 karakter')
    ])
    
    phone = StringField('Nomor Telepon', validators=[
        DataRequired(message='Nomor telepon harus diisi'),
        Length(min=10, max=15, message='Nomor telepon harus antara 10-15 digit')
    ])
    
    address_line = TextAreaField('Alamat Lengkap', validators=[
        DataRequired(message='Alamat lengkap harus diisi'),
        Length(min=10, message='Alamat minimal 10 karakter')
    ])
    
    city = StringField('Kota', validators=[
        DataRequired(message='Kota harus diisi'),
        Length(min=2, max=100, message='Nama kota harus antara 2-100 karakter')
    ])
    
    postal_code = StringField('Kode Pos', validators=[
        DataRequired(message='Kode pos harus diisi'),
        Length(min=5, max=5, message='Kode pos harus 5 digit')
    ])
    
    is_default = BooleanField('Jadikan Alamat Utama')
    submit = SubmitField('Simpan Alamat')

class ForgotPasswordForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    submit = SubmitField('Kirim Link Reset')

class ResetPasswordForm(FlaskForm):
    password = PasswordField('Password Baru', validators=[DataRequired(), Length(min=6)])
    password2 = PasswordField('Konfirmasi Password Baru', 
                             validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Reset Password')

class ReviewForm(FlaskForm):
    rating = SelectField('Rating', choices=[
        ('5', '⭐⭐⭐⭐⭐ Sangat Baik'),
        ('4', '⭐⭐⭐⭐ Baik'),
        ('3', '⭐⭐⭐ Cukup'),
        ('2', '⭐⭐ Kurang'),
        ('1', '⭐ Sangat Kurang')
    ], validators=[DataRequired(message='Rating harus dipilih')])
    
    comment = TextAreaField('Komentar', validators=[
        Length(max=500, message='Komentar maksimal 500 karakter')
    ])
    
    submit = SubmitField('Kirim Review')

class CartForm(FlaskForm):
    quantity = IntegerField('Jumlah', validators=[DataRequired(), NumberRange(min=1)], default=1)
    submit = SubmitField('Tambah ke Keranjang')
