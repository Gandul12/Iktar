import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, password, role, phone } = body

    // Validation
    if (!name || !email || !password || !role || !phone) {
      return NextResponse.json({ message: "Semua field harus diisi!" }, { status: 400 })
    }

    if (password.length < 6) {
      return NextResponse.json({ message: "Password minimal 6 karakter!" }, { status: 400 })
    }

    // Check if email already exists (demo)
    const existingEmails = ["admin@iktar.com", "seller@iktar.com", "buyer@iktar.com"]
    if (existingEmails.includes(email)) {
      return NextResponse.json({ message: "Email sudah terdaftar!" }, { status: 400 })
    }

    // Simulate successful registration
    const user = {
      id: Date.now(),
      name,
      email,
      role,
      phone,
      created_at: new Date().toISOString(),
    }

    return NextResponse.json({
      message: "Registrasi berhasil!",
      user,
    })
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json({ message: "Terjadi kesalahan server!" }, { status: 500 })
  }
}
