import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password } = body

    // Demo accounts
    const demoAccounts = {
      "admin@iktar.com": {
        id: 1,
        role: "admin",
        name: "Admin IkTar",
        password: "admin123",
        phone: "081234567890",
      },
      "seller@iktar.com": {
        id: 2,
        role: "seller",
        name: "Penjual Demo",
        password: "seller123",
        phone: "081234567891",
      },
      "buyer@iktar.com": {
        id: 3,
        role: "buyer",
        name: "Pembeli Demo",
        password: "buyer123",
        phone: "081234567892",
      },
    }

    const account = demoAccounts[email as keyof typeof demoAccounts]

    if (!account || account.password !== password) {
      return NextResponse.json({ message: "Email atau password salah!" }, { status: 401 })
    }

    // Return user data (excluding password)
    const { password: _, ...userData } = account

    return NextResponse.json({
      message: "Login berhasil!",
      user: {
        ...userData,
        email,
      },
    })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ message: "Terjadi kesalahan server!" }, { status: 500 })
  }
}
