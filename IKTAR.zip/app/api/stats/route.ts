import { NextResponse } from "next/server"

export async function GET() {
  return NextResponse.json({
    success: true,
    stats: {
      total_products: 123,
      total_sellers: 17,
      total_buyers: 322,
      categories: ["hias", "konsumsi", "predator", "bibit"],
    },
  })
}
