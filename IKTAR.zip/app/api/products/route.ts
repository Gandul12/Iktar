import { NextResponse } from "next/server"

const mockProducts = Array.from({ length: 8 }).map((_, i) => ({
  id: i + 1,
  name: `Ikan Demo #${i + 1}`,
  description: "Deskripsi ikan demo untuk tujuan preview.",
  price: 12000 + i * 1500,
  stock: 20 - i,
  category: ["hias", "konsumsi", "predator", "bibit"][i % 4],
  image_url: "/placeholder.svg?height=192&width=360",
  seller_name: "Penjual Demo",
  stock_status: i % 3 === 0 ? "low_stock" : "in_stock",
}))

export async function GET() {
  return NextResponse.json({
    success: true,
    products: mockProducts,
    pagination: {
      page: 1,
      pages: 1,
      per_page: 8,
      total: mockProducts.length,
      has_next: false,
      has_prev: false,
    },
  })
}
