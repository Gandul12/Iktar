#!/usr/bin/env python3
"""
IkTar Backend - Complete Flask API Server
Enhanced version with full features
"""

from flask import Flask, jsonify, request, session
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import secrets
import os

# Create Flask app
app = Flask(__name__)
CORS(app, supports_credentials=True, origins=["http://localhost:3000"])

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'iktar-secret-key-2024')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///iktar.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SESSION_PERMANENT'] = False
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=30)

# Initialize database
db = SQLAlchemy(app)

# Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(20))
    role = db.Column(db.String(20), default='buyer')  # buyer, seller, admin
    avatar = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reset_token = db.Column(db.String(100))
    reset_token_expires = db.Column(db.DateTime)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'role': self.role,
            'avatar': self.avatar or '/placeholder.svg?height=40&width=40',
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, default=0)
    category = db.Column(db.String(50))
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    image_url = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    seller = db.relationship('User', backref='products')
    
    def get_average_rating(self):
        reviews = Review.query.filter_by(product_id=self.id).all()
        if not reviews:
            return 0
        return round(sum(review.rating for review in reviews) / len(reviews), 1)
    
    def get_stock_status(self):
        if self.stock == 0:
            return 'out_of_stock'
        elif self.stock <= 5:
            return 'low_stock'
        return 'in_stock'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'price': self.price,
            'stock': self.stock,
            'category': self.category,
            'seller_id': self.seller_id,
            'seller_name': self.seller.name if self.seller else 'Unknown',
            'image_url': self.image_url or '/placeholder.svg?height=300&width=400',
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'average_rating': self.get_average_rating(),
            'stock_status': self.get_stock_status()
        }

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, processing, shipped, delivered, cancelled
    shipping_address = db.Column(db.Text)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    buyer = db.relationship('User', foreign_keys=[buyer_id], backref='purchases')
    seller = db.relationship('User', foreign_keys=[seller_id], backref='sales')
    product = db.relationship('Product', backref='transactions')
    
    def to_dict(self):
        return {
            'id': self.id,
            'buyer_id': self.buyer_id,
            'buyer_name': self.buyer.name if self.buyer else 'Unknown',
            'seller_id': self.seller_id,
            'seller_name': self.seller.name if self.seller else 'Unknown',
            'product_id': self.product_id,
            'product_name': self.product.name if self.product else 'Unknown',
            'product_image': self.product.image_url if self.product else '/placeholder.svg?height=100&width=100',
            'quantity': self.quantity,
            'total_price': self.total_price,
            'status': self.status,
            'shipping_address': self.shipping_address,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.Integer, db.ForeignKey('transaction.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    buyer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1-5
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    transaction = db.relationship('Transaction', backref='review')
    product = db.relationship('Product', backref='reviews')
    buyer = db.relationship('User', backref='reviews')
    
    def to_dict(self):
        return {
            'id': self.id,
            'transaction_id': self.transaction_id,
            'product_id': self.product_id,
            'buyer_id': self.buyer_id,
            'buyer_name': self.buyer.name if self.buyer else 'Anonymous',
            'rating': self.rating,
            'comment': self.comment,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    buyer = db.relationship('User', backref='cart_items')
    product = db.relationship('Product', backref='cart_items')
    
    def to_dict(self):
        return {
            'id': self.id,
            'buyer_id': self.buyer_id,
            'product_id': self.product_id,
            'product': self.product.to_dict() if self.product else None,
            'quantity': self.quantity,
            'subtotal': self.product.price * self.quantity if self.product else 0,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

# Helper functions
def login_required(f):
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

def admin_required(f):
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        user = User.query.get(session['user_id'])
        if not user or user.role != 'admin':
            return jsonify({'error': 'Admin access required'}), 403
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

def seller_required(f):
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        user = User.query.get(session['user_id'])
        if not user or user.role not in ['seller', 'admin']:
            return jsonify({'error': 'Seller access required'}), 403
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

# Routes
@app.route('/')
def home():
    return jsonify({
        'message': 'IkTar Backend API is running!',
        'status': 'success',
        'version': '2.0.0',
        'endpoints': {
            'auth': '/api/auth/*',
            'products': '/api/products',
            'cart': '/api/cart',
            'transactions': '/api/transactions',
            'reviews': '/api/reviews',
            'admin': '/api/admin/*'
        }
    })

# Authentication Routes
@app.route('/api/auth/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        
        # Validation
        required_fields = ['name', 'email', 'password', 'role', 'phone']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Check if user exists
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email sudah terdaftar'}), 400
        
        # Create new user
        user = User(
            name=data['name'],
            email=data['email'],
            phone=data.get('phone'),
            role=data.get('role', 'buyer'),
            avatar='/placeholder.svg?height=40&width=40'
        )
        user.set_password(data['password'])
        
        db.session.add(user)
        db.session.commit()
        
        return jsonify({
            'message': 'Registrasi berhasil',
            'user': user.to_dict()
        }), 201
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/auth/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        user = User.query.filter_by(email=data['email'], is_active=True).first()
        
        if user and user.check_password(data['password']):
            session['user_id'] = user.id
            session['user_role'] = user.role
            session.permanent = True
            
            return jsonify({
                'message': 'Login berhasil',
                'user': user.to_dict()
            })
        
        return jsonify({'error': 'Email atau password salah'}), 401
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'message': 'Logout berhasil'})

@app.route('/api/auth/me', methods=['GET'])
@login_required
def get_current_user():
    user = User.query.get(session['user_id'])
    return jsonify(user.to_dict())

# Product Routes
@app.route('/api/products', methods=['GET'])
def get_products():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 12, type=int)
        category = request.args.get('category')
        search = request.args.get('search')
        min_price = request.args.get('min_price', type=float)
        max_price = request.args.get('max_price', type=float)
        min_rating = request.args.get('min_rating', type=float)
        
        query = Product.query.filter_by(is_active=True)
        
        if category:
            query = query.filter(Product.category == category)
        
        if search:
            query = query.filter(Product.name.contains(search))
        
        if min_price:
            query = query.filter(Product.price >= min_price)
        
        if max_price:
            query = query.filter(Product.price <= max_price)
        
        products = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        result = []
        for product in products.items:
            product_dict = product.to_dict()
            if min_rating and product_dict['average_rating'] < min_rating:
                continue
            result.append(product_dict)
        
        return jsonify({
            'products': result,
            'total': products.total,
            'pages': products.pages,
            'current_page': page,
            'has_next': products.has_next,
            'has_prev': products.has_prev
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/stats', methods=['GET'])
def get_stats():
    try:
        total_products = Product.query.filter_by(is_active=True).count()
        total_sellers = User.query.filter_by(role='seller', is_active=True).count()
        total_buyers = User.query.filter_by(role='buyer', is_active=True).count()
        total_transactions = Transaction.query.count()
        
        categories = db.session.query(Product.category).filter_by(is_active=True).distinct().all()
        categories = [cat[0] for cat in categories if cat[0]]
        
        return jsonify({
            'totalProducts': total_products,
            'totalSellers': total_sellers,
            'totalBuyers': total_buyers,
            'totalTransactions': total_transactions,
            'categories': categories
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def create_sample_data():
    """Create sample data for development"""
    try:
        # Create admin user
        if not User.query.filter_by(email='admin@iktar.com').first():
            admin = User(
                name='Admin IkTar',
                email='admin@iktar.com',
                phone='081234567890',
                role='admin',
                avatar='/placeholder.svg?height=40&width=40'
            )
            admin.set_password('admin123')
            db.session.add(admin)
        
        # Create sample seller
        if not User.query.filter_by(email='seller@iktar.com').first():
            seller = User(
                name='Penjual Demo',
                email='seller@iktar.com',
                phone='081234567891',
                role='seller',
                avatar='/placeholder.svg?height=40&width=40'
            )
            seller.set_password('seller123')
            db.session.add(seller)
            db.session.commit()
            
            # Create sample products
            products_data = [
                {
                    'name': 'Ikan Guppy Premium',
                    'description': 'Ikan guppy berkualitas tinggi dengan warna-warna indah. Cocok untuk aquarium hias. Mudah dipelihara dan cocok untuk pemula.',
                    'price': 15000,
                    'stock': 50,
                    'category': 'hias',
                    'image_url': '/placeholder.svg?height=300&width=400'
                },
                {
                    'name': 'Ikan Lele Segar',
                    'description': 'Ikan lele segar langsung dari kolam. Daging empuk dan bergizi tinggi. Cocok untuk berbagai masakan.',
                    'price': 25000,
                    'stock': 30,
                    'category': 'konsumsi',
                    'image_url': '/placeholder.svg?height=300&width=400'
                },
                {
                    'name': 'Ikan Arwana Silver',
                    'description': 'Ikan arwana silver berkualitas tinggi. Cocok untuk aquarium besar. Ikan predator yang eksotis dan menarik.',
                    'price': 500000,
                    'stock': 5,
                    'category': 'predator',
                    'image_url': '/placeholder.svg?height=300&width=400'
                },
                {
                    'name': 'Bibit Ikan Nila',
                    'description': 'Bibit ikan nila unggul untuk budidaya. Pertumbuhan cepat dan tahan penyakit. Cocok untuk pemula dalam budidaya.',
                    'price': 5000,
                    'stock': 100,
                    'category': 'bibit',
                    'image_url': '/placeholder.svg?height=300&width=400'
                },
                {
                    'name': 'Ikan Cupang Halfmoon',
                    'description': 'Ikan cupang halfmoon dengan sirip yang indah. Warna cerah dan bentuk sirip sempurna. Cocok untuk kompetisi.',
                    'price': 35000,
                    'stock': 25,
                    'category': 'hias',
                    'image_url': '/placeholder.svg?height=300&width=400'
                },
                {
                    'name': 'Ikan Gurame Segar',
                    'description': 'Ikan gurame segar dengan daging tebal. Cocok untuk masakan tradisional. Kualitas terjamin dan segar.',
                    'price': 45000,
                    'stock': 20,
                    'category': 'konsumsi',
                    'image_url': '/placeholder.svg?height=300&width=400'
                }
            ]
            
            for prod_data in products_data:
                product = Product(
                    seller_id=seller.id,
                    **prod_data
                )
                db.session.add(product)
        
        # Create sample buyer
        if not User.query.filter_by(email='buyer@iktar.com').first():
            buyer = User(
                name='Pembeli Demo',
                email='buyer@iktar.com',
                phone='081234567892',
                role='buyer',
                avatar='/placeholder.svg?height=40&width=40'
            )
            buyer.set_password('buyer123')
            db.session.add(buyer)
        
        db.session.commit()
        print("✅ Sample data created successfully!")
        
    except Exception as e:
        print(f"⚠️ Error creating sample data: {e}")
        db.session.rollback()

def main():
    """Main application entry point"""
    try:
        with app.app_context():
            try:
                # Create tables
                db.create_all()
                print("✅ Database tables created successfully!")
                
                # Create sample data
                create_sample_data()
                    
            except Exception as e:
                print(f"⚠️ Database setup error: {e}")
                return
        
        print("🐟 IkTar Backend API Starting...")
        print("📍 API URL: http://localhost:5000")
        print("🔗 Frontend URL: http://localhost:3000")
        print("🔑 Demo Accounts:")
        print("   👑 Admin: admin@iktar.com / admin123")
        print("   🏪 Seller: seller@iktar.com / seller123")
        print("   🛒 Buyer: buyer@iktar.com / buyer123")
        print("🧪 Test endpoints:")
        print("   - http://localhost:5000/api/products")
        print("   - http://localhost:5000/api/stats")
        print("=" * 50)
        
        # Run the application
        app.run(
            host='0.0.0.0',
            port=5000,
            debug=True
        )
        
    except Exception as e:
        print(f"❌ Application Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()
